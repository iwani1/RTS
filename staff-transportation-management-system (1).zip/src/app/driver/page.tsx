// @ts-nocheck
import { getSession } from "@/lib/auth";
import { redirect } from "next/navigation";

export default async function DriverPage() {
  const session = await getSession();

  if (!session) {
    redirect("/login");
  }

  if (session.role !== "driver" && session.role !== "super_admin") {
    redirect("/unauthorized");
  }

  return (
    <div>
      <ClientDriverPage />
    </div>
  );
}

function ClientDriverPage() {
  return (
    <div className="min-h-screen bg-slate-50 p-4 md:p-6">
      <header className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Driver Dashboard</h1>
          <p className="text-slate-500 text-sm">Manage your assigned trips</p>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-sm text-slate-500 hidden md:block">
            Driver: Kwaku Ofori
          </span>
          <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white text-sm font-medium">KO</div>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <p className="text-sm text-slate-500">Today's Trips</p>
          <p className="text-3xl font-bold text-slate-900">2</p>
          <p className="text-xs text-green-600 mt-1">• 1 scheduled, 1 completed</p>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <p className="text-sm text-slate-500">Status</p>
          <p className="text-3xl font-bold text-slate-900">Available</p>
          <button className="w-full mt-3 px-4 py-2 bg-primary text-white rounded-lg text-sm font-medium hover:bg-primary/90">
            Mark Unavailable
          </button>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <p className="text-sm text-slate-500">Total Trips</p>
          <p className="text-3xl font-bold text-slate-900">24</p>
          <p className="text-xs text-green-600 mt-1">• 100% completion rate</p>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200">
          <h2 className="text-lg font-semibold text-slate-900">Assigned Trips</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-left text-slate-500">
                <th className="px-6 py-3 font-medium">Trip</th>
                <th className="px-6 py-3 font-medium">Route</th>
                <th className="px-6 py-3 font-medium">Vehicle</th>
                <th className="px-6 py-3 font-medium">Departure</th>
                <th className="px-6 py-3 font-medium">Status</th>
                <th className="px-6 py-3 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-slate-200 hover:bg-slate-50">
                <td className="px-6 py-3 font-medium">Trip #101</td>
                <td className="px-6 py-3">Osu - Head Office</td>
                <td className="px-6 py-3">GT-1234-A</td>
                <td className="px-6 py-3">07:00 AM</td>
                <td className="px-6 py-3">
                  <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded-full text-xs">Scheduled</span>
                </td>
                <td className="px-6 py-3">
                  <button className="px-4 py-2 bg-primary text-white rounded-lg text-sm hover:bg-primary/90">
                    Start Trip
                  </button>
                </td>
              </tr>
              <tr className="border-b border-slate-200 hover:bg-slate-50">
                <td className="px-6 py-3 font-medium">Trip #102</td>
                <td className="px-6 py-3">East Legon - Head Office</td>
                <td className="px-6 py-3">GT-5678-B</td>
                <td className="px-6 py-3">07:15 AM</td>
                <td className="px-6 py-3">
                  <span className="px-2 py-1 bg-green-100 text-green-700 rounded-full text-xs">Completed</span>
                </td>
                <td className="px-6 py-3">
                  <button className="px-4 py-2 text-slate-600 rounded-lg text-sm hover:bg-slate-100">
                    View Details
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <h2 className="text-lg font-semibold text-slate-900 mb-4">Quick Actions</h2>
          <div className="space-y-3">
            <button className="w-full py-3 border border-slate-300 rounded-lg text-sm text-slate-700 hover:bg-slate-50 flex items-center justify-between">
              <span>Report Breakdown</span>
              <span className="text-slate-400">›</span>
            </button>
            <button className="w-full py-3 border border-slate-300 rounded-lg text-sm text-slate-700 hover:bg-slate-50 flex items-center justify-between">
              <span>Report Traffic Delay</span>
              <span className="text-slate-400">›</span>
            </button>
            <button className="w-full py-3 border border-slate-300 rounded-lg text-sm text-slate-700 hover:bg-slate-50 flex items-center justify-between">
              <span>Submit Incident</span>
              <span className="text-slate-400">›</span>
            </button>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <h2 className="text-lg font-semibold text-slate-900 mb-4">Today's Schedule</h2>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
              <div>
                <p className="text-sm font-medium text-slate-900">Morning Pickup</p>
                <p className="text-xs text-slate-500">Osu • 07:00 AM • 30 seats</p>
              </div>
              <span className="text-xs font-medium bg-green-100 text-green-700 px-2 py-1 rounded">On Time</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
              <div>
                <p className="text-sm font-medium text-slate-900">Evening Dropoff</p>
                <p className="text-xs text-slate-500">Head Office • 05:30 PM • 28 seats</p>
              </div>
              <span className="text-xs font-medium bg-green-100 text-green-700 px-2 py-1 rounded">On Time</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}