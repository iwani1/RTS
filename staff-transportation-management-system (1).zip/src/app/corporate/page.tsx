// @ts-nocheck
import { getSession } from "@/lib/auth";
import { redirect } from "next/navigation";

export default async function CorporatePage() {
  const session = await getSession();

  if (!session) {
    redirect("/login");
  }

  if (session.role !== "corporate_hr" && session.role !== "super_admin") {
    redirect("/unauthorized");
  }

  return (
    <div>
      <ClientCorporatePage initialRole={session.role} initialCompanyId={session.companyId} />
    </div>
  );
}

function ClientCorporatePage({ initialRole, initialCompanyId }: any) {
  return (
    <div className="min-h-screen bg-slate-50 p-6 md:p-12">
      <header className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Corporate Portal</h1>
          <p className="text-slate-500 text-sm">Manage your company transportation</p>
        </div>
      </header>
      <CorporateClientContent initialCompanyId={initialCompanyId} />
    </div>
  );
}

function CorporateClientContent({ initialCompanyId }: any) {
  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <p className="text-sm text-slate-500">Total Employees</p>
          <p className="text-2xl font-bold text-slate-900">5</p>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <p className="text-sm text-slate-500">Active Bookings</p>
          <p className="text-2xl font-bold text-slate-900">12</p>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <p className="text-sm text-slate-500">Vehicles</p>
          <p className="text-2xl font-bold text-slate-900">3</p>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <p className="text-sm text-slate-500">Drivers</p>
          <p className="text-2xl font-bold text-slate-900">2</p>
        </div>
      </div>
      <div className="bg-white rounded-xl border border-slate-200 p-6">
        <h2 className="text-lg font-semibold text-slate-900 mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button className="px-6 py-3 bg-primary text-white rounded-lg text-sm font-medium hover:bg-primary/90">
            Book Transportation
          </button>
          <button className="px-6 py-3 border border-slate-300 rounded-lg text-sm text-slate-700 hover:bg-slate-50">
            View Bookings
          </button>
          <button className="px-6 py-3 border border-slate-300 rounded-lg text-sm text-slate-700 hover:bg-slate-50">
            View Trips
          </button>
        </div>
      </div>
    </div>
  );
}