// @ts-nocheck
import { getSession } from "@/lib/auth";
import { redirect } from "next/navigation";

export default async function HomePage() {
  const session = await getSession();

  if (session) {
    if (session.role === "super_admin" || session.role === "operations_manager" || session.role === "fleet_manager" || session.role === "finance_officer") {
      redirect("/dashboard");
    }
    if (session.role === "dispatcher") {
      redirect("/dispatch");
    }
    if (session.role === "corporate_hr") {
      redirect("/corporate");
    }
    if (session.role === "driver") {
      redirect("/driver");
    }
    if (session.role === "employee") {
      redirect("/employee");
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50">
      <div className="max-w-4xl mx-auto px-6 text-center">
        <div className="w-16 h-16 bg-primary rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg shadow-primary/20">
          <span className="text-3xl">🚌</span>
        </div>
        <h1 className="text-4xl font-bold text-slate-900 mb-4">Staff Transportation Management System</h1>
        <p className="text-xl text-slate-600 mb-8">
          Enterprise-grade transportation management for corporate clients.
          Manage bookings, vehicles, drivers, routes, and live dispatching.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <a href="/login" className="px-8 py-4 bg-primary text-white rounded-xl text-lg font-medium hover:bg-primary/90 transition-colors shadow-lg shadow-primary/20">
            Sign In
          </a>
        </div>
        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-8 text-left">
          <div className="text-left">
            <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center text-blue-600 mb-3">
              <span>🏢</span>
            </div>
            <h3 className="text-lg font-semibold text-slate-900 mb-2">Multi-Company</h3>
            <p className="text-slate-500 text-sm">Manage multiple corporate clients under one platform</p>
          </div>
          <div className="text-left">
            <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center text-green-600 mb-3">
              <span>📱</span>
            </div>
            <h3 className="text-lg font-semibold text-slate-900 mb-2">Mobile Ready</h3>
            <p className="text-slate-500 text-sm">Driver and passenger mobile interfaces</p>
          </div>
          <div className="text-left">
            <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center text-purple-600 mb-3">
              <span>📊</span>
            </div>
            <h3 className="text-lg font-semibold text-slate-900 mb-2">Real-time Dispatch</h3>
            <p className="text-slate-500 text-sm">Live GPS tracking and operational dashboard</p>
          </div>
        </div>
      </div>
    </div>
  );
}