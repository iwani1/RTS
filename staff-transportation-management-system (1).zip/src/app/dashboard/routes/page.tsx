// @ts-nocheck
"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

export default function RoutesPage() {
  const [routes, setRoutes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    loadRoutes();
  }, []);

  async function loadRoutes() {
    try {
      const res = await fetch("/api/routes");
      const data = await res.json();
      setRoutes(data.routes || []);
    } catch (err) {
      toast.error("Failed to load routes");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Routes</h1>
          <p className="text-slate-500">Manage transportation routes</p>
        </div>
        <Button onClick={() => setShowForm(true)}>
          <Plus className="w-4 h-4 mr-2" /> Add Route
        </Button>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Code</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Description</TableHead>
              <TableHead>Shift</TableHead>
              <TableHead>Duration</TableHead>
              <TableHead>Distance</TableHead>
              <TableHead>Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {routes.map((r, i) => (
              <TableRow key={r.id || i}>
                <TableCell className="font-medium">{r.code}</TableCell>
                <TableCell>{r.name}</TableCell>
                <TableCell>{r.description || "-"}</TableCell>
                <TableCell>{r.shift?.name || "N/A"}</TableCell>
                <TableCell>{r.estimatedDurationMinutes || "-"} min</TableCell>
                <TableCell>{r.distanceKm || "-"} km</TableCell>
                <TableCell>
                  <Badge variant="success">{r.isActive ? "Active" : "Inactive"}</Badge>
                </TableCell>
              </TableRow>
            ))}
            {routes.length === 0 && (
              <TableRow>
                <TableCell colSpan={7} className="text-center text-slate-500 py-4">
                  No routes found
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>Add Route</CardTitle>
          </CardHeader>
          <CardContent>
            <form className="space-y-4" onSubmit={(e) => {
              e.preventDefault();
              toast.success("Route added (demo)");
              setShowForm(false);
            }}>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Route Name</label>
                  <Input placeholder="Osu - Head Office" required />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Route Code</label>
                  <Input placeholder="R001" required />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Description</label>
                  <Input placeholder="Route description" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Shift</label>
                  <Input placeholder="Select shift" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Duration (min)</label>
                  <Input type="number" placeholder="45" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Distance (km)</label>
                  <Input placeholder="12.5" />
                </div>
              </div>
              <div className="flex gap-2 pt-4">
                <Button type="submit">Add Route</Button>
                <Button type="button" variant="outline" onClick={() => setShowForm(false)}>
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}
    </div>
  );
}