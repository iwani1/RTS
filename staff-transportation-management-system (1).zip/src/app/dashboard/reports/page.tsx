// @ts-nocheck
"use client";

import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function ReportsPage() {
  const [reports, setReports] = useState([]);

  useEffect(() => {
    setReports([
      { title: "Daily Operations Report", type: "Operational", date: "Today", records: 12 },
      { title: "Vehicle Utilization Report", type: "Fleet", date: "This Week", records: 3 },
      { title: "Driver Performance Report", type: "HR", date: "This Month", records: 2 },
      { title: "Booking Analytics", type: "Bookings", date: "This Month", records: 45 },
      { title: "Revenue Summary", type: "Finance", date: "This Month", records: 1 },
      { title: "Incident Summary", type: "Safety", date: "This Quarter", records: 0 },
    ]);
  }, []);

  const typeConfig = {
    Operational: "info",
    Fleet: "success",
    HR: "primary",
    Bookings: "warning",
    Finance: "secondary",
    Safety: "destructive",
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Reports</h1>
          <p className="text-slate-500">Generate and export operational reports</p>
        </div>
        <div className="flex gap-2">
          <Button>Export CSV</Button>
          <Button variant="outline">Export PDF</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {reports.map((r, i) => (
          <Card key={i}>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-sm">{r.title}</CardTitle>
                <p className="text-xs text-slate-500">{r.type} • {r.date}</p>
              </div>
              <Badge variant={typeConfig[r.type] || "secondary"}>
                {r.records} records
              </Badge>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between pt-4">
                <span className="text-sm text-slate-600">Download</span>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline">CSV</Button>
                  <Button size="sm" variant="outline">PDF</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}