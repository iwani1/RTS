// @ts-nocheck
"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

export default function IncidentsPage() {
  const [incidents, setIncidents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    loadIncidents();
  }, []);

  async function loadIncidents() {
    try {
      const res = await fetch("/api/incidents");
      const data = await res.json();
      setIncidents(data.incidents || []);
    } catch (err) {
      toast.error("Failed to load incidents");
    } finally {
      setLoading(false);
    }
  }

  const severityConfig = {
    low: { variant: "info", label: "Low" },
    medium: { variant: "warning", label: "Medium" },
    high: { variant: "warning", label: "High" },
    critical: { variant: "destructive", label: "Critical" },
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Incidents</h1>
          <p className="text-slate-500">Safety and incident reports</p>
        </div>
        <Button onClick={() => setShowForm(true)}>
          <Plus className="w-4 h-4 mr-2" /> Report Incident
        </Button>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Title</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Severity</TableHead>
              <TableHead>Location</TableHead>
              <TableHead>Reported By</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Date</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {incidents.map((inc, i) => (
              <TableRow key={inc.id || i}>
                <TableCell className="font-medium">{inc.title}</TableCell>
                <TableCell className="text-sm">{inc.incidentType}</TableCell>
                <TableCell>
                  <Badge variant={severityConfig[inc.severity]?.variant || "secondary"}>
                    {severityConfig[inc.severity]?.label || inc.severity}
                  </Badge>
                </TableCell>
                <TableCell className="text-sm">{inc.location || "-"}</TableCell>
                <TableCell className="text-sm">{inc.reportedBy}</TableCell>
                <TableCell>
                  <Badge variant="info">{inc.status}</Badge>
                </TableCell>
                <TableCell>{inc.createdAt}</TableCell>
              </TableRow>
            ))}
            {incidents.length === 0 && (
              <TableRow>
                <TableCell colSpan={7} className="text-center text-slate-500 py-4">
                  No incidents found
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>Report Incident</CardTitle>
          </CardHeader>
          <CardContent>
            <form className="space-y-4" onSubmit={(e) => {
              e.preventDefault();
              toast.success("Incident reported (demo)");
              setShowForm(false);
            }}>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Title</label>
                  <Input placeholder="Incident title" required />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Incident Type</label>
                  <Input placeholder="Breakdown, Accident, Delay" required />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Severity</label>
                  <Input placeholder="low/medium/high/critical" required />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Trip</label>
                  <Input placeholder="Trip ID" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Vehicle</label>
                  <Input placeholder="Vehicle ID" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Driver</label>
                  <Input placeholder="Driver ID" />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Location</label>
                <Input placeholder="Incident location" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Description</label>
                <textarea className="w-full border border-slate-300 rounded-md p-2 text-sm" rows={3} required />
              </div>
              <div className="flex gap-2 pt-4">
                <Button type="submit">Report Incident</Button>
                <Button type="button" variant="outline" onClick={() => setShowForm(false)}>
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}
    </div>
  );
}