// @ts-nocheck
"use client";

import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Users, Truck, Bus, Calendar, AlertCircle, Clock, CheckCircle2, TrendingUp } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

const statCards = [
  { title: "Total Companies", value: "1", icon: Users, color: "bg-blue-500" },
  { title: "Total Employees", value: "5", icon: Users, color: "bg-green-500" },
  { title: "Total Vehicles", value: "3", icon: Truck, color: "bg-purple-500" },
  { title: "Total Drivers", value: "2", icon: Bus, color: "bg-orange-500" },
  { title: "Active Trips", value: "2", icon: Calendar, color: "bg-indigo-500" },
  { title: "Pending Bookings", value: "0", icon: Clock, color: "bg-yellow-500" },
];

const recentTrips = [
  { id: 1, route: "Osu - Head Office", driver: "Kwaku Ofori", vehicle: "GT-1234-A", status: "scheduled", time: "07:00 AM", capacity: "12/30" },
  { id: 2, route: "East Legon - Head Office", driver: "Samuel Addo", vehicle: "GT-5678-B", status: "scheduled", time: "07:15 AM", capacity: "8/15" },
];

export default function DashboardPage() {
  const [stats, setStats] = useState(statCards);

  useEffect(() => {
    fetch("/api/dashboard")
      .then((res) => res.json())
      .then((data) => {
        if (data.stats) {
          setStats([
            { title: "Total Companies", value: data.stats.totalCompanies, icon: Users, color: "bg-blue-500" },
            { title: "Total Employees", value: data.stats.totalEmployees, icon: Users, color: "bg-green-500" },
            { title: "Total Vehicles", value: data.stats.totalVehicles, icon: Truck, color: "bg-purple-500" },
            { title: "Total Drivers", value: data.stats.totalDrivers, icon: Bus, color: "bg-orange-500" },
            { title: "Total Trips", value: data.stats.totalTrips, icon: Calendar, color: "bg-indigo-500" },
            { title: "Total Bookings", value: data.stats.totalBookings, icon: Clock, color: "bg-yellow-500" },
          ]);
        }
      })
      .catch(() => toast.error("Failed to load dashboard data"));
  }, []);

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-6">
        {stats.map((stat, i) => (
          <Card key={i} className="border-l-4 border-transparent">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-slate-500">{stat.title}</CardTitle>
              <div className={cn(stat.color, "p-3 rounded-lg")}>
                <stat.icon className="w-5 h-5 text-white" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-slate-900">{stat.value}</div>
              <p className="text-xs text-slate-400 mt-1">Real-time data</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Recent Trips</CardTitle>
            <CardDescription>View latest scheduled trips</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Route</TableHead>
                  <TableHead>Driver</TableHead>
                  <TableHead>Vehicle</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Time</TableHead>
                  <TableHead>Capacity</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {recentTrips.map((trip) => (
                  <TableRow key={trip.id}>
                    <TableCell>{trip.route}</TableCell>
                    <TableCell>{trip.driver}</TableCell>
                    <TableCell>{trip.vehicle}</TableCell>
                    <TableCell>
                      <Badge variant={trip.status === "scheduled" ? "info" : "secondary"}>
                        {trip.status}
                      </Badge>
                    </TableCell>
                    <TableCell>{trip.time}</TableCell>
                    <TableCell>{trip.capacity}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>System Status</CardTitle>
            <CardDescription>Operational health overview</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between py-2">
              <span className="text-sm text-slate-600">Database Connection</span>
              <Badge variant="success">Connected</Badge>
            </div>
            <div className="flex items-center justify-between py-2">
              <span className="text-sm text-slate-600">API Server</span>
              <Badge variant="success">Online</Badge>
            </div>
            <div className="flex items-center justify-between py-2">
              <span className="text-sm text-slate-600">GPS Tracking</span>
              <Badge variant="info">Standby</Badge>
            </div>
            <div className="flex items-center justify-between py-2">
              <span className="text-sm text-slate-600">Notifications</span>
              <Badge variant="success">Active</Badge>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}