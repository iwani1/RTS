// @ts-nocheck
"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

export default function VehiclesPage() {
  const [vehicles, setVehicles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    loadVehicles();
  }, []);

  async function loadVehicles() {
    try {
      const res = await fetch("/api/vehicles");
      const data = await res.json();
      setVehicles(data.vehicles || []);
    } catch (err) {
      toast.error("Failed to load vehicles");
    } finally {
      setLoading(false);
    }
  }

  const statusConfig = {
    available: { variant: "success", label: "Available" },
    assigned: { variant: "info", label: "Assigned" },
    on_trip: { variant: "warning", label: "On Trip" },
    under_maintenance: { variant: "warning", label: "Maintenance" },
    out_of_service: { variant: "destructive", label: "Out of Service" },
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Vehicles</h1>
          <p className="text-slate-500">Manage fleet vehicles</p>
        </div>
        <Button onClick={() => setShowForm(true)}>
          <Plus className="w-4 h-4 mr-2" /> Add Vehicle
        </Button>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Registration</TableHead>
              <TableHead>Make / Model</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Capacity</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Assigned Driver</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {vehicles.map((v, i) => (
              <TableRow key={v.id || i}>
                <TableCell className="font-medium">{v.registrationNumber}</TableCell>
                <TableCell>{v.make} {v.model}</TableCell>
                <TableCell>{v.vehicleType}</TableCell>
                <TableCell>{v.seatingCapacity} seats</TableCell>
                <TableCell>
                  <Badge variant={statusConfig[v.status]?.variant || "secondary"}>
                    {statusConfig[v.status]?.label || v.status}
                  </Badge>
                </TableCell>
                <TableCell>{v.assignedDriverId ? "Assigned" : "Unassigned"}</TableCell>
              </TableRow>
            ))}
            {vehicles.length === 0 && (
              <TableRow>
                <TableCell colSpan={6} className="text-center text-slate-500 py-4">
                  No vehicles found
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>Add Vehicle</CardTitle>
          </CardHeader>
          <CardContent>
            <form className="space-y-4" onSubmit={(e) => {
              e.preventDefault();
              toast.success("Vehicle added (demo)");
              setShowForm(false);
            }}>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Registration Number</label>
                  <Input placeholder="GT-1234-A" required />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Make</label>
                  <Input placeholder="Toyota" required />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Model</label>
                  <Input placeholder="Coaster" required />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Year</label>
                  <Input type="number" placeholder="2022" required />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Vehicle Type</label>
                  <Input placeholder="minibus" required />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Fuel Type</label>
                  <Input placeholder="diesel" required />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Seating Capacity</label>
                  <Input type="number" placeholder="30" required />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Color</label>
                  <Input placeholder="White" />
                </div>
              </div>
              <div className="flex gap-2 pt-4">
                <Button type="submit">Add Vehicle</Button>
                <Button type="button" variant="outline" onClick={() => setShowForm(false)}>
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}
    </div>
  );
}