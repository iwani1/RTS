// @ts-nocheck
"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function SettingsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Settings</h1>
        <p className="text-slate-500">System configuration and preferences</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Company Settings</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">System Name</label>
            <Input defaultValue="Staff Transportation Management System" />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Default Currency</label>
            <Input defaultValue="GHS" />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Default Timezone</label>
            <Input defaultValue="Africa/Accra" />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Support Email</label>
            <Input type="email" defaultValue="support@tms.com" />
          </div>
          <Button>Save Settings</Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Authentication Settings</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Session Timeout (minutes)</label>
            <Input type="number" defaultValue="10080" />
          </div>
          <div className="space-y-2 flex items-center gap-3">
            <input type="checkbox" className="rounded text-primary" defaultChecked />
            <label className="text-sm text-slate-600">Enable Two-Factor Authentication</label>
          </div>
          <div className="space-y-2 flex items-center gap-3">
            <input type="checkbox" className="rounded text-primary" defaultChecked />
            <label className="text-sm text-slate-600">Require Email Verification</label>
          </div>
          <Button>Save Auth Settings</Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Notification Settings</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2 flex items-center gap-3">
            <input type="checkbox" className="rounded text-primary" defaultChecked />
            <label className="text-sm text-slate-600">Email Notifications</label>
          </div>
          <div className="space-y-2 flex items-center gap-3">
            <input type="checkbox" className="rounded text-primary" defaultChecked />
            <label className="text-sm text-slate-600">SMS Notifications</label>
          </div>
          <div className="space-y-2 flex items-center gap-3">
            <input type="checkbox" className="rounded text-primary" defaultChecked />
            <label className="text-sm text-slate-600">Push Notifications</label>
          </div>
          <Button>Save Notification Settings</Button>
        </CardContent>
      </Card>
    </div>
  );
}