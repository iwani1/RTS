// @ts-nocheck
"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

export default function TripsPage() {
  const [trips, setTrips] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    loadTrips();
  }, []);

  async function loadTrips() {
    try {
      const res = await fetch("/api/trips");
      const data = await res.json();
      setTrips(data.trips || []);
    } catch (err) {
      toast.error("Failed to load trips");
    } finally {
      setLoading(false);
    }
  }

  const statusConfig = {
    scheduled: { variant: "info", label: "Scheduled" },
    dispatched: { variant: "warning", label: "Dispatched" },
    in_progress: { variant: "warning", label: "In Progress" },
    completed: { variant: "success", label: "Completed" },
    cancelled: { variant: "destructive", label: "Cancelled" },
    delayed: { variant: "warning", label: "Delayed" },
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Trips</h1>
          <p className="text-slate-500">Manage scheduled trips</p>
        </div>
        <Button onClick={() => setShowForm(true)}>
          <Plus className="w-4 h-4 mr-2" /> Add Trip
        </Button>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Route</TableHead>
              <TableHead>Vehicle</TableHead>
              <TableHead>Driver</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Departure</TableHead>
              <TableHead>Capacity</TableHead>
              <TableHead>Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {trips.map((t, i) => (
              <TableRow key={t.id || i}>
                <TableCell>{t.route?.name || "N/A"}</TableCell>
                <TableCell>{t.vehicle?.registrationNumber || "N/A"}</TableCell>
                <TableCell>{t.driver?.firstName + " " + t.driver?.lastName || "N/A"}</TableCell>
                <TableCell>{t.tripDate}</TableCell>
                <TableCell>{t.scheduledDeparture}</TableCell>
                <TableCell>{t.currentOccupancy}/{t.capacity}</TableCell>
                <TableCell>
                  <Badge variant={statusConfig[t.status]?.variant || "secondary"}>
                    {statusConfig[t.status]?.label || t.status}
                  </Badge>
                </TableCell>
              </TableRow>
            ))}
            {trips.length === 0 && (
              <TableRow>
                <TableCell colSpan={7} className="text-center text-slate-500 py-4">
                  No trips found
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>Schedule Trip</CardTitle>
          </CardHeader>
          <CardContent>
            <form className="space-y-4" onSubmit={(e) => {
              e.preventDefault();
              toast.success("Trip scheduled (demo)");
              setShowForm(false);
            }}>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Route</label>
                  <Input placeholder="Select route" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Vehicle</label>
                  <Input placeholder="Select vehicle" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Driver</label>
                  <Input placeholder="Select driver" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Shift</label>
                  <Input placeholder="Select shift" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Trip Date</label>
                  <Input type="date" required />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Departure Time</label>
                  <Input type="time" required />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Capacity</label>
                  <Input type="number" placeholder="30" required />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Notes</label>
                <Input placeholder="Additional notes" />
              </div>
              <div className="flex gap-2 pt-4">
                <Button type="submit">Schedule Trip</Button>
                <Button type="button" variant="outline" onClick={() => setShowForm(false)}>
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}
    </div>
  );
}