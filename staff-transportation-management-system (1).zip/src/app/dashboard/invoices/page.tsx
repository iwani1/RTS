// @ts-nocheck
"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

export default function InvoicesPage() {
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadInvoices();
  }, []);

  async function loadInvoices() {
    try {
      const res = await fetch("/api/invoices");
      const data = await res.json();
      setInvoices(data.invoices || []);
    } catch (err) {
      toast.error("Failed to load invoices");
    } finally {
      setLoading(false);
    }
  }

  const statusConfig = {
    draft: { variant: "info", label: "Draft" },
    sent: { variant: "warning", label: "Sent" },
    paid: { variant: "success", label: "Paid" },
    overdue: { variant: "destructive", label: "Overdue" },
    cancelled: { variant: "secondary", label: "Cancelled" },
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Invoices</h1>
          <p className="text-slate-500">Corporate billing and invoicing</p>
        </div>
        <Button>
          <Plus className="w-4 h-4 mr-2" /> Generate Invoice
        </Button>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Invoice #</TableHead>
              <TableHead>Company</TableHead>
              <TableHead>Period</TableHead>
              <TableHead>Total Amount</TableHead>
              <TableHead>Paid</TableHead>
              <TableHead>Due Date</TableHead>
              <TableHead>Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {invoices.map((inv, i) => (
              <TableRow key={inv.id || i}>
                <TableCell className="font-medium">{inv.invoiceNumber || `INV-${i+1}`}</TableCell>
                <TableCell>{inv.company?.name || "N/A"}</TableCell>
                <TableCell className="text-sm">{inv.billingPeriodStart} - {inv.billingPeriodEnd}</TableCell>
                <TableCell>₵{inv.totalAmount || 0}</TableCell>
                <TableCell>₵{inv.amountPaid || 0}</TableCell>
                <TableCell>{inv.dueDate}</TableCell>
                <TableCell>
                  <Badge variant={statusConfig[inv.status]?.variant || "secondary"}>
                    {statusConfig[inv.status]?.label || inv.status}
                  </Badge>
                </TableCell>
              </TableRow>
            ))}
            {invoices.length === 0 && (
              <TableRow>
                <TableCell colSpan={7} className="text-center text-slate-500 py-4">
                  No invoices found
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Quick Invoice Generation</CardTitle>
        </CardHeader>
        <CardContent>
          <form className="space-y-4" onSubmit={(e) => {
            e.preventDefault();
            toast.success("Invoice generated (demo)");
          }}>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Company</label>
                <Input placeholder="Select company" required />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Period Start</label>
                <Input type="date" required />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Period End</label>
                <Input type="date" required />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Due Date</label>
                <Input type="date" required />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Notes</label>
              <Input placeholder="Invoice notes" />
            </div>
            <Button type="submit">Generate Invoice</Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}