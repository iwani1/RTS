// @ts-nocheck
"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

export default function BookingsPage() {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    loadBookings();
  }, []);

  async function loadBookings() {
    try {
      const res = await fetch("/api/bookings");
      const data = await res.json();
      setBookings(data.bookings || []);
    } catch (err) {
      toast.error("Failed to load bookings");
    } finally {
      setLoading(false);
    }
  }

  const statusConfig = {
    pending: { variant: "warning", label: "Pending" },
    confirmed: { variant: "success", label: "Confirmed" },
    assigned: { variant: "info", label: "Assigned" },
    picked_up: { variant: "success", label: "Picked Up" },
    dropped_off: { variant: "success", label: "Dropped Off" },
    cancelled: { variant: "destructive", label: "Cancelled" },
    no_show: { variant: "warning", label: "No Show" },
    waiting_list: { variant: "info", label: "Waiting" },
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Bookings</h1>
          <p className="text-slate-500">Manage employee bookings</p>
        </div>
        <Button onClick={() => setShowForm(true)}>
          <Plus className="w-4 h-4 mr-2" /> Add Booking
        </Button>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Reference</TableHead>
              <TableHead>Employee</TableHead>
              <TableHead>Pickup</TableHead>
              <TableHead>Dropoff</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Pickup Time</TableHead>
              <TableHead>Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {bookings.map((b, i) => (
              <TableRow key={b.id || i}>
                <TableCell className="font-medium text-xs">{b.bookingReference}</TableCell>
                <TableCell>{b.employee?.firstName + " " + b.employee?.lastName || "N/A"}</TableCell>
                <TableCell className="text-sm">{b.pickupLocation}</TableCell>
                <TableCell className="text-sm">{b.dropoffLocation}</TableCell>
                <TableCell>{b.tripDate}</TableCell>
                <TableCell>{b.scheduledPickupTime}</TableCell>
                <TableCell>
                  <Badge variant={statusConfig[b.status]?.variant || "secondary"}>
                    {statusConfig[b.status]?.label || b.status}
                  </Badge>
                </TableCell>
              </TableRow>
            ))}
            {bookings.length === 0 && (
              <TableRow>
                <TableCell colSpan={7} className="text-center text-slate-500 py-4">
                  No bookings found
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>Create Booking</CardTitle>
          </CardHeader>
          <CardContent>
            <form className="space-y-4" onSubmit={(e) => {
              e.preventDefault();
              toast.success("Booking created (demo)");
              setShowForm(false);
            }}>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Employee</label>
                  <Input placeholder="Select employee" required />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Trip</label>
                  <Input placeholder="Select trip" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Route</label>
                  <Input placeholder="Select route" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Booking Type</label>
                  <Input placeholder="one_time" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Pickup Location</label>
                  <Input placeholder="Pickup location" required />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Dropoff Location</label>
                  <Input placeholder="Dropoff location" required />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Trip Date</label>
                  <Input type="date" required />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Pickup Time</label>
                  <Input type="time" required />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Notes</label>
                <Input placeholder="Additional notes" />
              </div>
              <div className="flex gap-2 pt-4">
                <Button type="submit">Create Booking</Button>
                <Button type="button" variant="outline" onClick={() => setShowForm(false)}>
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}
    </div>
  );
}