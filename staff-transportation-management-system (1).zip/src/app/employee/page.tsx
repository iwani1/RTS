// @ts-nocheck
import { getSession } from "@/lib/auth";
import { redirect } from "next/navigation";

export default async function EmployeePage() {
  const session = await getSession();

  if (!session) {
    redirect("/login");
  }

  if (session.role !== "employee" && session.role !== "super_admin") {
    redirect("/unauthorized");
  }

  return (
    <div>
      <ClientEmployeePage />
    </div>
  );
}

function ClientEmployeePage() {
  return (
    <div className="min-h-screen bg-slate-50 p-4 md:p-6">
      <header className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">My Transportation</h1>
          <p className="text-slate-500 text-sm">Book and track your rides</p>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-sm text-slate-500 hidden md:block">
            Kwame Asare
          </span>
          <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white text-sm font-medium">KA</div>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <p className="text-sm text-slate-500">Upcoming Trips</p>
          <p className="text-3xl font-bold text-slate-900">2</p>
          <p className="text-xs text-green-600 mt-1">• Today: 1, Tomorrow: 1</p>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <p className="text-sm text-slate-500">Next Pickup</p>
          <p className="text-3xl font-bold text-slate-900">07:00 AM</p>
          <p className="text-xs text-slate-500 mt-1">Osu Oxford Street</p>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <p className="text-sm text-slate-500">Trip History</p>
          <p className="text-3xl font-bold text-slate-900">24</p>
          <p className="text-xs text-green-600 mt-1">• 100% attendance</p>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-slate-900">Book Transportation</h2>
          <button className="px-4 py-2 bg-primary text-white rounded-lg text-sm font-medium hover:bg-primary/90">
            New Booking
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-left text-slate-500">
                <th className="px-6 py-3 font-medium">Date</th>
                <th className="px-6 py-3 font-medium">Route</th>
                <th className="px-6 py-3 font-medium">Pickup</th>
                <th className="px-6 py-3 font-medium">Time</th>
                <th className="px-6 py-3 font-medium">Status</th>
                <th className="px-6 py-3 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-slate-200 hover:bg-slate-50">
                <td className="px-6 py-3 font-medium">Today</td>
                <td className="px-6 py-3">Osu - Head Office</td>
                <td className="px-6 py-3">Osu Oxford St</td>
                <td className="px-6 py-3">06:45 AM</td>
                <td className="px-6 py-3">
                  <span className="px-2 py-1 bg-green-100 text-green-700 rounded-full text-xs">Confirmed</span>
                </td>
                <td className="px-6 py-3">
                  <button className="text-primary text-sm hover:underline">View</button>
                </td>
              </tr>
              <tr className="border-b border-slate-200 hover:bg-slate-50">
                <td className="px-6 py-3 font-medium">Today</td>
                <td className="px-6 py-3">Head Office - Osu</td>
                <td className="px-6 py-3">Head Office</td>
                <td className="px-6 py-3">05:30 PM</td>
                <td className="px-6 py-3">
                  <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded-full text-xs">Scheduled</span>
                </td>
                <td className="px-6 py-3">
                  <button className="text-primary text-sm hover:underline">View</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <h2 className="text-lg font-semibold text-slate-900 mb-4">My Profile</h2>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-500">Employee ID</span>
              <span className="text-sm font-medium text-slate-900">EMP-001</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-500">Department</span>
              <span className="text-sm font-medium text-slate-900">Engineering</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-500">Shift</span>
              <span className="text-sm font-medium text-slate-900">Morning Shift</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-500">Home Address</span>
              <span className="text-sm font-medium text-slate-900">15 Osu Street, Accra</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-500">Office Address</span>
              <span className="text-sm font-medium text-slate-900">123 Independence Avenue</span>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <h2 className="text-lg font-semibold text-slate-900 mb-4">Saved Addresses</h2>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-100">
              <div>
                <p className="text-sm font-medium text-slate-900">Home</p>
                <p className="text-xs text-slate-500">15 Osu Street, Accra</p>
              </div>
              <span className="text-xs font-medium bg-blue-100 text-blue-700 px-2 py-1 rounded">Primary</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-100">
              <div>
                <p className="text-sm font-medium text-slate-900">Office</p>
                <p className="text-xs text-slate-500">123 Independence Avenue, Accra</p>
              </div>
              <span className="text-xs font-medium bg-blue-100 text-blue-700 px-2 py-1 rounded">Primary</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}