import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { Toaster as SonnerToaster } from "sonner";

export const metadata: Metadata = {
  title: "Staff Transportation Management System",
  description: "Enterprise-grade transportation management for corporate clients.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-slate-50 text-slate-900 antialiased">
        {children}
        <SonnerToaster position="bottom-right" richColors />
      </body>
    </html>
  );
}