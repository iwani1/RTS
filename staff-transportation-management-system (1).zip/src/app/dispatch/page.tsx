// @ts-nocheck
import { getSession } from "@/lib/auth";
import { redirect } from "next/navigation";

export default async function DispatchPage() {
  const session = await getSession();

  if (!session) {
    redirect("/login");
  }

  if (
    session.role !== "dispatcher" &&
    session.role !== "super_admin" &&
    session.role !== "operations_manager"
  ) {
    redirect("/unauthorized");
  }

  return (
    <div>
      <ClientDispatchPage />
    </div>
  );
}

function ClientDispatchPage() {
  return (
    <div className="min-h-screen bg-slate-50 p-4 md:p-6">
      <header className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Dispatch Command Center</h1>
          <p className="text-slate-500 text-sm">Live transportation operations</p>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-sm text-slate-500 hidden md:block">
            Active Trips: 2
          </span>
          <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white text-sm font-medium">DC</div>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <p className="text-sm text-slate-500">Active Vehicles</p>
          <p className="text-3xl font-bold text-slate-900">3</p>
          <p className="text-xs text-green-600 mt-1">• All operational</p>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <p className="text-sm text-slate-500">Active Trips</p>
          <p className="text-3xl font-bold text-slate-900">2</p>
          <p className="text-xs text-blue-600 mt-1">• 1 in progress</p>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <p className="text-sm text-slate-500">Pending Bookings</p>
          <p className="text-3xl font-bold text-slate-900">0</p>
          <p className="text-xs text-green-600 mt-1">• All processed</p>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <p className="text-sm text-slate-500">Alerts</p>
          <p className="text-3xl font-bold text-slate-900">0</p>
          <p className="text-xs text-green-600 mt-1">• No active alerts</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden h-[600px]">
          <div className="px-6 py-4 border-b border-slate-200">
            <h2 className="text-lg font-semibold text-slate-900">Live Operations Map</h2>
          </div>
          <div className="h-full relative bg-slate-100 overflow-hidden">
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <div className="w-24 h-24 rounded-full border-4 border-primary/20 flex items-center justify-center mx-auto mb-4">
                  <div className="w-12 h-12 rounded-full bg-primary flex items-center justify-center text-white">
                    <span className="text-lg">📍</span>
                  </div>
                </div>
                <p className="text-sm text-slate-500">Map integration ready</p>
                <p className="text-xs text-slate-400 mt-1">Configure Google Maps API key</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200">
            <h2 className="text-lg font-semibold text-slate-900">Trip Status Board</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-left text-slate-500">
                  <th className="px-6 py-3 font-medium">Trip</th>
                  <th className="px-6 py-3 font-medium">Driver</th>
                  <th className="px-6 py-3 font-medium">Vehicle</th>
                  <th className="px-6 py-3 font-medium">Status</th>
                  <th className="px-6 py-3 font-medium">Progress</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-slate-200 hover:bg-slate-50">
                  <td className="px-6 py-3 font-medium">Trip #101</td>
                  <td className="px-6 py-3">Kwaku Ofori</td>
                  <td className="px-6 py-3">GT-1234-A</td>
                  <td className="px-6 py-3">
                    <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded-full text-xs">In Progress</span>
                  </td>
                  <td className="px-6 py-3">
                    <div className="w-full bg-slate-200 rounded-full h-2">
                      <div className="bg-primary h-2 rounded-full" style={{ width: "65%" }} />
                    </div>
                  </td>
                </tr>
                <tr className="border-b border-slate-200 hover:bg-slate-50">
                  <td className="px-6 py-3 font-medium">Trip #102</td>
                  <td className="px-6 py-3">Samuel Addo</td>
                  <td className="px-6 py-3">GT-5678-B</td>
                  <td className="px-6 py-3">
                    <span className="px-2 py-1 bg-green-100 text-green-700 rounded-full text-xs">Completed</span>
                  </td>
                  <td className="px-6 py-3">
                    <div className="w-full bg-slate-200 rounded-full h-2">
                      <div className="bg-green-600 h-2 rounded-full" style={{ width: "100%" }} />
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <h2 className="text-lg font-semibold text-slate-900 mb-4">Quick Dispatch Actions</h2>
          <div className="space-y-3">
            <button className="w-full py-3 border border-slate-300 rounded-lg text-sm text-slate-700 hover:bg-slate-50">
              Assign Vehicle
            </button>
            <button className="w-full py-3 border border-slate-300 rounded-lg text-sm text-slate-700 hover:bg-slate-50">
              Assign Driver
            </button>
            <button className="w-full py-3 border border-slate-300 rounded-lg text-sm text-slate-700 hover:bg-slate-50">
              Create Emergency Trip
            </button>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <h2 className="text-lg font-semibold text-slate-900 mb-4">Operational Alerts</h2>
          <div className="space-y-3">
            <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg border border-blue-100">
              <div className="w-6 h-6 rounded-full bg-blue-200 flex items-center justify-center text-blue-600 text-xs">!</div>
              <div>
                <p className="text-sm text-blue-800 font-medium">No active alerts</p>
                <p className="text-xs text-blue-600">All systems normal</p>
              </div>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <h2 className="text-lg font-semibold text-slate-900 mb-4">Fleet Status</h2>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-500">GT-1234-A (Toyota Coaster)</span>
              <span className="text-xs font-medium bg-green-100 text-green-700 px-2 py-1 rounded">Available</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-500">GT-5678-B (Ford Transit)</span>
              <span className="text-xs font-medium bg-blue-100 text-blue-700 px-2 py-1 rounded">On Trip</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-500">GT-9012-C (Toyota Hiace)</span>
              <span className="text-xs font-medium bg-green-100 text-green-700 px-2 py-1 rounded">Available</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}