// @ts-nocheck
export default function UnauthorizedPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50">
      <div className="text-center">
        <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <span className="text-2xl">🔒</span>
        </div>
        <h1 className="text-2xl font-bold text-slate-900 mb-2">Unauthorized Access</h1>
        <p className="text-slate-500 mb-6">You don't have permission to access this page.</p>
        <a href="/login" className="px-6 py-3 bg-primary text-white rounded-lg text-sm font-medium hover:bg-primary/90">
          Go to Login
        </a>
      </div>
    </div>
  );
}