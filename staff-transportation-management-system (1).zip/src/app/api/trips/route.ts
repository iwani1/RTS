// @ts-nocheck
import { NextResponse } from "next/server";
import { db } from "@/db";
import { trips, vehicles, drivers, bookings } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { tripSchema } from "@/lib/validation";
import { requireAuth, requireRole } from "@/lib/auth";

export async function GET(request: Request) {
  try {
    const session = await requireAuth();
    const { searchParams } = new URL(request.url);
    const companyId = searchParams.get("companyId");
    const status = searchParams.get("status");
    const tripDate = searchParams.get("tripDate");
    const driverId = searchParams.get("driverId");
    const vehicleId = searchParams.get("vehicleId");

    let query = db.query.trips.findMany({
      with: {
        route: true,
        vehicle: true,
        driver: true,
        shift: true,
        bookings: {
          with: {
            employee: true,
          },
        },
      },
      orderBy: (trips, { desc }) => [desc(trips.createdAt)],
    });

    const conditions = [];

    if (
      session.role !== "super_admin" &&
      session.role !== "operations_manager" &&
      session.role !== "dispatcher"
    ) {
      conditions.push(eq(trips.companyId, session.companyId!));
    } else if (companyId) {
      conditions.push(eq(trips.companyId, parseInt(companyId)));
    }

    if (status) {
      conditions.push(eq(trips.status, status as any));
    }

    if (tripDate) {
      conditions.push(eq(trips.tripDate, tripDate));
    }

    if (driverId) {
      conditions.push(eq(trips.driverId, parseInt(driverId)));
    }

    if (vehicleId) {
      conditions.push(eq(trips.vehicleId, parseInt(vehicleId)));
    }

    const allTrips = conditions.length > 0
      ? await db.query.trips.findMany({
          where: and(...conditions),
          with: {
            route: true,
            vehicle: true,
            driver: true,
            shift: true,
            bookings: {
              with: {
                employee: true,
              },
            },
          },
          orderBy: (trips, { desc }) => [desc(trips.createdAt)],
        })
      : await query;

    return NextResponse.json({ trips: allTrips });
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || "Internal server error" },
      { status: error.message === "Unauthorized" ? 401 : 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const session = await requireRole([
      "super_admin",
      "operations_manager",
      "dispatcher",
    ]);

    const body = await request.json();
    const validatedData = tripSchema.parse(body);
    const bodyData = await request.json().catch(() => ({}));
    
    let companyId = session.companyId;
    if (session.role === "super_admin" || session.role === "operations_manager") {
      companyId = (bodyData as any).companyId ?? session.companyId!;
    }

    const [newTrip] = await (db as any)
      .insert(trips)
      .values({
        companyId,
        routeId: validatedData.routeId ?? null,
        vehicleId: validatedData.vehicleId ?? null,
        driverId: validatedData.driverId ?? null,
        shiftId: validatedData.shiftId ?? null,
        tripDate: validatedData.tripDate,
        scheduledDeparture: validatedData.scheduledDeparture,
        scheduledArrival: validatedData.scheduledArrival || null,
        status: "scheduled",
        capacity: validatedData.capacity,
        currentOccupancy: 0,
        notes: validatedData.notes || null,
        createdBy: session.id,
      })
      .returning();

    // If vehicle assigned, update vehicle status
    if (validatedData.vehicleId) {
      await db
        .update(vehicles)
        .set({ status: "assigned" as any })
        .where(eq(vehicles.id, validatedData.vehicleId));
    }

    return NextResponse.json({ trip: newTrip }, { status: 201 });
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || "Internal server error" },
      { status: error.message.includes("Forbidden") ? 403 : 500 }
    );
  }
}