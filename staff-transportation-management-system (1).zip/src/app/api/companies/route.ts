// @ts-nocheck
import { NextResponse } from "next/server";
import { db } from "@/db";
import { companies } from "@/db/schema";
import { companySchema } from "@/lib/validation";
import { requireAuth, requireRole, requirePermission } from "@/lib/auth";

export async function GET() {
  try {
    await requireAuth();
    const allCompanies = await db.query.companies.findMany();
    return NextResponse.json({ companies: allCompanies });
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || "Internal server error" },
      { status: error.message === "Unauthorized" ? 401 : 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const session = await requireRole([
      "super_admin",
      "operations_manager",
    ]);

    const body = await request.json();
    const validatedData = companySchema.parse(body);

    const [newCompany] = await (db as any)
      .insert(companies)
      .values({
        name: validatedData.name,
        registrationNumber: validatedData.registrationNumber ?? null,
        taxId: validatedData.taxId ?? null,
        email: validatedData.email || null,
        phone: validatedData.phone || null,
        address: validatedData.address || null,
        city: validatedData.city || null,
        country: validatedData.country,
        currency: validatedData.currency,
        status: validatedData.status,
        createdBy: session.id,
      })
      .returning();

    return NextResponse.json({ company: newCompany }, { status: 201 });
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || "Internal server error" },
      { status: error.message.includes("Forbidden") ? 403 : 500 }
    );
  }
}