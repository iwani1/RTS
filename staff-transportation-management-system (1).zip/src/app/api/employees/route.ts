// @ts-nocheck
import { NextResponse } from "next/server";
import { db } from "@/db";
import { employees, users, companies } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { employeeSchema } from "@/lib/validation";
import { requireAuth, requireRole, hashPassword } from "@/lib/auth";

export async function GET(request: Request) {
  try {
    const session = await requireAuth();
    const { searchParams } = new URL(request.url);
    const companyId = searchParams.get("companyId");

    let query = db.query.employees.findMany({
      with: {
        company: true,
        branch: true,
        shift: true,
        user: true,
      },
    });

    // Non-super-admin users can only see their company's employees
    if (session.role !== "super_admin" && session.role !== "operations_manager") {
      query = db.query.employees.findMany({
        where: eq(employees.companyId, session.companyId!),
        with: {
          company: true,
          branch: true,
          shift: true,
          user: true,
        },
      });
    } else if (companyId) {
      query = db.query.employees.findMany({
        where: eq(employees.companyId, parseInt(companyId)),
        with: {
          company: true,
          branch: true,
          shift: true,
          user: true,
        },
      });
    }

    const allEmployees = await query;
    return NextResponse.json({ employees: allEmployees });
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || "Internal server error" },
      { status: error.message === "Unauthorized" ? 401 : 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const session = await requireRole([
      "super_admin",
      "operations_manager",
      "corporate_hr",
    ]);

    const body = await request.json();
    const validatedData = employeeSchema.parse(body);

    // Determine companyId for non-super-admin
    let companyId = validatedData.companyId;
    if (session.role === "corporate_hr" && session.companyId) {
      companyId = session.companyId;
    }

    // Create user account for employee
    const [user] = await db
      .insert(users)
      .values({
        email: validatedData.email || `${validatedData.employeeId}@company.local`,
        phone: validatedData.phone,
        passwordHash: await hashPassword("Employee123!"),
        firstName: validatedData.firstName,
        lastName: validatedData.lastName,
        role: "employee",
        status: "active",
        companyId,
      })
      .returning();

    const [newEmployee] = await (db as any)
      .insert(employees)
      .values({
        userId: user.id,
        companyId,
        branchId: validatedData.branchId ?? null,
        employeeId: validatedData.employeeId,
        firstName: validatedData.firstName,
        lastName: validatedData.lastName,
        email: validatedData.email || null,
        phone: validatedData.phone,
        homeAddress: validatedData.homeAddress || null,
        shiftId: validatedData.shiftId ?? null,
        isTransportEligible: validatedData.isTransportEligible,
        emergencyContactName: validatedData.emergencyContactName || null,
        emergencyContactPhone: validatedData.emergencyContactPhone || null,
        createdBy: session.id,
      })
      .returning();

    return NextResponse.json({ employee: newEmployee }, { status: 201 });
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || "Internal server error" },
      { status: error.message.includes("Forbidden") ? 403 : 500 }
    );
  }
}