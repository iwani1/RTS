// @ts-nocheck
import { NextResponse } from "next/server";
import { db } from "@/db";
import { bookings, employees, trips } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { bookingSchema } from "@/lib/validation";
import { requireAuth, requireRole, generateBookingReference, generateOTP } from "@/lib/auth";

export async function GET(request: Request) {
  try {
    const session = await requireAuth();
    const { searchParams } = new URL(request.url);
    const companyId = searchParams.get("companyId");
    const employeeId = searchParams.get("employeeId");
    const status = searchParams.get("status");
    const tripDate = searchParams.get("tripDate");

    let query = db.query.bookings.findMany({
      with: {
        employee: true,
        trip: true,
        route: true,
      },
      orderBy: (bookings, { desc }) => [desc(bookings.createdAt)],
    });

    // Build where conditions
    const conditions = [];

    if (session.role !== "super_admin" && session.role !== "operations_manager") {
      conditions.push(eq(bookings.companyId, session.companyId!));
    } else if (companyId) {
      conditions.push(eq(bookings.companyId, parseInt(companyId)));
    }

    if (employeeId) {
      conditions.push(eq(bookings.employeeId, parseInt(employeeId)));
    }

    if (status) {
      conditions.push(eq(bookings.status, status as any));
    }

    if (tripDate) {
      conditions.push(eq(bookings.tripDate, tripDate));
    }

    const allBookings = conditions.length > 0
      ? await db.query.bookings.findMany({
          where: and(...conditions),
          with: {
            employee: true,
            trip: true,
            route: true,
          },
          orderBy: (bookings, { desc }) => [desc(bookings.createdAt)],
        })
      : await query;

    return NextResponse.json({ bookings: allBookings });
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || "Internal server error" },
      { status: error.message === "Unauthorized" ? 401 : 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const session = await requireAuth();
    const body = await request.json();
    const validatedData = bookingSchema.parse(body);

    // Determine companyId
    let companyId = session.companyId;
    if (session.role === "super_admin" || session.role === "operations_manager") {
      // For bookings made on behalf, use employee's company
      const employee = await db.query.employees.findFirst({
        where: eq(employees.id, validatedData.employeeId),
      });
      if (employee) {
        companyId = employee.companyId;
      }
    }

    // Check for duplicate booking (same employee, same date, same type)
    const existingBooking = await db.query.bookings.findFirst({
      where: and(
        eq(bookings.employeeId, validatedData.employeeId),
        eq(bookings.tripDate, validatedData.tripDate),
        eq(bookings.status, "confirmed" as any)
      ),
    });

    if (existingBooking) {
      return NextResponse.json(
        { error: "Employee already has a confirmed booking for this date" },
        { status: 409 }
      );
    }

    const bookingReference = generateBookingReference();
    const otpCode = generateOTP();
    const otpExpiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours

    const [newBooking] = await (db as any)
      .insert(bookings)
      .values({
        bookingReference,
        employeeId: validatedData.employeeId,
        companyId,
        tripId: validatedData.tripId ?? null,
        routeId: validatedData.routeId ?? null,
        bookingType: validatedData.bookingType,
        status: "pending",
        pickupLocation: validatedData.pickupLocation,
        pickupLatitude: validatedData.pickupLatitude
          ? parseFloat(validatedData.pickupLatitude)
          : null,
        pickupLongitude: validatedData.pickupLongitude
          ? parseFloat(validatedData.pickupLongitude)
          : null,
        dropoffLocation: validatedData.dropoffLocation,
        dropoffLatitude: validatedData.dropoffLatitude
          ? parseFloat(validatedData.dropoffLatitude)
          : null,
        dropoffLongitude: validatedData.dropoffLongitude
          ? parseFloat(validatedData.dropoffLongitude)
          : null,
        scheduledPickupTime: validatedData.scheduledPickupTime,
        scheduledDropoffTime: validatedData.scheduledDropoffTime || null,
        tripDate: validatedData.tripDate,
        isRecurring: validatedData.isRecurring,
        otpCode,
        otpExpiresAt,
        notes: validatedData.notes || null,
        createdBy: session.id,
      })
      .returning();

    return NextResponse.json({ booking: newBooking }, { status: 201 });
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || "Internal server error" },
      { status: error.message.includes("Forbidden") ? 403 : 500 }
    );
  }
}