// @ts-nocheck
import { NextResponse } from "next/server";
import { db } from "@/db";
import { vehicles } from "@/db/schema";
import { eq } from "drizzle-orm";
import { vehicleSchema } from "@/lib/validation";
import { requireAuth, requireRole } from "@/lib/auth";

export async function GET(request: Request) {
  try {
    const session = await requireAuth();
    const { searchParams } = new URL(request.url);
    const companyId = searchParams.get("companyId");

    let query = db.query.vehicles.findMany();

    if (session.role !== "super_admin" && session.role !== "operations_manager" && session.role !== "fleet_manager") {
      query = db.query.vehicles.findMany({
        where: eq(vehicles.companyId, session.companyId!),
      });
    } else if (companyId) {
      query = db.query.vehicles.findMany({
        where: eq(vehicles.companyId, parseInt(companyId)),
      });
    }

    const allVehicles = await query;
    return NextResponse.json({ vehicles: allVehicles });
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || "Internal server error" },
      { status: error.message === "Unauthorized" ? 401 : 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const session = await requireRole([
      "super_admin",
      "operations_manager",
      "fleet_manager",
    ]);

    const body = await request.json();
    const validatedData = vehicleSchema.parse(body);

    let companyId = validatedData.companyId;
    if (
      (session.role === "fleet_manager" || session.role === "operations_manager") &&
      session.companyId
    ) {
      companyId = session.companyId;
    }

    const [newVehicle] = await (db as any)
      .insert(vehicles)
      .values({
        companyId,
        registrationNumber: validatedData.registrationNumber,
        make: validatedData.make,
        model: validatedData.model,
        year: validatedData.year,
        vehicleType: validatedData.vehicleType,
        fuelType: validatedData.fuelType,
        seatingCapacity: validatedData.seatingCapacity,
        standingCapacity: validatedData.standingCapacity,
        color: validatedData.color || null,
        ownershipStatus: validatedData.ownershipStatus,
        status: validatedData.status,
        assignedDriverId: validatedData.assignedDriverId ?? null,
        registrationExpiry: validatedData.registrationExpiry
          ? new Date(validatedData.registrationExpiry)
          : null,
        insuranceExpiry: validatedData.insuranceExpiry
          ? new Date(validatedData.insuranceExpiry)
          : null,
        roadworthinessExpiry: validatedData.roadworthinessExpiry
          ? new Date(validatedData.roadworthinessExpiry)
          : null,
        createdBy: session.id,
      })
      .returning();

    return NextResponse.json({ vehicle: newVehicle }, { status: 201 });
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || "Internal server error" },
      { status: error.message.includes("Forbidden") ? 403 : 500 }
    );
  }
}