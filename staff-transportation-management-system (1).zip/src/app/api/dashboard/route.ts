import { NextResponse } from "next/server";
import { db } from "@/db";
import { companies, employees, vehicles, drivers, trips, bookings, incidents } from "@/db/schema";
import { eq, count } from "drizzle-orm";
import { requireAuth } from "@/lib/auth";

export async function GET(request: Request) {
  try {
    const session = await requireAuth();
    const { searchParams } = new URL(request.url);
    const companyId = searchParams.get("companyId");

    const companyFilter = session.companyId
      ? eq(companies.id, session.companyId)
      : undefined;

    // Total companies
    const totalCompanies = await db
      .select({ count: count() })
      .from(companies)
      .where(companyFilter ? companyFilter : undefined);

    // Total employees
    const totalEmployees = await db
      .select({ count: count() })
      .from(employees)
      .where(
        session.companyId ? eq(employees.companyId, session.companyId) : undefined
      );

    // Total vehicles
    const totalVehicles = await db
      .select({ count: count() })
      .from(vehicles)
      .where(
        session.companyId ? eq(vehicles.companyId, session.companyId) : undefined
      );

    // Total drivers
    const totalDrivers = await db
      .select({ count: count() })
      .from(drivers)
      .where(
        session.companyId ? eq(drivers.companyId, session.companyId) : undefined
      );

    // Total trips
    const totalTrips = await db
      .select({ count: count() })
      .from(trips)
      .where(
        session.companyId ? eq(trips.companyId, session.companyId) : undefined
      );

    // Total bookings
    const totalBookings = await db
      .select({ count: count() })
      .from(bookings)
      .where(
        session.companyId ? eq(bookings.companyId, session.companyId) : undefined
      );

    // Trips by status
    const tripsByStatus = await db
      .select({
        status: trips.status,
        count: count(),
      })
      .from(trips)
      .where(
        session.companyId ? eq(trips.companyId, session.companyId) : undefined
      )
      .groupBy(trips.status);

    // Bookings by status
    const bookingsByStatus = await db
      .select({
        status: bookings.status,
        count: count(),
      })
      .from(bookings)
      .where(
        session.companyId ? eq(bookings.companyId, session.companyId) : undefined
      )
      .groupBy(bookings.status);

    // Vehicles by status
    const vehiclesByStatus = await db
      .select({
        status: vehicles.status,
        count: count(),
      })
      .from(vehicles)
      .where(
        session.companyId ? eq(vehicles.companyId, session.companyId) : undefined
      )
      .groupBy(vehicles.status);

    // Recent trips
    const recentTrips = await db.query.trips.findMany({
      where: session.companyId ? eq(trips.companyId, session.companyId) : undefined,
      with: {
        vehicle: true,
        driver: true,
        bookings: {
          with: {
            employee: true,
          },
        },
      },
      orderBy: (trips, { desc }) => [desc(trips.createdAt)],
      limit: 10,
    });

    return NextResponse.json({
      stats: {
        totalCompanies: totalCompanies[0]?.count || 0,
        totalEmployees: totalEmployees[0]?.count || 0,
        totalVehicles: totalVehicles[0]?.count || 0,
        totalDrivers: totalDrivers[0]?.count || 0,
        totalTrips: totalTrips[0]?.count || 0,
        totalBookings: totalBookings[0]?.count || 0,
      },
      tripsByStatus,
      bookingsByStatus,
      vehiclesByStatus,
      recentTrips,
    });
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || "Internal server error" },
      { status: error.message === "Unauthorized" ? 401 : 500 }
    );
  }
}