// @ts-nocheck
import { NextResponse } from "next/server";
import { db } from "@/db";
import { drivers, users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { driverSchema } from "@/lib/validation";
import { requireAuth, requireRole, hashPassword } from "@/lib/auth";

export async function GET(request: Request) {
  try {
    const session = await requireAuth();
    const { searchParams } = new URL(request.url);
    const companyId = searchParams.get("companyId");

    let query = db.query.drivers.findMany({
      with: {
        user: true,
        company: true,
      },
    });

    if (session.role !== "super_admin" && session.role !== "operations_manager" && session.role !== "fleet_manager") {
      query = db.query.drivers.findMany({
        where: eq(drivers.companyId, session.companyId!),
        with: {
          user: true,
          company: true,
        },
      });
    } else if (companyId) {
      query = db.query.drivers.findMany({
        where: eq(drivers.companyId, parseInt(companyId)),
        with: {
          user: true,
          company: true,
        },
      });
    }

    const allDrivers = await query;
    return NextResponse.json({ drivers: allDrivers });
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || "Internal server error" },
      { status: error.message === "Unauthorized" ? 401 : 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const session = await requireRole([
      "super_admin",
      "operations_manager",
      "fleet_manager",
    ]);

    const body = await request.json();
    const validatedData = driverSchema.parse(body);

    let companyId = validatedData.companyId;
    if (
      (session.role === "fleet_manager" || session.role === "operations_manager") &&
      session.companyId
    ) {
      companyId = session.companyId;
    }

    // Create user account for driver
    const [user] = await db
      .insert(users)
      .values({
        email: validatedData.email || `${validatedData.employeeId}@driver.local`,
        phone: validatedData.phone,
        passwordHash: await hashPassword("Driver123!"),
        firstName: validatedData.firstName,
        lastName: validatedData.lastName,
        role: "driver",
        status: "active",
        companyId,
      })
      .returning();

    const [newDriver] = await (db as any)
      .insert(drivers)
      .values({
        userId: user.id,
        companyId,
        employeeId: validatedData.employeeId,
        firstName: validatedData.firstName,
        lastName: validatedData.lastName,
        email: validatedData.email || null,
        phone: validatedData.phone,
        licenseNumber: validatedData.licenseNumber,
        licenseExpiry: validatedData.licenseExpiry
          ? new Date(validatedData.licenseExpiry)
          : null,
        licenseCategory: validatedData.licenseCategory || null,
        hireDate: new Date(validatedData.hireDate),
        emergencyContactName: validatedData.emergencyContactName || null,
        emergencyContactPhone: validatedData.emergencyContactPhone || null,
        createdBy: session.id,
      })
      .returning();

    return NextResponse.json({ driver: newDriver }, { status: 201 });
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || "Internal server error" },
      { status: error.message.includes("Forbidden") ? 403 : 500 }
    );
  }
}