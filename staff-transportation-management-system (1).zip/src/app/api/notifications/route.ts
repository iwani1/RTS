import { NextResponse } from "next/server";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireAuth } from "@/lib/auth";

export async function GET(request: Request) {
  try {
    const session = await requireAuth();
    const { searchParams } = new URL(request.url);
    const unreadOnly = searchParams.get("unread") === "true";
    const limit = parseInt(searchParams.get("limit") || "20");

    const conditions = [eq(notifications.userId, session.id)];
    if (unreadOnly) {
      conditions.push(eq(notifications.isRead, false));
    }

    const allNotifications = await db.query.notifications.findMany({
      where: eq(notifications.userId, session.id),
      orderBy: (notifications, { desc }) => [desc(notifications.createdAt)],
      limit,
    });

    return NextResponse.json({ notifications: allNotifications });
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || "Internal server error" },
      { status: error.message === "Unauthorized" ? 401 : 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const session = await requireAuth();
    const body = await request.json();

    const [notification] = await (db as any)
      .insert(notifications)
      .values({
        userId: session.id,
        companyId: session.companyId ?? null,
        title: body.title,
        message: body.message,
        type: body.type || "info",
        isRead: false,
        data: body.data || {},
      })
      .returning();

    return NextResponse.json({ notification }, { status: 201 });
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || "Internal server error" },
      { status: error.message === "Unauthorized" ? 401 : 500 }
    );
  }
}

export async function PATCH(request: Request) {
  try {
    const session = await requireAuth();
    const body = await request.json();
    const { notificationId, isRead } = body;

    await db
      .update(notifications)
      .set({
        isRead,
        readAt: isRead ? new Date() : null,
      })
      .where(eq(notifications.id, notificationId));

    return NextResponse.json({ success: true });
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || "Internal server error" },
      { status: error.message === "Unauthorized" ? 401 : 500 }
    );
  }
}