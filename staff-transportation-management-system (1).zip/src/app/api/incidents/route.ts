// @ts-nocheck
import { NextResponse } from "next/server";
import { db } from "@/db";
import { incidents } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireAuth, requireRole } from "@/lib/auth";

export async function GET(request: Request) {
  try {
    const session = await requireAuth();
    const { searchParams } = new URL(request.url);
    const companyId = searchParams.get("companyId");

    let query = db.query.incidents.findMany({
      with: {
        trip: true,
        vehicle: true,
        driver: true,
      },
      orderBy: (incidents, { desc }) => [desc(incidents.createdAt)],
    });

    if (session.role !== "super_admin" && session.role !== "operations_manager") {
      query = db.query.incidents.findMany({
        where: eq(incidents.companyId, session.companyId!),
        with: {
          trip: true,
          vehicle: true,
          driver: true,
        },
        orderBy: (incidents, { desc }) => [desc(incidents.createdAt)],
      });
    } else if (companyId) {
      query = db.query.incidents.findMany({
        where: eq(incidents.companyId, parseInt(companyId)),
        with: {
          trip: true,
          vehicle: true,
          driver: true,
        },
        orderBy: (incidents, { desc }) => [desc(incidents.createdAt)],
      });
    }

    const allIncidents = await query;
    return NextResponse.json({ incidents: allIncidents });
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || "Internal server error" },
      { status: error.message === "Unauthorized" ? 401 : 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const session = await requireAuth();
    const body = await request.json();

    const companyId = session.companyId!;

    const [incident] = await (db as any)
      .insert(incidents)
      .values({
        companyId,
        tripId: body.tripId ?? null,
        vehicleId: body.vehicleId ?? null,
        driverId: body.driverId ?? null,
        title: body.title,
        description: body.description,
        severity: body.severity || "medium",
        incidentType: body.incidentType,
        location: body.location || null,
        latitude: body.latitude ? parseFloat(body.latitude) : null,
        longitude: body.longitude ? parseFloat(body.longitude) : null,
        reportedBy: session.id,
        status: "open",
      })
      .returning();

    return NextResponse.json({ incident }, { status: 201 });
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || "Internal server error" },
      { status: error.message === "Unauthorized" ? 401 : 500 }
    );
  }
}