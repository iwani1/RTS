// @ts-nocheck
import { NextResponse } from "next/server";
import { db } from "@/db";
import { shifts } from "@/db/schema";
import { eq } from "drizzle-orm";
import { shiftSchema } from "@/lib/validation";
import { requireAuth, requireRole } from "@/lib/auth";

export async function GET(request: Request) {
  try {
    const session = await requireAuth();
    const { searchParams } = new URL(request.url);
    const companyId = searchParams.get("companyId");

    let query = db.query.shifts.findMany();

    if (
      session.role !== "super_admin" &&
      session.role !== "operations_manager"
    ) {
      query = db.query.shifts.findMany({
        where: eq(shifts.companyId, session.companyId!),
      });
    } else if (companyId) {
      query = db.query.shifts.findMany({
        where: eq(shifts.companyId, parseInt(companyId)),
      });
    }

    const allShifts = await query;
    return NextResponse.json({ shifts: allShifts });
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || "Internal server error" },
      { status: error.message === "Unauthorized" ? 401 : 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const session = await requireRole([
      "super_admin",
      "operations_manager",
    ]);

    const body = await request.json();
    const validatedData = shiftSchema.parse(body);

    let companyId = validatedData.companyId;
    if (
      session.role === "operations_manager" &&
      session.companyId
    ) {
      companyId = session.companyId;
    }

    const [newShift] = await (db as any)
      .insert(shifts)
      .values({
        companyId,
        name: validatedData.name,
        shiftType: validatedData.shiftType,
        startTime: validatedData.startTime,
        endTime: validatedData.endTime,
        reportingTime: validatedData.reportingTime,
        daysOfWeek: validatedData.daysOfWeek,
        isActive: validatedData.isActive,
      })
      .returning();

    return NextResponse.json({ shift: newShift }, { status: 201 });
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || "Internal server error" },
      { status: error.message.includes("Forbidden") ? 403 : 500 }
    );
  }
}