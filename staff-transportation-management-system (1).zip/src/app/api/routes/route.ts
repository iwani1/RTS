// @ts-nocheck
import { NextResponse } from "next/server";
import { db } from "@/db";
import { routes } from "@/db/schema";
import { eq } from "drizzle-orm";
import { routeSchema } from "@/lib/validation";
import { requireAuth, requireRole } from "@/lib/auth";

export async function GET(request: Request) {
  try {
    const session = await requireAuth();
    const { searchParams } = new URL(request.url);
    const companyId = searchParams.get("companyId");

    let query = db.query.routes.findMany({
      with: {
        stops: true,
        shift: true,
      },
    });

    if (
      session.role !== "super_admin" &&
      session.role !== "operations_manager" &&
      session.role !== "dispatcher"
    ) {
      query = db.query.routes.findMany({
        where: eq(routes.companyId, session.companyId!),
        with: {
          stops: true,
          shift: true,
        },
      });
    } else if (companyId) {
      query = db.query.routes.findMany({
        where: eq(routes.companyId, parseInt(companyId)),
        with: {
          stops: true,
          shift: true,
        },
      });
    }

    const allRoutes = await query;
    return NextResponse.json({ routes: allRoutes });
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || "Internal server error" },
      { status: error.message === "Unauthorized" ? 401 : 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const session = await requireRole([
      "super_admin",
      "operations_manager",
      "dispatcher",
    ]);

    const body = await request.json();
    const validatedData = routeSchema.parse(body);

    let companyId = validatedData.companyId;
    if (
      (session.role === "operations_manager" || session.role === "dispatcher") &&
      session.companyId
    ) {
      companyId = session.companyId;
    }

    const [newRoute] = await (db as any)
      .insert(routes)
      .values({
        companyId,
        name: validatedData.name,
        code: validatedData.code,
        description: validatedData.description || null,
        shiftId: validatedData.shiftId ?? null,
        estimatedDurationMinutes: validatedData.estimatedDurationMinutes ?? null,
        distanceKm: validatedData.distanceKm
          ? parseFloat(validatedData.distanceKm)
          : null,
        createdBy: session.id,
      })
      .returning();

    return NextResponse.json({ route: newRoute }, { status: 201 });
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || "Internal server error" },
      { status: error.message.includes("Forbidden") ? 403 : 500 }
    );
  }
}