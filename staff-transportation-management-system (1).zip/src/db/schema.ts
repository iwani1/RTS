import {
  pgTable,
  serial,
  text,
  varchar,
  timestamp,
  boolean,
  integer,
  decimal,
  date,
  time,
  pgEnum,
  unique,
  index,
  foreignKey,
  jsonb,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

// ============================================================================
// ENUMS
// ============================================================================

export const userRoleEnum = pgEnum("user_role", [
  "super_admin",
  "operations_manager",
  "dispatcher",
  "fleet_manager",
  "finance_officer",
  "corporate_hr",
  "driver",
  "employee",
]);

export const userStatusEnum = pgEnum("user_status", [
  "active",
  "inactive",
  "pending",
  "suspended",
]);

export const companyStatusEnum = pgEnum("company_status", [
  "active",
  "inactive",
  "suspended",
]);

export const vehicleStatusEnum = pgEnum("vehicle_status", [
  "available",
  "assigned",
  "on_trip",
  "under_maintenance",
  "out_of_service",
]);

export const vehicleTypeEnum = pgEnum("vehicle_type", [
  "sedan",
  "suv",
  "minibus",
  "bus",
  "van",
  "coaster",
]);

export const fuelTypeEnum = pgEnum("fuel_type", ["petrol", "diesel", "electric", "hybrid"]);

export const tripStatusEnum = pgEnum("trip_status", [
  "scheduled",
  "dispatched",
  "in_progress",
  "completed",
  "cancelled",
  "delayed",
]);

export const bookingStatusEnum = pgEnum("booking_status", [
  "pending",
  "confirmed",
  "assigned",
  "picked_up",
  "dropped_off",
  "cancelled",
  "no_show",
  "waiting_list",
]);

export const shiftTypeEnum = pgEnum("shift_type", ["morning", "afternoon", "evening", "night"]);

export const bookingTypeEnum = pgEnum("booking_type", [
  "one_time",
  "daily",
  "weekly",
  "monthly",
]);

export const paymentStatusEnum = pgEnum("payment_status", [
  "pending",
  "paid",
  "partially_paid",
  "failed",
  "refunded",
]);

export const invoiceStatusEnum = pgEnum("invoice_status", [
  "draft",
  "sent",
  "paid",
  "overdue",
  "cancelled",
]);

export const incidentSeverityEnum = pgEnum("incident_severity", [
  "low",
  "medium",
  "high",
  "critical",
]);

export const notificationTypeEnum = pgEnum("notification_type", [
  "info",
  "warning",
  "alert",
  "success",
  "error",
]);

// ============================================================================
// TABLES
// ============================================================================

export const roles = pgTable(
  "roles",
  {
    id: serial("id").primaryKey(),
    name: varchar("name", { length: 50 }).notNull().unique(),
    description: text("description"),
    isSystem: boolean("is_system").default(false).notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (table) => ({
    nameIdx: index("roles_name_idx").on(table.name),
  })
);

export const permissions = pgTable(
  "permissions",
  {
    id: serial("id").primaryKey(),
    name: varchar("name", { length: 100 }).notNull().unique(),
    resource: varchar("resource", { length: 50 }).notNull(),
    action: varchar("action", { length: 50 }).notNull(),
    description: text("description"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => ({
    resourceActionIdx: index("permissions_resource_action_idx").on(
      table.resource,
      table.action
    ),
  })
);

export const rolePermissions = pgTable(
  "role_permissions",
  {
    id: serial("id").primaryKey(),
    roleId: integer("role_id")
      .notNull()
      .references(() => roles.id, { onDelete: "cascade" }),
    permissionId: integer("permission_id")
      .notNull()
      .references(() => permissions.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => ({
    rolePermissionIdx: index("role_permissions_role_perm_idx").on(
      table.roleId,
      table.permissionId
    ),
  })
);

export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    email: varchar("email", { length: 255 }).notNull().unique(),
    phone: varchar("phone", { length: 20 }),
    passwordHash: varchar("password_hash", { length: 255 }).notNull(),
    firstName: varchar("first_name", { length: 100 }).notNull(),
    lastName: varchar("last_name", { length: 100 }).notNull(),
    role: userRoleEnum("role").notNull().default("employee"),
    status: userStatusEnum("status").default("pending").notNull(),
    emailVerified: boolean("email_verified").default(false).notNull(),
    phoneVerified: boolean("phone_verified").default(false).notNull(),
    twoFactorEnabled: boolean("two_factor_enabled").default(false).notNull(),
    twoFactorSecret: varchar("two_factor_secret", { length: 255 }),
    profileImageUrl: varchar("profile_image_url", { length: 500 }),
    companyId: integer("company_id"),
    lastLoginAt: timestamp("last_login_at"),
    resetToken: varchar("reset_token", { length: 255 }),
    resetTokenExpires: timestamp("reset_token_expires"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
    createdBy: integer("created_by"),
  },
  (table) => ({
    emailIdx: index("users_email_idx").on(table.email),
    companyIdx: index("users_company_idx").on(table.companyId),
    roleIdx: index("users_role_idx").on(table.role),
    statusIdx: index("users_status_idx").on(table.status),
  })
);

export const userRoles = pgTable(
  "user_roles",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    roleId: integer("role_id")
      .notNull()
      .references(() => roles.id, { onDelete: "cascade" }),
    assignedAt: timestamp("assigned_at").defaultNow().notNull(),
    assignedBy: integer("assigned_by"),
  },
  (table) => ({
    userRoleIdx: index("user_roles_user_role_idx").on(table.userId, table.roleId),
  })
);

export const companies = pgTable(
  "companies",
  {
    id: serial("id").primaryKey(),
    name: varchar("name", { length: 255 }).notNull(),
    registrationNumber: varchar("registration_number", { length: 100 }),
    taxId: varchar("tax_id", { length: 100 }),
    email: varchar("email", { length: 255 }),
    phone: varchar("phone", { length: 50 }),
    address: text("address"),
    city: varchar("city", { length: 100 }),
    country: varchar("country", { length: 100 }).default("Ghana"),
    currency: varchar("currency", { length: 3 }).default("GHS"),
    status: companyStatusEnum("status").default("active").notNull(),
    subscriptionPlan: varchar("subscription_plan", { length: 50 }).default("basic"),
    logoUrl: varchar("logo_url", { length: 500 }),
    settings: jsonb("settings").$type<Record<string, unknown>>().default({}),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
    createdBy: integer("created_by"),
  },
  (table) => ({
    nameIdx: index("companies_name_idx").on(table.name),
    statusIdx: index("companies_status_idx").on(table.status),
  })
);

export const companyBranches = pgTable(
  "company_branches",
  {
    id: serial("id").primaryKey(),
    companyId: integer("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    name: varchar("name", { length: 255 }).notNull(),
    address: text("address").notNull(),
    city: varchar("city", { length: 100 }),
    phone: varchar("phone", { length: 50 }),
    email: varchar("email", { length: 255 }),
    isHeadquarters: boolean("is_headquarters").default(false).notNull(),
    latitude: decimal("latitude", { precision: 10, scale: 8 }),
    longitude: decimal("longitude", { precision: 11, scale: 8 }),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (table) => ({
    companyIdx: index("company_branches_company_idx").on(table.companyId),
  })
);

export const shifts = pgTable(
  "shifts",
  {
    id: serial("id").primaryKey(),
    companyId: integer("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    name: varchar("name", { length: 100 }).notNull(),
    shiftType: shiftTypeEnum("shift_type").notNull(),
    startTime: time("start_time").notNull(),
    endTime: time("end_time").notNull(),
    reportingTime: time("reporting_time").notNull(),
    daysOfWeek: jsonb("days_of_week").$type<number[]>().default([1, 2, 3, 4, 5]),
    isActive: boolean("is_active").default(true).notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => ({
    companyIdx: index("shifts_company_idx").on(table.companyId),
  })
);

export const employees = pgTable(
  "employees",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
    companyId: integer("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    branchId: integer("branch_id").references(() => companyBranches.id, {
      onDelete: "set null",
    }),
    employeeId: varchar("employee_id", { length: 50 }).notNull(),
    firstName: varchar("first_name", { length: 100 }).notNull(),
    lastName: varchar("last_name", { length: 100 }).notNull(),
    email: varchar("email", { length: 255 }),
    phone: varchar("phone", { length: 50 }).notNull(),
    homeAddress: text("home_address"),
    homeLatitude: decimal("home_latitude", { precision: 10, scale: 8 }),
    homeLongitude: decimal("home_longitude", { precision: 11, scale: 8 }),
    officeAddress: text("office_address"),
    officeLatitude: decimal("office_latitude", { precision: 10, scale: 8 }),
    officeLongitude: decimal("office_longitude", { precision: 11, scale: 8 }),
    shiftId: integer("shift_id").references(() => shifts.id, { onDelete: "set null" }),
    isTransportEligible: boolean("is_transport_eligible").default(true).notNull(),
    emergencyContactName: varchar("emergency_contact_name", { length: 200 }),
    emergencyContactPhone: varchar("emergency_contact_phone", { length: 50 }),
    profileImageUrl: varchar("profile_image_url", { length: 500 }),
    status: userStatusEnum("status").default("active").notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
    createdBy: integer("created_by"),
  },
  (table) => ({
    employeeIdIdx: index("employees_employee_id_idx").on(table.employeeId),
    companyIdx: index("employees_company_idx").on(table.companyId),
    userIdx: index("employees_user_idx").on(table.userId),
  })
);

export const employeeShifts = pgTable(
  "employee_shifts",
  {
    id: serial("id").primaryKey(),
    employeeId: integer("employee_id")
      .notNull()
      .references(() => employees.id, { onDelete: "cascade" }),
    shiftId: integer("shift_id")
      .notNull()
      .references(() => shifts.id, { onDelete: "cascade" }),
    effectiveFrom: date("effective_from").notNull(),
    effectiveTo: date("effective_to"),
    isActive: boolean("is_active").default(true).notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => ({
    employeeIdx: index("employee_shifts_employee_idx").on(table.employeeId),
    shiftIdx: index("employee_shifts_shift_idx").on(table.shiftId),
  })
);

export const addresses = pgTable(
  "addresses",
  {
    id: serial("id").primaryKey(),
    employeeId: integer("employee_id")
      .notNull()
      .references(() => employees.id, { onDelete: "cascade" }),
    type: varchar("type", { length: 50 }).notNull(), // home, office, emergency
    label: varchar("label", { length: 100 }),
    street: text("street"),
    city: varchar("city", { length: 100 }),
    state: varchar("state", { length: 100 }),
    country: varchar("country", { length: 100 }),
    postalCode: varchar("postal_code", { length: 20 }),
    latitude: decimal("latitude", { precision: 10, scale: 8 }),
    longitude: decimal("longitude", { precision: 11, scale: 8 }),
    isPrimary: boolean("is_primary").default(false).notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => ({
    employeeIdx: index("addresses_employee_idx").on(table.employeeId),
  })
);

export const vehicles = pgTable(
  "vehicles",
  {
    id: serial("id").primaryKey(),
    companyId: integer("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    registrationNumber: varchar("registration_number", { length: 50 }).notNull().unique(),
    make: varchar("make", { length: 100 }).notNull(),
    model: varchar("model", { length: 100 }).notNull(),
    year: integer("year").notNull(),
    vehicleType: vehicleTypeEnum("vehicle_type").notNull(),
    fuelType: fuelTypeEnum("fuel_type").notNull().default("diesel"),
    seatingCapacity: integer("seating_capacity").notNull(),
    standingCapacity: integer("standing_capacity").default(0),
    color: varchar("color", { length: 50 }),
    chassisNumber: varchar("chassis_number", { length: 100 }),
    engineNumber: varchar("engine_number", { length: 100 }),
    photoUrl: varchar("photo_url", { length: 500 }),
    registrationExpiry: date("registration_expiry"),
    insuranceExpiry: date("insurance_expiry"),
    roadworthinessExpiry: date("roadworthiness_expiry"),
    ownershipStatus: varchar("ownership_status", { length: 50 }).default("owned"),
    assignedDriverId: integer("assigned_driver_id"),
    status: vehicleStatusEnum("status").default("available").notNull(),
    currentMileage: integer("current_mileage").default(0),
    fuelConsumptionPerKm: decimal("fuel_consumption_per_km", { precision: 6, scale: 2 }),
    lastServiceDate: date("last_service_date"),
    nextServiceDueDate: date("next_service_due_date"),
    notes: text("notes"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
    createdBy: integer("created_by"),
  },
  (table) => ({
    regIdx: index("vehicles_reg_idx").on(table.registrationNumber),
    companyIdx: index("vehicles_company_idx").on(table.companyId),
    statusIdx: index("vehicles_status_idx").on(table.status),
    driverIdx: index("vehicles_driver_idx").on(table.assignedDriverId),
  })
);

export const drivers = pgTable(
  "drivers",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
    companyId: integer("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    employeeId: varchar("employee_id", { length: 50 }).notNull().unique(),
    firstName: varchar("first_name", { length: 100 }).notNull(),
    lastName: varchar("last_name", { length: 100 }).notNull(),
    email: varchar("email", { length: 255 }),
    phone: varchar("phone", { length: 50 }).notNull(),
    licenseNumber: varchar("license_number", { length: 100 }).notNull(),
    licenseExpiry: date("license_expiry").notNull(),
    licenseCategory: varchar("license_category", { length: 20 }),
    dateOfBirth: date("date_of_birth"),
    hireDate: date("hire_date").notNull(),
    emergencyContactName: varchar("emergency_contact_name", { length: 200 }),
    emergencyContactPhone: varchar("emergency_contact_phone", { length: 50 }),
    profileImageUrl: varchar("profile_image_url", { length: 500 }),
    isAvailable: boolean("is_available").default(true).notNull(),
    status: userStatusEnum("status").default("active").notNull(),
    rating: decimal("rating", { precision: 3, scale: 2 }).default("5.00"),
    totalTrips: integer("total_trips").default(0),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
    createdBy: integer("created_by"),
  },
  (table) => ({
    employeeIdIdx: index("drivers_employee_id_idx").on(table.employeeId),
    licenseIdx: index("drivers_license_idx").on(table.licenseNumber),
    companyIdx: index("drivers_company_idx").on(table.companyId),
    userIdx: index("drivers_user_idx").on(table.userId),
  })
);

export const driverShifts = pgTable(
  "driver_shifts",
  {
    id: serial("id").primaryKey(),
    driverId: integer("driver_id")
      .notNull()
      .references(() => drivers.id, { onDelete: "cascade" }),
    shiftId: integer("shift_id")
      .notNull()
      .references(() => shifts.id, { onDelete: "cascade" }),
    effectiveFrom: date("effective_from").notNull(),
    effectiveTo: date("effective_to"),
    isActive: boolean("is_active").default(true).notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => ({
    driverIdx: index("driver_shifts_driver_idx").on(table.driverId),
    shiftIdx: index("driver_shifts_shift_idx").on(table.shiftId),
  })
);

export const routes = pgTable(
  "routes",
  {
    id: serial("id").primaryKey(),
    companyId: integer("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    name: varchar("name", { length: 255 }).notNull(),
    code: varchar("code", { length: 20 }).notNull(),
    description: text("description"),
    shiftId: integer("shift_id").references(() => shifts.id, { onDelete: "set null" }),
    isActive: boolean("is_active").default(true).notNull(),
    estimatedDurationMinutes: integer("estimated_duration_minutes"),
    distanceKm: decimal("distance_km", { precision: 8, scale: 2 }),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
    createdBy: integer("created_by"),
  },
  (table) => ({
    companyIdx: index("routes_company_idx").on(table.companyId),
    codeIdx: index("routes_code_idx").on(table.code),
    shiftIdx: index("routes_shift_idx").on(table.shiftId),
  })
);

export const routeStops = pgTable(
  "route_stops",
  {
    id: serial("id").primaryKey(),
    routeId: integer("route_id")
      .notNull()
      .references(() => routes.id, { onDelete: "cascade" }),
    stopSequence: integer("stop_sequence").notNull(),
    name: varchar("name", { length: 255 }).notNull(),
    address: text("address").notNull(),
    latitude: decimal("latitude", { precision: 10, scale: 8 }).notNull(),
    longitude: decimal("longitude", { precision: 11, scale: 8 }).notNull(),
    estimatedArrivalOffset: integer("estimated_arrival_offset_minutes").default(0),
    isPickup: boolean("is_pickup").default(true).notNull(),
    isDropoff: boolean("is_dropoff").default(false).notNull(),
    notes: text("notes"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => ({
    routeIdx: index("route_stops_route_idx").on(table.routeId),
    sequenceIdx: index("route_stops_sequence_idx").on(table.routeId, table.stopSequence),
  })
);

export const trips = pgTable(
  "trips",
  {
    id: serial("id").primaryKey(),
    companyId: integer("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    routeId: integer("route_id").references(() => routes.id, { onDelete: "set null" }),
    vehicleId: integer("vehicle_id").references(() => vehicles.id, { onDelete: "set null" }),
    driverId: integer("driver_id").references(() => drivers.id, { onDelete: "set null" }),
    shiftId: integer("shift_id").references(() => shifts.id, { onDelete: "set null" }),
    tripDate: date("trip_date").notNull(),
    scheduledDeparture: time("scheduled_departure").notNull(),
    actualDeparture: time("actual_departure"),
    scheduledArrival: time("scheduled_arrival"),
    actualArrival: time("actual_arrival"),
    status: tripStatusEnum("status").default("scheduled").notNull(),
    capacity: integer("capacity").notNull(),
    currentOccupancy: integer("current_occupancy").default(0),
    notes: text("notes"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
    createdBy: integer("created_by"),
  },
  (table) => ({
    companyIdx: index("trips_company_idx").on(table.companyId),
    routeIdx: index("trips_route_idx").on(table.routeId),
    vehicleIdx: index("trips_vehicle_idx").on(table.vehicleId),
    driverIdx: index("trips_driver_idx").on(table.driverId),
    dateIdx: index("trips_date_idx").on(table.tripDate),
    statusIdx: index("trips_status_idx").on(table.status),
  })
);

export const tripAssignments = pgTable(
  "trip_assignments",
  {
    id: serial("id").primaryKey(),
    tripId: integer("trip_id")
      .notNull()
      .references(() => trips.id, { onDelete: "cascade" }),
    vehicleId: integer("vehicle_id").references(() => vehicles.id, { onDelete: "set null" }),
    driverId: integer("driver_id").references(() => drivers.id, { onDelete: "set null" }),
    assignedAt: timestamp("assigned_at").defaultNow().notNull(),
    assignedBy: integer("assigned_by"),
    notes: text("notes"),
  },
  (table) => ({
    tripIdx: index("trip_assignments_trip_idx").on(table.tripId),
  })
);

export const bookings = pgTable(
  "bookings",
  {
    id: serial("id").primaryKey(),
    bookingReference: varchar("booking_reference", { length: 50 }).notNull().unique(),
    employeeId: integer("employee_id")
      .notNull()
      .references(() => employees.id, { onDelete: "cascade" }),
    companyId: integer("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    tripId: integer("trip_id").references(() => trips.id, { onDelete: "set null" }),
    routeId: integer("route_id").references(() => routes.id, { onDelete: "set null" }),
    bookingType: bookingTypeEnum("booking_type").default("one_time").notNull(),
    status: bookingStatusEnum("status").default("pending").notNull(),
    pickupLocation: text("pickup_location").notNull(),
    pickupLatitude: decimal("pickup_latitude", { precision: 10, scale: 8 }),
    pickupLongitude: decimal("pickup_longitude", { precision: 11, scale: 8 }),
    dropoffLocation: text("dropoff_location").notNull(),
    dropoffLatitude: decimal("dropoff_latitude", { precision: 10, scale: 8 }),
    dropoffLongitude: decimal("dropoff_longitude", { precision: 11, scale: 8 }),
    scheduledPickupTime: time("scheduled_pickup_time").notNull(),
    actualPickupTime: time("actual_pickup_time"),
    scheduledDropoffTime: time("scheduled_dropoff_time"),
    actualDropoffTime: time("actual_dropoff_time"),
    tripDate: date("trip_date").notNull(),
    isRecurring: boolean("is_recurring").default(false).notNull(),
    recurrenceEndDate: date("recurrence_end_date"),
    otpCode: varchar("otp_code", { length: 6 }),
    otpVerified: boolean("otp_verified").default(false).notNull(),
    otpExpiresAt: timestamp("otp_expires_at"),
    notes: text("notes"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
    createdBy: integer("created_by"),
  },
  (table) => ({
    bookingRefIdx: index("bookings_booking_ref_idx").on(table.bookingReference),
    employeeIdx: index("bookings_employee_idx").on(table.employeeId),
    companyIdx: index("bookings_company_idx").on(table.companyId),
    tripIdx: index("bookings_trip_idx").on(table.tripId),
    statusIdx: index("bookings_status_idx").on(table.status),
    dateIdx: index("bookings_date_idx").on(table.tripDate),
  })
);

export const boardingRecords = pgTable(
  "boarding_records",
  {
    id: serial("id").primaryKey(),
    bookingId: integer("booking_id")
      .notNull()
      .references(() => bookings.id, { onDelete: "cascade" }),
    tripId: integer("trip_id").references(() => trips.id, { onDelete: "set null" }),
    driverId: integer("driver_id").references(() => drivers.id, { onDelete: "set null" }),
    boardingTime: timestamp("boarding_time").defaultNow().notNull(),
    otpCode: varchar("otp_code", { length: 6 }).notNull(),
    otpVerified: boolean("otp_verified").default(false).notNull(),
    isNoShow: boolean("is_no_show").default(false).notNull(),
    notes: text("notes"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => ({
    bookingIdx: index("boarding_records_booking_idx").on(table.bookingId),
    tripIdx: index("boarding_records_trip_idx").on(table.tripId),
  })
);

export const gpsTrackingEvents = pgTable(
  "gps_tracking_events",
  {
    id: serial("id").primaryKey(),
    tripId: integer("trip_id")
      .notNull()
      .references(() => trips.id, { onDelete: "cascade" }),
    vehicleId: integer("vehicle_id").references(() => vehicles.id, { onDelete: "set null" }),
    driverId: integer("driver_id").references(() => drivers.id, { onDelete: "set null" }),
    latitude: decimal("latitude", { precision: 10, scale: 8 }).notNull(),
    longitude: decimal("longitude", { precision: 11, scale: 8 }).notNull(),
    speed: decimal("speed", { precision: 6, scale: 2 }),
    heading: integer("heading"),
    accuracy: decimal("accuracy", { precision: 6, scale: 2 }),
    timestamp: timestamp("timestamp").defaultNow().notNull(),
  },
  (table) => ({
    tripIdx: index("gps_tracking_events_trip_idx").on(table.tripId),
    vehicleIdx: index("gps_tracking_events_vehicle_idx").on(table.vehicleId),
    timestampIdx: index("gps_tracking_events_timestamp_idx").on(table.timestamp),
  })
);

export const maintenanceRecords = pgTable(
  "maintenance_records",
  {
    id: serial("id").primaryKey(),
    vehicleId: integer("vehicle_id")
      .notNull()
      .references(() => vehicles.id, { onDelete: "cascade" }),
    type: varchar("type", { length: 100 }).notNull(),
    description: text("description"),
    cost: decimal("cost", { precision: 12, scale: 2 }),
    serviceDate: date("service_date").notNull(),
    nextDueDate: date("next_due_date"),
    serviceProvider: varchar("service_provider", { length: 255 }),
    mileageAtService: integer("mileage_at_service"),
    status: varchar("status", { length: 50 }).default("completed"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => ({
    vehicleIdx: index("maintenance_records_vehicle_idx").on(table.vehicleId),
  })
);

export const payments = pgTable(
  "payments",
  {
    id: serial("id").primaryKey(),
    companyId: integer("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    invoiceId: integer("invoice_id"),
    amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
    currency: varchar("currency", { length: 3 }).default("GHS").notNull(),
    status: paymentStatusEnum("status").default("pending").notNull(),
    paymentMethod: varchar("payment_method", { length: 50 }),
    transactionReference: varchar("transaction_reference", { length: 255 }),
    providerReference: varchar("provider_reference", { length: 255 }),
    paymentDate: timestamp("payment_date"),
    notes: text("notes"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (table) => ({
    companyIdx: index("payments_company_idx").on(table.companyId),
    invoiceIdx: index("payments_invoice_idx").on(table.invoiceId),
    statusIdx: index("payments_status_idx").on(table.status),
  })
);

export const invoices = pgTable(
  "invoices",
  {
    id: serial("id").primaryKey(),
    invoiceNumber: varchar("invoice_number", { length: 50 }).notNull().unique(),
    companyId: integer("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    billingPeriodStart: date("billing_period_start").notNull(),
    billingPeriodEnd: date("billing_period_end").notNull(),
    subtotal: decimal("subtotal", { precision: 12, scale: 2 }).notNull(),
    taxAmount: decimal("tax_amount", { precision: 12, scale: 2 }).default("0").notNull(),
    discountAmount: decimal("discount_amount", { precision: 12, scale: 2 }).default("0").notNull(),
    totalAmount: decimal("total_amount", { precision: 12, scale: 2 }).notNull(),
    amountPaid: decimal("amount_paid", { precision: 12, scale: 2 }).default("0").notNull(),
    status: invoiceStatusEnum("status").default("draft").notNull(),
    dueDate: date("due_date").notNull(),
    sentAt: timestamp("sent_at"),
    paidAt: timestamp("paid_at"),
    notes: text("notes"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
    createdBy: integer("created_by"),
  },
  (table) => ({
    invoiceNumberIdx: index("invoices_invoice_number_idx").on(table.invoiceNumber),
    companyIdx: index("invoices_company_idx").on(table.companyId),
    statusIdx: index("invoices_status_idx").on(table.status),
  })
);

export const driverEarnings = pgTable(
  "driver_earnings",
  {
    id: serial("id").primaryKey(),
    driverId: integer("driver_id")
      .notNull()
      .references(() => drivers.id, { onDelete: "cascade" }),
    tripId: integer("trip_id").references(() => trips.id, { onDelete: "set null" }),
    basePay: decimal("base_pay", { precision: 10, scale: 2 }).notNull(),
    allowance: decimal("allowance", { precision: 10, scale: 2 }).default("0").notNull(),
    overtimePay: decimal("overtime_pay", { precision: 10, scale: 2 }).default("0").notNull(),
    totalEarnings: decimal("total_earnings", { precision: 10, scale: 2 }).notNull(),
    currency: varchar("currency", { length: 3 }).default("GHS").notNull(),
    paid: boolean("paid").default(false).notNull(),
    payDate: date("pay_date"),
    periodStart: date("period_start").notNull(),
    periodEnd: date("period_end").notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => ({
    driverIdx: index("driver_earnings_driver_idx").on(table.driverId),
    tripIdx: index("driver_earnings_trip_idx").on(table.tripId),
    periodIdx: index("driver_earnings_period_idx").on(table.periodStart, table.periodEnd),
  })
);

export const incidents = pgTable(
  "incidents",
  {
    id: serial("id").primaryKey(),
    companyId: integer("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    tripId: integer("trip_id").references(() => trips.id, { onDelete: "set null" }),
    vehicleId: integer("vehicle_id").references(() => vehicles.id, { onDelete: "set null" }),
    driverId: integer("driver_id").references(() => drivers.id, { onDelete: "set null" }),
    title: varchar("title", { length: 255 }).notNull(),
    description: text("description").notNull(),
    severity: incidentSeverityEnum("severity").default("medium").notNull(),
    incidentType: varchar("incident_type", { length: 100 }).notNull(),
    location: text("location"),
    latitude: decimal("latitude", { precision: 10, scale: 8 }),
    longitude: decimal("longitude", { precision: 11, scale: 8 }),
    reportedBy: integer("reported_by").notNull(),
    reportedAt: timestamp("reported_at").defaultNow().notNull(),
    resolvedAt: timestamp("resolved_at"),
    status: varchar("status", { length: 50 }).default("open").notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (table) => ({
    companyIdx: index("incidents_company_idx").on(table.companyId),
    tripIdx: index("incidents_trip_idx").on(table.tripId),
    statusIdx: index("incidents_status_idx").on(table.status),
    severityIdx: index("incidents_severity_idx").on(table.severity),
  })
);

export const notifications = pgTable(
  "notifications",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").references(() => users.id, { onDelete: "cascade" }),
    companyId: integer("company_id").references(() => companies.id, { onDelete: "cascade" }),
    title: varchar("title", { length: 255 }).notNull(),
    message: text("message").notNull(),
    type: notificationTypeEnum("type").default("info").notNull(),
    isRead: boolean("is_read").default(false).notNull(),
    isPush: boolean("is_push").default(false).notNull(),
    isEmail: boolean("is_email").default(false).notNull(),
    isSms: boolean("is_sms").default(false).notNull(),
    data: jsonb("data").$type<Record<string, unknown>>().default({}),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    readAt: timestamp("read_at"),
  },
  (table) => ({
    userIdx: index("notifications_user_idx").on(table.userId),
    companyIdx: index("notifications_company_idx").on(table.companyId),
    readIdx: index("notifications_read_idx").on(table.isRead),
  })
);

export const serviceLevelAgreements = pgTable(
  "service_level_agreements",
  {
    id: serial("id").primaryKey(),
    companyId: integer("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    name: varchar("name", { length: 255 }).notNull(),
    description: text("description"),
    maxPickupDelayMinutes: integer("max_pickup_delay_minutes").default(15),
    maxTripDelayMinutes: integer("max_trip_delay_minutes").default(30),
    minOnTimePercentage: decimal("min_on_time_percentage", { precision: 5, scale: 2 }).default("90.00"),
    penaltyPerLatePickup: decimal("penalty_per_late_pickup", { precision: 10, scale: 2 }),
    isActive: boolean("is_active").default(true).notNull(),
    createdAt: timestamp("created_at").defaultNow().notNull(),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (table) => ({
    companyIdx: index("service_level_agreements_company_idx").on(table.companyId),
  })
);

export const auditLogs = pgTable(
  "audit_logs",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id"),
    companyId: integer("company_id"),
    action: varchar("action", { length: 100 }).notNull(),
    entityType: varchar("entity_type", { length: 100 }).notNull(),
    entityId: integer("entity_id"),
    oldValues: jsonb("old_values").$type<Record<string, unknown>>().default({}),
    newValues: jsonb("new_values").$type<Record<string, unknown>>().default({}),
    ipAddress: varchar("ip_address", { length: 50 }),
    userAgent: text("user_agent"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (table) => ({
    userIdx: index("audit_logs_user_idx").on(table.userId),
    companyIdx: index("audit_logs_company_idx").on(table.companyId),
    actionIdx: index("audit_logs_action_idx").on(table.action),
    entityIdx: index("audit_logs_entity_idx").on(table.entityType, table.entityId),
    createdAtIdx: index("audit_logs_created_at_idx").on(table.createdAt),
  })
);

// ============================================================================
// RELATIONS
// ============================================================================

export const rolesRelations = relations(roles, ({ many }) => ({
  rolePermissions: many(rolePermissions),
  userRoles: many(userRoles),
}));

export const permissionsRelations = relations(permissions, ({ many }) => ({
  rolePermissions: many(rolePermissions),
}));

export const rolePermissionsRelations = relations(rolePermissions, ({ one }) => ({
  role: one(roles, { fields: [rolePermissions.roleId], references: [roles.id] }),
  permission: one(permissions, {
    fields: [rolePermissions.permissionId],
    references: [permissions.id],
  }),
}));

export const usersRelations = relations(users, ({ one, many }) => ({
  company: one(companies, { fields: [users.companyId], references: [companies.id] }),
  userRoles: many(userRoles),
  employee: one(employees, { fields: [users.id], references: [employees.userId] }),
  driver: one(drivers, { fields: [users.id], references: [drivers.userId] }),
  notifications: many(notifications),
  auditLogs: many(auditLogs),
}));

export const userRolesRelations = relations(userRoles, ({ one }) => ({
  user: one(users, { fields: [userRoles.userId], references: [users.id] }),
  role: one(roles, { fields: [userRoles.roleId], references: [roles.id] }),
}));

export const companiesRelations = relations(companies, ({ many }) => ({
  branches: many(companyBranches),
  shifts: many(shifts),
  employees: many(employees),
  vehicles: many(vehicles),
  drivers: many(drivers),
  routes: many(routes),
  trips: many(trips),
  bookings: many(bookings),
  invoices: many(invoices),
  payments: many(payments),
  incidents: many(incidents),
  notifications: many(notifications),
  serviceLevelAgreements: many(serviceLevelAgreements),
  auditLogs: many(auditLogs),
}));

export const companyBranchesRelations = relations(companyBranches, ({ one }) => ({
  company: one(companies, { fields: [companyBranches.companyId], references: [companies.id] }),
}));

export const shiftsRelations = relations(shifts, ({ one, many }) => ({
  company: one(companies, { fields: [shifts.companyId], references: [companies.id] }),
  employees: many(employees),
  routes: many(routes),
}));

export const employeesRelations = relations(employees, ({ one, many }) => ({
  user: one(users, { fields: [employees.userId], references: [users.id] }),
  company: one(companies, { fields: [employees.companyId], references: [companies.id] }),
  branch: one(companyBranches, {
    fields: [employees.branchId],
    references: [companyBranches.id],
  }),
  shift: one(shifts, { fields: [employees.shiftId], references: [shifts.id] }),
  addresses: many(addresses),
  bookings: many(bookings),
  employeeShifts: many(employeeShifts),
}));

export const employeeShiftsRelations = relations(employeeShifts, ({ one }) => ({
  employee: one(employees, { fields: [employeeShifts.employeeId], references: [employees.id] }),
  shift: one(shifts, { fields: [employeeShifts.shiftId], references: [shifts.id] }),
}));

export const addressesRelations = relations(addresses, ({ one }) => ({
  employee: one(employees, { fields: [addresses.employeeId], references: [employees.id] }),
}));

export const vehiclesRelations = relations(vehicles, ({ one, many }) => ({
  company: one(companies, { fields: [vehicles.companyId], references: [companies.id] }),
  assignedDriver: one(drivers, {
    fields: [vehicles.assignedDriverId],
    references: [drivers.id],
  }),
  trips: many(trips),
  tripAssignments: many(tripAssignments),
  maintenanceRecords: many(maintenanceRecords),
  gpsEvents: many(gpsTrackingEvents),
}));

export const driversRelations = relations(drivers, ({ one, many }) => ({
  user: one(users, { fields: [drivers.userId], references: [users.id] }),
  company: one(companies, { fields: [drivers.companyId], references: [companies.id] }),
  trips: many(trips),
  tripAssignments: many(tripAssignments),
  boardingRecords: many(boardingRecords),
  gpsEvents: many(gpsTrackingEvents),
  driverShifts: many(driverShifts),
  driverEarnings: many(driverEarnings),
  incidents: many(incidents),
}));

export const driverShiftsRelations = relations(driverShifts, ({ one }) => ({
  driver: one(drivers, { fields: [driverShifts.driverId], references: [drivers.id] }),
  shift: one(shifts, { fields: [driverShifts.shiftId], references: [shifts.id] }),
}));

export const routesRelations = relations(routes, ({ one, many }) => ({
  company: one(companies, { fields: [routes.companyId], references: [companies.id] }),
  shift: one(shifts, { fields: [routes.shiftId], references: [shifts.id] }),
  stops: many(routeStops),
  trips: many(trips),
}));

export const routeStopsRelations = relations(routeStops, ({ one }) => ({
  route: one(routes, { fields: [routeStops.routeId], references: [routes.id] }),
}));

export const tripsRelations = relations(trips, ({ one, many }) => ({
  company: one(companies, { fields: [trips.companyId], references: [companies.id] }),
  route: one(routes, { fields: [trips.routeId], references: [routes.id] }),
  vehicle: one(vehicles, { fields: [trips.vehicleId], references: [vehicles.id] }),
  driver: one(drivers, { fields: [trips.driverId], references: [drivers.id] }),
  shift: one(shifts, { fields: [trips.shiftId], references: [shifts.id] }),
  bookings: many(bookings),
  tripAssignments: many(tripAssignments),
  boardingRecords: many(boardingRecords),
  gpsEvents: many(gpsTrackingEvents),
  driverEarnings: many(driverEarnings),
  incidents: many(incidents),
}));

export const tripAssignmentsRelations = relations(tripAssignments, ({ one }) => ({
  trip: one(trips, { fields: [tripAssignments.tripId], references: [trips.id] }),
  vehicle: one(vehicles, {
    fields: [tripAssignments.vehicleId],
    references: [vehicles.id],
  }),
  driver: one(drivers, { fields: [tripAssignments.driverId], references: [drivers.id] }),
}));

export const bookingsRelations = relations(bookings, ({ one, many }) => ({
  employee: one(employees, { fields: [bookings.employeeId], references: [employees.id] }),
  company: one(companies, { fields: [bookings.companyId], references: [companies.id] }),
  trip: one(trips, { fields: [bookings.tripId], references: [trips.id] }),
  route: one(routes, { fields: [bookings.routeId], references: [routes.id] }),
  boardingRecords: many(boardingRecords),
}));

export const boardingRecordsRelations = relations(boardingRecords, ({ one }) => ({
  booking: one(bookings, { fields: [boardingRecords.bookingId], references: [bookings.id] }),
  trip: one(trips, { fields: [boardingRecords.tripId], references: [trips.id] }),
  driver: one(drivers, { fields: [boardingRecords.driverId], references: [drivers.id] }),
}));

export const gpsTrackingEventsRelations = relations(gpsTrackingEvents, ({ one }) => ({
  trip: one(trips, { fields: [gpsTrackingEvents.tripId], references: [trips.id] }),
  vehicle: one(vehicles, {
    fields: [gpsTrackingEvents.vehicleId],
    references: [vehicles.id],
  }),
  driver: one(drivers, { fields: [gpsTrackingEvents.driverId], references: [drivers.id] }),
}));

export const maintenanceRecordsRelations = relations(maintenanceRecords, ({ one }) => ({
  vehicle: one(vehicles, {
    fields: [maintenanceRecords.vehicleId],
    references: [vehicles.id],
  }),
}));

export const paymentsRelations = relations(payments, ({ one }) => ({
  company: one(companies, { fields: [payments.companyId], references: [companies.id] }),
  invoice: one(invoices, { fields: [payments.invoiceId], references: [invoices.id] }),
}));

export const invoicesRelations = relations(invoices, ({ one, many }) => ({
  company: one(companies, { fields: [invoices.companyId], references: [companies.id] }),
  payments: many(payments),
}));

export const driverEarningsRelations = relations(driverEarnings, ({ one }) => ({
  driver: one(drivers, { fields: [driverEarnings.driverId], references: [drivers.id] }),
  trip: one(trips, { fields: [driverEarnings.tripId], references: [trips.id] }),
}));

export const incidentsRelations = relations(incidents, ({ one }) => ({
  company: one(companies, { fields: [incidents.companyId], references: [companies.id] }),
  trip: one(trips, { fields: [incidents.tripId], references: [trips.id] }),
  vehicle: one(vehicles, { fields: [incidents.vehicleId], references: [vehicles.id] }),
  driver: one(drivers, { fields: [incidents.driverId], references: [drivers.id] }),
}));

export const notificationsRelations = relations(notifications, ({ one }) => ({
  user: one(users, { fields: [notifications.userId], references: [users.id] }),
  company: one(companies, {
    fields: [notifications.companyId],
    references: [companies.id],
  }),
}));

export const serviceLevelAgreementsRelations = relations(serviceLevelAgreements, ({ one }) => ({
  company: one(companies, {
    fields: [serviceLevelAgreements.companyId],
    references: [companies.id],
  }),
}));

export const auditLogsRelations = relations(auditLogs, ({ one }) => ({
  user: one(users, { fields: [auditLogs.userId], references: [users.id] }),
  company: one(companies, {
    fields: [auditLogs.companyId],
    references: [companies.id],
  }),
}));