// @ts-nocheck
import { db } from "@/db";
import {
  roles,
  permissions,
  rolePermissions,
  users,
  companies,
  companyBranches,
  shifts,
  employees,
  vehicles,
  drivers,
  routes,
  routeStops,
  trips,
  bookings,
} from "@/db/schema";
import { eq } from "drizzle-orm";
import { hashPassword } from "@/lib/auth";

async function seed() {
  console.log("🌱 Starting database seed...");

  // Create roles
  const roleData = [
    { name: "super_admin", description: "Full system access", isSystem: true },
    { name: "operations_manager", description: "Operations oversight", isSystem: true },
    { name: "dispatcher", description: "Trip dispatch and coordination", isSystem: true },
    { name: "fleet_manager", description: "Vehicle and fleet management", isSystem: true },
    { name: "finance_officer", description: "Billing and payments", isSystem: true },
    { name: "corporate_hr", description: "Corporate client HR", isSystem: true },
    { name: "driver", description: "Driver operations", isSystem: true },
    { name: "employee", description: "Employee/passenger", isSystem: true },
  ];

  for (const role of roleData) {
    await db.insert(roles).values(role).onConflictDoNothing();
  }
  console.log("✅ Roles created");

  // Create permissions
  const permissionData = [
    { name: "companies.view", resource: "companies", action: "view", description: "View companies" },
    { name: "companies.create", resource: "companies", action: "create", description: "Create companies" },
    { name: "companies.edit", resource: "companies", action: "edit", description: "Edit companies" },
    { name: "employees.view", resource: "employees", action: "view", description: "View employees" },
    { name: "employees.create", resource: "employees", action: "create", description: "Create employees" },
    { name: "employees.edit", resource: "employees", action: "edit", description: "Edit employees" },
    { name: "vehicles.view", resource: "vehicles", action: "view", description: "View vehicles" },
    { name: "vehicles.create", resource: "vehicles", action: "create", description: "Create vehicles" },
    { name: "vehicles.edit", resource: "vehicles", action: "edit", description: "Edit vehicles" },
    { name: "drivers.view", resource: "drivers", action: "view", description: "View drivers" },
    { name: "drivers.create", resource: "drivers", action: "create", description: "Create drivers" },
    { name: "drivers.edit", resource: "drivers", action: "edit", description: "Edit drivers" },
    { name: "bookings.view", resource: "bookings", action: "view", description: "View bookings" },
    { name: "bookings.create", resource: "bookings", action: "create", description: "Create bookings" },
    { name: "bookings.edit", resource: "bookings", action: "edit", description: "Edit bookings" },
    { name: "trips.view", resource: "trips", action: "view", description: "View trips" },
    { name: "trips.create", resource: "trips", action: "create", description: "Create trips" },
    { name: "trips.edit", resource: "trips", action: "edit", description: "Edit trips" },
    { name: "routes.view", resource: "routes", action: "view", description: "View routes" },
    { name: "routes.create", resource: "routes", action: "create", description: "Create routes" },
    { name: "dashboard.view", resource: "dashboard", action: "view", description: "View dashboard" },
    { name: "reports.view", resource: "reports", action: "view", description: "View reports" },
  ];

  for (const perm of permissionData) {
    await db.insert(permissions).values(perm).onConflictDoNothing();
  }
  console.log("✅ Permissions created");

  // Assign all permissions to super_admin
  const superAdminRole = await db.query.roles.findFirst({
    where: eq(roles.name, "super_admin"),
  });
  const allPermissions = await db.query.permissions.findMany();
  if (superAdminRole && allPermissions.length > 0) {
    for (const perm of allPermissions) {
      await db.insert(rolePermissions).values({
        roleId: superAdminRole.id,
        permissionId: perm.id,
      }).onConflictDoNothing();
    }
  }
  console.log("✅ Role permissions assigned");

  // Create demo company
  const [demoCompany] = await db.insert(companies).values({
    name: "Tech Solutions Ghana Ltd",
    registrationNumber: "RC-123456",
    taxId: "TIN-789012",
    email: "hr@techsolutions.com",
    phone: "+233 20 123 4567",
    address: "123 Independence Avenue",
    city: "Accra",
    country: "Ghana",
    currency: "GHS",
    status: "active",
    createdBy: 1,
  }).returning();
  console.log("✅ Demo company created");

  // Create branches
  const [hqBranch] = await db.insert(companyBranches).values({
    companyId: demoCompany.id,
    name: "Head Office",
    address: "123 Independence Avenue, Accra",
    city: "Accra",
    phone: "+233 20 123 4567",
    email: "hq@techsolutions.com",
    isHeadquarters: true,
    latitude: 5.5600,
    longitude: -0.1867,
  }).returning();

  const [northBranch] = await db.insert(companyBranches).values({
    companyId: demoCompany.id,
    name: "North Industrial Branch",
    address: "456 Industrial Area, North Accra",
    city: "Accra",
    phone: "+233 20 987 6543",
    email: "north@techsolutions.com",
    isHeadquarters: false,
    latitude: 5.6000,
    longitude: -0.2000,
  }).returning();
  console.log("✅ Branches created");

  // Create shifts
  const [morningShift] = await db.insert(shifts).values({
    companyId: demoCompany.id,
    name: "Morning Shift",
    shiftType: "morning",
    startTime: "08:00:00",
    endTime: "17:00:00",
    reportingTime: "07:30:00",
    daysOfWeek: [1, 2, 3, 4, 5],
    isActive: true,
  }).returning();

  const [eveningShift] = await db.insert(shifts).values({
    companyId: demoCompany.id,
    name: "Evening Shift",
    shiftType: "evening",
    startTime: "16:00:00",
    endTime: "01:00:00",
    reportingTime: "15:30:00",
    daysOfWeek: [1, 2, 3, 4, 5],
    isActive: true,
  }).returning();

  const [nightShift] = await db.insert(shifts).values({
    companyId: demoCompany.id,
    name: "Night Shift",
    shiftType: "night",
    startTime: "22:00:00",
    endTime: "06:00:00",
    reportingTime: "21:30:00",
    daysOfWeek: [1, 2, 3, 4, 5],
    isActive: true,
  }).returning();
  console.log("✅ Shifts created");

  // Create super admin user
  const adminPasswordHash = await hashPassword("Admin123!");
  const [adminUser] = await db.insert(users).values({
    email: "admin@tms.com",
    phone: "+233 20 000 0000",
    passwordHash: adminPasswordHash,
    firstName: "System",
    lastName: "Administrator",
    role: "super_admin",
    status: "active",
    emailVerified: true,
    phoneVerified: true,
    companyId: demoCompany.id,
  }).returning();
  console.log("✅ Super admin created");

  // Create demo employees
  const demoEmployees = [
    {
      employeeId: "EMP-001",
      firstName: "Kwame",
      lastName: "Asare",
      email: "kwame.asare@techsolutions.com",
      phone: "+233 24 111 1111",
      homeAddress: "15 Osu Street, Accra",
      homeLatitude: 5.5500,
      homeLongitude: -0.1900,
      officeAddress: "123 Independence Avenue, Accra",
      officeLatitude: 5.5600,
      officeLongitude: -0.1867,
      branchId: hqBranch.id,
      shiftId: morningShift.id,
    },
    {
      employeeId: "EMP-002",
      firstName: "Ama",
      lastName: "Owusu",
      email: "ama.owusu@techsolutions.com",
      phone: "+233 24 222 2222",
      homeAddress: "22 East Legon Road, Accra",
      homeLatitude: 5.5800,
      homeLongitude: -0.1700,
      officeAddress: "123 Independence Avenue, Accra",
      officeLatitude: 5.5600,
      officeLongitude: -0.1867,
      branchId: hqBranch.id,
      shiftId: morningShift.id,
    },
    {
      employeeId: "EMP-003",
      firstName: "Kofi",
      lastName: "Mensah",
      email: "kofi.mensah@techsolutions.com",
      phone: "+233 24 333 3333",
      homeAddress: "8 Airport Residential, Accra",
      homeLatitude: 5.5550,
      homeLongitude: -0.1750,
      officeAddress: "456 Industrial Area, North Accra",
      officeLatitude: 5.6000,
      officeLongitude: -0.2000,
      branchId: northBranch.id,
      shiftId: morningShift.id,
    },
    {
      employeeId: "EMP-004",
      firstName: "Efua",
      lastName: "Aidoo",
      email: "efua.aidoo@techsolutions.com",
      phone: "+233 24 444 4444",
      homeAddress: "30 Cantonments Road, Accra",
      homeLatitude: 5.5700,
      homeLongitude: -0.1800,
      officeAddress: "123 Independence Avenue, Accra",
      officeLatitude: 5.5600,
      officeLongitude: -0.1867,
      branchId: hqBranch.id,
      shiftId: eveningShift.id,
    },
    {
      employeeId: "EMP-005",
      firstName: "Yaw",
      lastName: "Boateng",
      email: "yaw.boateng@techsolutions.com",
      phone: "+233 24 555 5555",
      homeAddress: "12 Kasoa Road, Accra",
      homeLatitude: 5.5200,
      homeLongitude: -0.2500,
      officeAddress: "123 Independence Avenue, Accra",
      officeLatitude: 5.5600,
      officeLongitude: -0.1867,
      branchId: hqBranch.id,
      shiftId: nightShift.id,
    },
  ];

  for (const emp of demoEmployees) {
    const empPasswordHash = await hashPassword("Employee123!");
    const [user] = await db.insert(users).values({
      email: emp.email,
      phone: emp.phone,
      passwordHash: empPasswordHash,
      firstName: emp.firstName,
      lastName: emp.lastName,
      role: "employee",
      status: "active",
      companyId: demoCompany.id,
    }).returning();

    await db.insert(employees).values({
      userId: user.id,
      companyId: demoCompany.id,
      branchId: emp.branchId,
      employeeId: emp.employeeId,
      firstName: emp.firstName,
      lastName: emp.lastName,
      email: emp.email,
      phone: emp.phone,
      homeAddress: emp.homeAddress,
      homeLatitude: emp.homeLatitude,
      homeLongitude: emp.homeLongitude,
      officeAddress: emp.officeAddress,
      officeLatitude: emp.officeLatitude,
      officeLongitude: emp.officeLongitude,
      shiftId: emp.shiftId,
      isTransportEligible: true,
      createdBy: adminUser.id,
    });
  }
  console.log("✅ Demo employees created");

  // Create drivers
  const demoDrivers = [
    {
      employeeId: "DRV-001",
      firstName: "Kwaku",
      lastName: "Ofori",
      email: "kwaku.ofori@techsolutions.com",
      phone: "+233 24 600 0001",
      licenseNumber: "DL-2021-001",
      licenseExpiry: "2027-12-31",
      licenseCategory: "D",
      hireDate: "2022-01-15",
      emergencyContactName: "Akua Ofori",
      emergencyContactPhone: "+233 24 600 0002",
    },
    {
      employeeId: "DRV-002",
      firstName: "Samuel",
      lastName: "Addo",
      email: "samuel.addo@techsolutions.com",
      phone: "+233 24 600 0003",
      licenseNumber: "DL-2021-002",
      licenseExpiry: "2026-06-30",
      licenseCategory: "D",
      hireDate: "2022-03-10",
      emergencyContactName: "Mary Addo",
      emergencyContactPhone: "+233 24 600 0004",
    },
  ];

  for (const drv of demoDrivers) {
    const drvPasswordHash = await hashPassword("Driver123!");
    const [user] = await db.insert(users).values({
      email: drv.email,
      phone: drv.phone,
      passwordHash: drvPasswordHash,
      firstName: drv.firstName,
      lastName: drv.lastName,
      role: "driver",
      status: "active",
      companyId: demoCompany.id,
    }).returning();

    await db.insert(drivers).values({
      userId: user.id,
      companyId: demoCompany.id,
      employeeId: drv.employeeId,
      firstName: drv.firstName,
      lastName: drv.lastName,
      email: drv.email,
      phone: drv.phone,
      licenseNumber: drv.licenseNumber,
      licenseExpiry: new Date(drv.licenseExpiry),
      licenseCategory: drv.licenseCategory,
      hireDate: new Date(drv.hireDate),
      emergencyContactName: drv.emergencyContactName,
      emergencyContactPhone: drv.emergencyContactPhone,
      isAvailable: true,
      createdBy: adminUser.id,
    });
  }
  console.log("✅ Demo drivers created");

  // Create vehicles
  const demoVehicles = [
    {
      registrationNumber: "GT-1234-A",
      make: "Toyota",
      model: "Coaster",
      year: 2022,
      vehicleType: "minibus",
      fuelType: "diesel",
      seatingCapacity: 30,
      standingCapacity: 0,
      color: "White",
      status: "available",
      registrationExpiry: "2025-12-31",
      insuranceExpiry: "2025-06-30",
      roadworthinessExpiry: "2025-09-30",
    },
    {
      registrationNumber: "GT-5678-B",
      make: "Ford",
      model: "Transit",
      year: 2021,
      vehicleType: "van",
      fuelType: "diesel",
      seatingCapacity: 15,
      standingCapacity: 0,
      color: "Silver",
      status: "available",
      registrationExpiry: "2025-10-31",
      insuranceExpiry: "2025-04-30",
      roadworthinessExpiry: "2025-07-31",
    },
    {
      registrationNumber: "GT-9012-C",
      make: "Toyota",
      model: "Hiace",
      year: 2023,
      vehicleType: "van",
      fuelType: "diesel",
      seatingCapacity: 14,
      standingCapacity: 0,
      color: "White",
      status: "available",
      registrationExpiry: "2026-01-31",
      insuranceExpiry: "2025-08-31",
      roadworthinessExpiry: "2025-11-30",
    },
  ];

  for (const veh of demoVehicles) {
    await db.insert(vehicles).values({
      companyId: demoCompany.id,
      registrationNumber: veh.registrationNumber,
      make: veh.make,
      model: veh.model,
      year: veh.year,
      vehicleType: veh.vehicleType,
      fuelType: veh.fuelType,
      seatingCapacity: veh.seatingCapacity,
      standingCapacity: veh.standingCapacity,
      color: veh.color,
      status: veh.status,
      registrationExpiry: veh.registrationExpiry ? new Date(veh.registrationExpiry) : null,
      insuranceExpiry: veh.insuranceExpiry ? new Date(veh.insuranceExpiry) : null,
      roadworthinessExpiry: veh.roadworthinessExpiry ? new Date(veh.roadworthinessExpiry) : null,
      createdBy: adminUser.id,
    });
  }
  console.log("✅ Demo vehicles created");

  // Create routes
  const [route1] = await db.insert(routes).values({
    companyId: demoCompany.id,
    name: "Osu - Head Office Route",
    code: "R001",
    description: "Morning pickup from Osu area to Head Office",
    shiftId: morningShift.id,
    estimatedDurationMinutes: 45,
    distanceKm: 12.5,
    createdBy: adminUser.id,
  }).returning();

  const [route2] = await db.insert(routes).values({
    companyId: demoCompany.id,
    name: "East Legon - Head Office Route",
    code: "R002",
    description: "Morning pickup from East Legon to Head Office",
    shiftId: morningShift.id,
    estimatedDurationMinutes: 35,
    distanceKm: 8.5,
    createdBy: adminUser.id,
  }).returning();

  const [route3] = await db.insert(routes).values({
    companyId: demoCompany.id,
    name: "North Industrial Route",
    code: "R003",
    description: "Evening route to North Industrial Branch",
    shiftId: eveningShift.id,
    estimatedDurationMinutes: 50,
    distanceKm: 15.0,
    createdBy: adminUser.id,
  }).returning();

  // Create route stops
  await db.insert(routeStops).values([
    {
      routeId: route1.id,
      stopSequence: 1,
      name: "Osu Oxford Street",
      address: "Oxford Street, Osu, Accra",
      latitude: 5.5500,
      longitude: -0.1900,
      estimatedArrivalOffset: 0,
      isPickup: true,
      isDropoff: false,
    },
    {
      routeId: route1.id,
      stopSequence: 2,
      name: "Osu Castle Road",
      address: "Castle Road, Osu, Accra",
      latitude: 5.5530,
      longitude: -0.1880,
      estimatedArrivalOffset: 10,
      isPickup: true,
      isDropoff: false,
    },
    {
      routeId: route1.id,
      stopSequence: 3,
      name: "Head Office Drop-off",
      address: "123 Independence Avenue, Accra",
      latitude: 5.5600,
      longitude: -0.1867,
      estimatedArrivalOffset: 25,
      isPickup: false,
      isDropoff: true,
    },
  ]);

  await db.insert(routeStops).values([
    {
      routeId: route2.id,
      stopSequence: 1,
      name: "East Legon Junction",
      address: "East Legon Junction, Accra",
      latitude: 5.5800,
      longitude: -0.1700,
      estimatedArrivalOffset: 0,
      isPickup: true,
      isDropoff: false,
    },
    {
      routeId: route2.id,
      stopSequence: 2,
      name: "Head Office Drop-off",
      address: "123 Independence Avenue, Accra",
      latitude: 5.5600,
      longitude: -0.1867,
      estimatedArrivalOffset: 20,
      isPickup: false,
      isDropoff: true,
    },
  ]);
  console.log("✅ Routes and stops created");

  // Create sample trips
  const today = new Date().toISOString().split("T")[0];
  const [trip1] = await db.insert(trips).values({
    companyId: demoCompany.id,
    routeId: route1.id,
    vehicleId: 1,
    driverId: 1,
    shiftId: morningShift.id,
    tripDate: today,
    scheduledDeparture: "07:00:00",
    scheduledArrival: "07:45:00",
    status: "scheduled",
    capacity: 30,
    currentOccupancy: 0,
    createdBy: adminUser.id,
  }).returning();

  const [trip2] = await db.insert(trips).values({
    companyId: demoCompany.id,
    routeId: route2.id,
    vehicleId: 2,
    driverId: 2,
    shiftId: morningShift.id,
    tripDate: today,
    scheduledDeparture: "07:15:00",
    scheduledArrival: "07:50:00",
    status: "scheduled",
    capacity: 15,
    currentOccupancy: 0,
    createdBy: adminUser.id,
  }).returning();

  // Create sample bookings
  const demoEmployeesList = await db.query.employees.findMany({
    where: eq(employees.companyId, demoCompany.id),
    limit: 5,
  });

  for (const emp of demoEmployeesList) {
    await db.insert(bookings).values({
      bookingReference: `TMS-${Math.floor(100000 + Math.random() * 900000)}-${Date.now().toString().slice(-6)}`,
      employeeId: emp.id,
      companyId: demoCompany.id,
      tripId: trip1.id,
      routeId: route1.id,
      bookingType: "daily",
      status: "confirmed",
      pickupLocation: emp.homeAddress || "Unknown",
      dropoffLocation: emp.officeAddress || "Unknown",
      scheduledPickupTime: "06:45:00",
      tripDate: today,
      isRecurring: true,
      otpCode: Math.floor(100000 + Math.random() * 900000).toString(),
      createdBy: adminUser.id,
    });
  }
  console.log("✅ Sample bookings created");

  console.log("🎉 Database seed completed successfully!");
  console.log(`📋 Demo credentials:`);
  console.log(`   Admin: admin@tms.com / Admin123!`);
  console.log(`   Employee: kwame.asare@techsolutions.com / Employee123!`);
}

seed().catch((err) => {
  console.error("❌ Seed failed:", err);
  process.exit(1);
});