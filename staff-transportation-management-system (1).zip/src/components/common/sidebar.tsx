// @ts-nocheck
"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  Users,
  Truck,
  Bus,
  Calendar,
  MapPin,
  FileText,
  ShieldAlert,
  CreditCard,
  Settings,
  LogOut,
  BarChart3,
  Phone,
  Mail,
  Clock,
  CheckCircle2,
  AlertCircle,
  Layers,
  TrendingUp,
  Wallet,
  UserCheck,
  Map,
} from "lucide-react";

const Building = ({ className }: any) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M4 5h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2" />
    <path d="M10 13h4" />
    <path d="M10 17h4" />
    <path d="M4 9h16" />
  </svg>
);

interface NavItem {
  title: string;
  href: string;
  icon: React.ElementType;
  roles: string[];
}

const navigation: NavItem[] = [
  { title: "Dashboard", href: "/dashboard", icon: LayoutDashboard, roles: ["super_admin", "operations_manager", "dispatcher", "fleet_manager", "finance_officer"] },
  { title: "Dispatch", href: "/dispatch", icon: Layers, roles: ["super_admin", "operations_manager", "dispatcher"] },
  { title: "Companies", href: "/dashboard/companies", icon: Building, roles: ["super_admin", "operations_manager"] },
  { title: "Employees", href: "/dashboard/employees", icon: Users, roles: ["super_admin", "operations_manager", "corporate_hr"] },
  { title: "Vehicles", href: "/dashboard/vehicles", icon: Truck, roles: ["super_admin", "operations_manager", "fleet_manager"] },
  { title: "Drivers", href: "/dashboard/drivers", icon: UserCheck, roles: ["super_admin", "operations_manager", "fleet_manager"] },
  { title: "Routes", href: "/dashboard/routes", icon: Map, roles: ["super_admin", "operations_manager", "dispatcher"] },
  { title: "Trips", href: "/dashboard/trips", icon: Bus, roles: ["super_admin", "operations_manager", "dispatcher"] },
  { title: "Bookings", href: "/dashboard/bookings", icon: Calendar, roles: ["super_admin", "operations_manager", "corporate_hr", "dispatcher"] },
  { title: "Incidents", href: "/dashboard/incidents", icon: AlertCircle, roles: ["super_admin", "operations_manager", "dispatcher"] },
  { title: "Invoices", href: "/dashboard/invoices", icon: CreditCard, roles: ["super_admin", "operations_manager", "finance_officer"] },
  { title: "Reports", href: "/dashboard/reports", icon: BarChart3, roles: ["super_admin", "operations_manager", "finance_officer"] },
  { title: "Settings", href: "/dashboard/settings", icon: Settings, roles: ["super_admin"] },
];

export function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="fixed left-0 top-0 h-full w-64 bg-slate-900 text-white flex flex-col z-20 hidden md:block">
      <div className="p-6 border-b border-slate-800">
        <Link href="/" className="flex items-center gap-2">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <Bus className="w-5 h-5 text-white" />
          </div>
          <span className="font-bold text-lg tracking-tight">TMS</span>
        </Link>
      </div>

      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {navigation.map((item) => {
          const isActive = pathname === item.href || pathname.startsWith(item.href + "/");
          return (
            <Link
              key={item.title}
              href={item.href}
              className={`
                flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors
                ${isActive ? "bg-primary text-white" : "text-slate-300 hover:bg-slate-800 hover:text-white"}
              `}
            >
              <item.icon className="w-5 h-5" />
              {item.title}
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-slate-800">
        <Link href="/api/auth/logout" className="flex items-center gap-3 px-4 py-2 text-sm font-medium text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg">
          <LogOut className="w-4 h-4" />
          Sign out
        </Link>
      </div>
    </aside>
  );
}