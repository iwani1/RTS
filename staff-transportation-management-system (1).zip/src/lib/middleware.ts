import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { getSession } from "@/lib/auth";

// Public routes that don't require authentication
const PUBLIC_ROUTES = [
  "/api/auth/login",
  "/api/auth/register",
  "/api/auth/forgot-password",
  "/api/auth/reset-password",
  "/api/health",
];

// Auth pages
const AUTH_PAGES = ["/login", "/register", "/forgot-password", "/reset-password"];

// Role-based route access
const ROUTE_ROLE_ACCESS: Record<string, string[]> = {
  "/dashboard": ["super_admin", "operations_manager", "dispatcher", "fleet_manager", "finance_officer"],
  "/corporate": ["corporate_hr"],
  "/driver": ["driver"],
  "/employee": ["employee"],
  "/dispatch": ["super_admin", "operations_manager", "dispatcher"],
};

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // Skip static files and API routes (handled individually)
  if (
    pathname.startsWith("/_next") ||
    pathname.startsWith("/api/") ||
    pathname.startsWith("/favicon")
  ) {
    return NextResponse.next();
  }

  const session = await getSession();

  // Redirect to login if accessing protected page without session
  if (!session) {
    if (AUTH_PAGES.includes(pathname)) {
      return NextResponse.next();
    }
    return NextResponse.redirect(new URL("/login", request.url));
  }

  // Redirect to dashboard if authenticated user tries to access auth pages
  if (session && AUTH_PAGES.includes(pathname)) {
    const defaultRoute = getDefaultRoute(session.role);
    return NextResponse.redirect(new URL(defaultRoute, request.url));
  }

  // Role-based route protection for pages
  for (const [routePattern, allowedRoles] of Object.entries(ROUTE_ROLE_ACCESS)) {
    if (pathname.startsWith(routePattern)) {
      if (!allowedRoles.includes(session.role) && session.role !== "super_admin") {
        return NextResponse.redirect(new URL("/unauthorized", request.url));
      }
      break;
    }
  }

  return NextResponse.next();
}

function getDefaultRoute(role: string): string {
  const routeMap: Record<string, string> = {
    super_admin: "/dashboard",
    operations_manager: "/dashboard",
    dispatcher: "/dispatch",
    fleet_manager: "/dashboard",
    finance_officer: "/dashboard",
    corporate_hr: "/corporate",
    driver: "/driver",
    employee: "/employee",
  };
  return routeMap[role] || "/dashboard";
}

export const config = {
  matcher: ["/((?!api|_next|favicon.ico|.*\\..*|login|register|forgot-password|reset-password).*)"],
};