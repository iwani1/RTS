import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";
import { db } from "@/db";
import { users, roles, userRoles, permissions, rolePermissions } from "@/db/schema";
import { eq, and } from "drizzle-orm";

const JWT_SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET || "your-super-secret-jwt-key-change-in-production"
);

const COOKIE_NAME = "tms_session";
const COOKIE_MAX_AGE = 7 * 24 * 60 * 60; // 7 days

export interface SessionUser {
  id: number;
  email: string;
  firstName: string;
  lastName: string;
  role: string;
  status: string;
  companyId?: number;
  permissions: string[];
}

export async function createSession(user: SessionUser): Promise<string> {
  const token = await new SignJWT({
    id: user.id,
    email: user.email,
    firstName: user.firstName,
    lastName: user.lastName,
    role: user.role,
    status: user.status,
    companyId: user.companyId,
    permissions: user.permissions,
  })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("7d")
    .sign(JWT_SECRET);

  const cookieStore = await cookies();
  cookieStore.set(COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: COOKIE_MAX_AGE,
    path: "/",
  });

  return token;
}

export async function getSession(): Promise<SessionUser | null> {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get(COOKIE_NAME)?.value;

    if (!token) return null;

    const { payload } = await jwtVerify(token, JWT_SECRET);
    return payload as unknown as SessionUser;
  } catch {
    return null;
  }
}

export async function destroySession(): Promise<void> {
  const cookieStore = await cookies();
  cookieStore.delete(COOKIE_NAME);
}

export async function getCurrentUser(): Promise<SessionUser | null> {
  return getSession();
}

export async function requireAuth(): Promise<SessionUser> {
  const session = await getSession();
  if (!session) {
    throw new Error("Unauthorized");
  }
  return session;
}

export async function requireRole(allowedRoles: string[]): Promise<SessionUser> {
  const session = await requireAuth();
  if (!allowedRoles.includes(session.role)) {
    throw new Error("Forbidden: Insufficient role permissions");
  }
  return session;
}

export async function requirePermission(resource: string, action: string): Promise<SessionUser> {
  const session = await requireAuth();
  
  // Super admin has all permissions
  if (session.role === "super_admin") {
    return session;
  }

  // Check if user has the specific permission via their role
  const userRole = await db.query.userRoles.findFirst({
    where: eq(userRoles.userId, session.id),
  });

  if (!userRole) {
    throw new Error("Forbidden: No role assigned");
  }

  const rolePerms = await db.query.rolePermissions.findMany({
    where: eq(rolePermissions.roleId, userRole.roleId),
    with: { permission: true },
  });

  const hasPermission = rolePerms.some(
    (rp) =>
      rp.permission?.resource === resource && rp.permission?.action === action
  );

  if (!hasPermission) {
    throw new Error("Forbidden: Insufficient permissions");
  }

  return session;
}

export async function hashPassword(password: string): Promise<string> {
  const bcrypt = await import("bcryptjs");
  return bcrypt.hash(password, 12);
}

export async function verifyPassword(
  plainPassword: string,
  hashedPassword: string
): Promise<boolean> {
  const bcrypt = await import("bcryptjs");
  return bcrypt.compare(plainPassword, hashedPassword);
}

export function generateOTP(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

export function generateBookingReference(): string {
  const prefix = "TMS";
  const random = Math.floor(100000 + Math.random() * 900000).toString();
  const timestamp = Date.now().toString().slice(-6);
  return `${prefix}-${random}-${timestamp}`;
}