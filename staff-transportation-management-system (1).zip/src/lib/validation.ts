import { z } from "zod";

export const loginSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

export const registerSchema = z.object({
  email: z.string().email("Invalid email address"),
  phone: z.string().min(10, "Invalid phone number"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  role: z.string().default("employee"),
  companyId: z.coerce.number().optional(),
});

export const companySchema = z.object({
  name: z.string().min(1, "Company name is required"),
  registrationNumber: z.string().optional(),
  taxId: z.string().optional(),
  email: z.string().email("Invalid email").optional().or(z.literal("")),
  phone: z.string().optional(),
  address: z.string().optional(),
  city: z.string().optional(),
  country: z.string().default("Ghana"),
  currency: z.string().default("GHS"),
  status: z.string().default("active"),
});

export const employeeSchema = z.object({
  employeeId: z.string().min(1, "Employee ID is required"),
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  email: z.string().email("Invalid email").optional().or(z.literal("")),
  phone: z.string().min(10, "Invalid phone number"),
  companyId: z.coerce.number(),
  branchId: z.coerce.number().optional().nullable(),
  shiftId: z.coerce.number().optional().nullable(),
  homeAddress: z.string().optional(),
  emergencyContactName: z.string().optional(),
  emergencyContactPhone: z.string().optional(),
  isTransportEligible: z.boolean().default(true),
});

export const vehicleSchema = z.object({
  registrationNumber: z.string().min(1, "Registration number is required"),
  make: z.string().min(1, "Make is required"),
  model: z.string().min(1, "Model is required"),
  year: z.coerce.number().min(1900).max(2100),
  vehicleType: z.string(),
  fuelType: z.string().default("diesel"),
  seatingCapacity: z.coerce.number().min(1),
  standingCapacity: z.coerce.number().default(0),
  color: z.string().optional(),
  ownershipStatus: z.string().default("owned"),
  status: z.string().default("available"),
  companyId: z.coerce.number(),
  assignedDriverId: z.coerce.number().optional().nullable(),
  registrationExpiry: z.string().optional(),
  insuranceExpiry: z.string().optional(),
  roadworthinessExpiry: z.string().optional(),
});

export const driverSchema = z.object({
  employeeId: z.string().min(1, "Employee ID is required"),
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  email: z.string().email("Invalid email").optional().or(z.literal("")),
  phone: z.string().min(10, "Invalid phone number"),
  companyId: z.coerce.number(),
  licenseNumber: z.string().min(1, "License number is required"),
  licenseExpiry: z.string(),
  licenseCategory: z.string().optional(),
  hireDate: z.string(),
  emergencyContactName: z.string().optional(),
  emergencyContactPhone: z.string().optional(),
});

export const bookingSchema = z.object({
  employeeId: z.coerce.number(),
  tripId: z.coerce.number().optional().nullable(),
  routeId: z.coerce.number().optional().nullable(),
  bookingType: z.string().default("one_time"),
  pickupLocation: z.string().min(1, "Pickup location is required"),
  pickupLatitude: z.string().optional(),
  pickupLongitude: z.string().optional(),
  dropoffLocation: z.string().min(1, "Dropoff location is required"),
  dropoffLatitude: z.string().optional(),
  dropoffLongitude: z.string().optional(),
  scheduledPickupTime: z.string(),
  scheduledDropoffTime: z.string().optional(),
  tripDate: z.string(),
  isRecurring: z.boolean().default(false),
  notes: z.string().optional(),
});

export const tripSchema = z.object({
  routeId: z.coerce.number().optional().nullable(),
  vehicleId: z.coerce.number().optional().nullable(),
  driverId: z.coerce.number().optional().nullable(),
  shiftId: z.coerce.number().optional().nullable(),
  tripDate: z.string(),
  scheduledDeparture: z.string(),
  scheduledArrival: z.string().optional(),
  capacity: z.coerce.number().min(1),
  notes: z.string().optional(),
});

export const routeSchema = z.object({
  name: z.string().min(1, "Route name is required"),
  code: z.string().min(1, "Route code is required"),
  description: z.string().optional(),
  companyId: z.coerce.number(),
  shiftId: z.coerce.number().optional().nullable(),
  estimatedDurationMinutes: z.coerce.number().optional().nullable(),
  distanceKm: z.string().optional(),
});

export const shiftSchema = z.object({
  name: z.string().min(1, "Shift name is required"),
  shiftType: z.string(),
  startTime: z.string(),
  endTime: z.string(),
  reportingTime: z.string(),
  daysOfWeek: z.array(z.number()).default([1, 2, 3, 4, 5]),
  companyId: z.coerce.number(),
  isActive: z.boolean().default(true),
});

export const forgotPasswordSchema = z.object({
  email: z.string().email("Invalid email address"),
});

export const resetPasswordSchema = z.object({
  token: z.string(),
  password: z.string().min(6, "Password must be at least 6 characters"),
});