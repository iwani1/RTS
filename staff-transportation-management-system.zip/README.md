# StaffRide TMS — Enterprise Staff Transportation Management System

A production-oriented, multi-client transportation management system (TMS) for a company that runs
daily home-to-office / office-to-home staff shuttle operations. Built with **Next.js (App Router) + TypeScript +
Tailwind CSS + PostgreSQL (Drizzle ORM)**.

Everything is persisted in PostgreSQL — there are no frontend-only sample arrays, and every button, form and
dashboard action performs a real, authorised server operation.

---

## 1. Quick start

```bash
npm install
cp .env.example .env               # set DATABASE_URL
npx drizzle-kit push               # create the schema
npm run build && npm run start     # or: npm run dev
```

The demonstration dataset (3 corporate clients, ~36 employees, 12 vehicles, 10 drivers, routes, trips, bookings,
invoices, incidents, audit logs) seeds automatically the first time the login page is opened.

### Demo accounts — password `Password123!`

| Role | Email | Notes |
| --- | --- | --- |
| Super Administrator | `admin@staffridegh.com` | 2FA code `246810` |
| Operations Manager | `ops@staffridegh.com` | |
| Dispatcher | `dispatch@staffridegh.com` | |
| Fleet Manager | `fleet@staffridegh.com` | |
| Finance Officer | `finance@staffridegh.com` | |
| Corporate HR (Sikaman) | `hr@sikamanfinancial.com` | sees only its own client |
| Employee (Sikaman) | `ama@sikamanfinancial.com` | passenger app |
| Driver | `driver.kwesi@staffridegh.com` | driver app |

### Tests

```bash
node --experimental-strip-types --test tests/domain.test.ts
```

15 unit tests cover booking rules, capacity enforcement, trip state transitions, vehicle/driver recommendation,
routing heuristics, billing models, driver pay and on-time calculation.

---

## 2. Modules delivered

| Module | Status | Where |
| --- | --- | --- |
| Authentication, RBAC, 2FA, audit trail | ✅ Phase 1 | `/login`, `/register`, `/forgot-password`, `src/lib/auth.ts`, `src/lib/rbac.ts` |
| Corporate client & branch management, SLAs | ✅ Phase 1 | `/companies`, `/companies/[id]` |
| Employee register, shifts, CSV import, policies | ✅ Phase 1 | `/employees` |
| Bookings, recurring rules, waiting list, duplicates | ✅ Phase 1 | `/passenger`, `/bookings` |
| Route planning & optimisation (heuristic, VRP-ready) | ✅ Phase 1/2 | `/routes`, `src/lib/domain.ts` |
| Fleet, documents, maintenance, availability guards | ✅ Phase 1 | `/fleet` |
| Driver management & mobile duty app | ✅ Phase 1/2 | `/drivers`, `/driver`, `/driver/trip/[id]` |
| Dispatch command centre | ✅ Phase 1/2 | `/dispatch` |
| Live GPS tracking & map | ✅ Phase 2 (demo provider) | `/dispatch`, `/api/dispatch/live` |
| Boarding OTP verification, no-shows | ✅ Phase 2 | `/driver/trip/[id]` |
| Incidents, SOS, breakdown workflow, safety docs | ✅ Phase 2 | `/incidents` |
| Offline driver actions + sync | ✅ Phase 2 | `/api/driver/sync` |
| Invoicing, payments, driver payroll | ✅ Phase 3 | `/finance` |
| Analytics, CSV / print-PDF exports | ✅ Phase 3 | `/reports`, `/api/reports/export` |
| Audit trail | ✅ Phase 3 | `/audit` |
| HR / SSO integrations, OR-Tools VRP, multicurrency, native apps | ⏳ Phase 4 | see `/docs` roadmap |

---

## 3. Architecture

```
Next.js App Router (React server components)
├── (auth)          login / register / password recovery
├── (portal)        role-aware workspace shell (sidebar driven by RBAC matrix)
├── actions/        server actions — every mutation is authorised + audited
├── api/            REST: health, dispatch/live, driver/sync, reports/export, auth/logout
components/         UI primitives, app shell, SVG charts, vector map
db/                 Drizzle schema (28 tables) + pooled pg client
lib/
  auth.ts           scrypt password hashing, DB sessions, guards, audit logging
  rbac.ts           role → section / permission matrix
  domain.ts         pure business rules (no framework imports → unit testable)
  queries.ts        analytics aggregations
  seed.ts           demonstration dataset
```

**Technology substitutions** (documented deliberately):

* **Drizzle ORM** instead of Prisma — identical relational guarantees, lighter runtime, direct SQL when needed.
* **Cookie sessions + scrypt** instead of a managed auth provider — no external dependency; swap-in point is
  `src/lib/auth.ts` only.
* **Polling REST feed** instead of WebSockets — works on serverless/containers; the `LiveMap` component polls
  `/api/dispatch/live` every 15 s and can be replaced by a socket subscription without touching the UI.
* **PWA-ready responsive web** for drivers and passengers; the offline queue API is already implemented.

## 4. Security & privacy

* Server-side authorisation on every action (`requirePermission`, `guard()`), plus tenant scoping on `companyId`.
* Passwords hashed with scrypt (per-user salt, timing-safe comparison); sessions are DB-backed with 7 day expiry.
* 2FA required for privileged roles (super admin, ops manager, finance).
* Home addresses, phone numbers and GPS history are only exposed to the roles that need them (a driver sees
  passengers only on their own duty).
* Every mutation writes an audit log entry with actor, entity, tenant and payload.
* Retention: GPS events 90 days, audit logs 24 months, sessions 7 days.

## 5. Further reading

* `docs/API.md` — REST + server action reference, request/response shapes.
* `docs/OPERATIONS.md` — SOPs, rollout plan, phased roadmap with effort estimates, runbook.
* `/docs` — the same documentation rendered in-app.
