import Link from "next/link";

export const metadata = { title: "Documentation" };

const NAVY = "text-navy-800 dark:text-teal-300";

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mt-10 scroll-mt-20" id={title.toLowerCase().replace(/[^a-z0-9]+/g, "-")}>
      <h2 className={`text-xl font-semibold ${NAVY}`}>{title}</h2>
      <div className="mt-3 space-y-3 text-sm leading-relaxed text-slate-600 dark:text-slate-300">{children}</div>
    </section>
  );
}

function Code({ children }: { children: React.ReactNode }) {
  return (
    <pre className="overflow-x-auto rounded-lg bg-navy-950 p-4 text-xs leading-relaxed text-navy-100">
      <code>{children}</code>
    </pre>
  );
}

export default function DocsPage() {
  return (
    <div className="mx-auto max-w-4xl px-6 py-10">
      <nav className="flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-teal-500 font-bold text-navy-950">SR</span>
          <span className="font-semibold text-navy-900 dark:text-white">StaffRide TMS</span>
        </Link>
        <Link href="/login" className="rounded-lg bg-navy-800 px-4 py-2 text-sm font-medium text-white dark:bg-teal-600">
          Sign in
        </Link>
      </nav>

      <h1 className="mt-10 text-3xl font-semibold text-navy-900 dark:text-white">Platform documentation</h1>
      <p className="mt-3 text-sm text-slate-600 dark:text-slate-300">
        Enterprise staff transportation management system for multi-client shuttle operations. Phase 1 MVP is fully
        implemented with persisted data; Phase 2 operations and Phase 3 finance modules are implemented against clearly
        labelled demo provider interfaces.
      </p>

      <Section title="Architecture">
        <p>
          Next.js (App Router) with React server components, TypeScript and Tailwind CSS. Business logic lives in
          framework-free modules so it can be unit tested and later extracted into a service layer.
        </p>
        <Code>{`src/
  app/
    (auth)/          login, register, password recovery
    (portal)/        role aware workspace (dashboard, dispatch, trips, bookings,
                     routes, employees, companies, fleet, drivers, incidents,
                     finance, reports, audit, settings, passenger, driver)
    actions/         server actions (admin, ops, auth) — authorisation enforced
    api/             REST endpoints: health, dispatch/live, driver/sync,
                     reports/export, auth/logout
  components/        UI primitives, shell, charts, vector map
  db/                Drizzle schema + pooled client
  lib/
    auth.ts          sessions (scrypt hashes), RBAC guards, audit logging
    rbac.ts          role → section/permission matrix
    domain.ts        pure business rules (capacity, routing, pricing, OTP)
    queries.ts       analytics aggregations
    seed.ts          demonstration dataset
tests/               node:test unit tests for booking/capacity/billing rules`}</Code>
        <p>
          Substitutions from the suggested stack: <strong>Drizzle ORM</strong> instead of Prisma (same relational
          guarantees, lighter runtime, first-class SQL escape hatch), <strong>cookie sessions with scrypt</strong>{" "}
          instead of a managed auth provider (no external dependency, easy to swap for Auth0/Clerk), and{" "}
          <strong>polling REST feed</strong> instead of WebSockets (deploy-friendly, upgrade path documented).
        </p>
      </Section>

      <Section title="Roles and access">
        <ul className="list-inside list-disc space-y-1">
          <li><strong>Super Administrator</strong> — full platform access including audit trail and user administration.</li>
          <li><strong>Operations Manager</strong> — clients, employees, routes, trips, dispatch, bookings, incidents.</li>
          <li><strong>Dispatcher</strong> — dispatch board, trip lifecycle, booking decisions, incident handling.</li>
          <li><strong>Corporate HR Administrator</strong> — own company only: employees, bookings, trips, invoices, reports.</li>
          <li><strong>Fleet Manager</strong> — vehicles, maintenance, drivers, incidents.</li>
          <li><strong>Finance Officer</strong> — invoicing, payments, driver payroll, reports.</li>
          <li><strong>Driver</strong> — own assignments, manifests, boarding verification, incident reporting.</li>
          <li><strong>Employee / Passenger</strong> — own bookings, boarding codes, tracking, feedback.</li>
        </ul>
        <p>
          Authorisation is enforced server side on every mutating action (<code>requirePermission</code> /
          <code>guard()</code>) and again in the navigation matrix; tenant isolation is applied by scoping every query
          on <code>companyId</code>.
        </p>
      </Section>

      <Section title="Data model">
        <Code>{`companies ─┬─ company_branches ──┐
           ├─ employee_shifts  ┌──┴────────────┐
           ├─ employees ───────┤  trips        │
           ├─ stops            │  bookings ────┤ (trip_id, capacity guarded)
           ├─ routes ─ route_stops ┘            │
           ├─ service_agreements                │
           ├─ invoices ─ invoice_lines          │
           ├─ payments                          │
           └─ incidents                         │
users ─ sessions / password_resets / audit_logs / notifications
vehicles ─ maintenance_records ─ gps_events
drivers ─ driver_shifts / driver_earnings
passenger_boardings (booking_id, trip_id) unique per trip`}</Code>
        <p>
          Foreign keys use <code>on delete cascade</code> for owned children and <code>set null</code> for optional
          references. Hot lookup paths are indexed: <code>trips(trip_date,status)</code>,{" "}
          <code>bookings(company_id,booking_date)</code>, <code>gps_events(trip_id,recorded_at)</code>,{" "}
          <code>audit_logs(created_at)</code>. Retention: GPS events 90 days, audit logs 24 months, sessions 7 days.
        </p>
      </Section>

      <Section title="Core workflows">
        <ol className="list-inside list-decimal space-y-2">
          <li>
            <strong>Morning pickup.</strong> Employee books home→office → duplicate and policy validation → approval →
            planner clusters by zone, sequences stops (nearest neighbour), sizes the vehicle and recommends a driver →
            departure time derived from shift start minus route duration minus buffer → driver and passengers notified →
            driver starts the trip → boarding verified with the passenger&apos;s 6-digit code → completion accrues
            analytics and driver earnings.
          </li>
          <li>
            <strong>Evening drop-off.</strong> Confirmed passengers are allocated to return corridors, the driver
            receives the manifest, and each drop-off confirmation is recorded against the trip.
          </li>
          <li>
            <strong>Breakdown.</strong> Driver reports from the app → trip flips to <code>breakdown</code> and dispatch
            is alerted → dispatcher reassigns an available vehicle (capacity permitting) → passengers are notified of the
            replacement → incident is closed with the action taken.
          </li>
          <li>
            <strong>Missed pickup / no-show.</strong> Driver records a no-show, the seat is released, the booking is
            flagged and the client report reflects it.
          </li>
          <li>
            <strong>Monthly billing.</strong> Completed trips for the period are aggregated per pricing model
            (per passenger / per trip / per km / fixed retainer), 15% VAT applied, invoice issued and payments
            reconciled; driver payroll accrues per completed trip with overtime.
          </li>
        </ol>
      </Section>

      <Section title="API reference">
        <Code>{`GET  /api/health                  liveness + database check
POST /api/auth/logout             destroy session (303 redirect)
GET  /api/dispatch/live           live positions + active trip feed (RBAC)
POST /api/driver/sync             offline queue replay: positions, boardings,
                                  no-shows (idempotent via clientRef)
GET  /api/reports/export?type=    operating | trips | bookings | payroll
      &from=&to=&company=          CSV download (RBAC + tenant scope)

Server actions (form posts, same authorisation model):
  admin.createCompanyAction, admin.createEmployeeAction,
  admin.importEmployeesAction, admin.createVehicleAction,
  admin.scheduleMaintenanceAction, admin.createDriverAction,
  admin.createRouteAction, admin.inviteUserAction,
  admin.generateInvoiceAction, admin.recordPaymentAction
  ops.planTripsAction, ops.createTripAction, ops.assignResourcesAction,
  ops.updateTripStatusAction, ops.decideBookingAction, ops.moveBookingAction,
  ops.createIncidentAction, ops.confirmBoardingAction, ops.markNoShowAction,
  ops.driverTripAction, ops.setAvailabilityAction,
  ops.createBookingAction, ops.cancelOwnBookingAction, ops.submitFeedbackAction`}</Code>
      </Section>

      <Section title="Configuration">
        <Code>{`DATABASE_URL=postgresql://user:pass@host:5432/tms     # required
NEXT_PUBLIC_MAP_PROVIDER=mapbox|google                # optional
NEXT_PUBLIC_MAPBOX_TOKEN=...                          # optional (basemap)
PAYSTACK_SECRET_KEY=...                               # optional (payments)
FLUTTERWAVE_SECRET_KEY=...                            # optional (payments)
SMS_GATEWAY_URL=...                                   # optional (notifications)
SMTP_URL=...                                          # optional (email)`}</Code>
        <p>
          Anything not configured falls back to a clearly labelled demo implementation: the vector map renders in-app,
          payment records are reconciliation entries only, notifications persist in-app, and GPS positions come from the
          driver app or manual dispatcher entry.
        </p>
      </Section>

      <Section title="Standard operating procedures">
        <ul className="list-inside list-disc space-y-1">
          <li><strong>05:00</strong> Dispatcher opens the dispatch board, reviews driver availability and vehicle status.</li>
          <li><strong>05:15</strong> Run the planner for home→office; review seat fill and move waitlisted passengers onto spare capacity.</li>
          <li><strong>05:30 – 09:00</strong> Monitor departures; delays are flagged by drivers and passengers notified automatically.</li>
          <li><strong>09:00</strong> Close morning exceptions (no-shows, breakdowns) with an incident note.</li>
          <li><strong>16:30</strong> Plan the office→home return legs from the day&apos;s confirmed passengers.</li>
          <li><strong>Month end</strong> Generate invoices per client, reconcile payments, approve driver payroll and export CSV.</li>
        </ul>
      </Section>

      <Section title="Roadmap">
        <table className="w-full text-left text-xs">
          <thead className="text-slate-500">
            <tr>
              <th className="py-2">Phase</th>
              <th>Status</th>
              <th>Content</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
            <tr>
              <td className="py-2 font-medium">Phase 1 — MVP</td>
              <td className="text-emerald-600">Delivered</td>
              <td>Auth + RBAC, clients, employees, fleet, drivers, bookings, routes, trips, dispatch, passenger and driver apps, PostgreSQL persistence, seed data.</td>
            </tr>
            <tr>
              <td className="py-2 font-medium">Phase 2 — Live ops</td>
              <td className="text-emerald-600">Delivered (demo providers)</td>
              <td>GPS feed + live map, dispatch polling, notifications, boarding OTP, planner improvements, driver availability, incidents, offline queue sync.</td>
            </tr>
            <tr>
              <td className="py-2 font-medium">Phase 3 — Finance</td>
              <td className="text-emerald-600">Delivered</td>
              <td>Invoices, payments, driver earnings, payroll export, maintenance reminders, SLA records, analytics and CSV/print exports.</td>
            </tr>
            <tr>
              <td className="py-2 font-medium">Phase 4 — Scale</td>
              <td className="text-amber-600">Pending</td>
              <td>HR/SSO integrations (SAML/OIDC), OR-Tools VRP service, live traffic, multicurrency, native mobile apps, queue workers, observability stack.</td>
            </tr>
          </tbody>
        </table>
      </Section>

      <Section title="Known limitations">
        <ul className="list-inside list-disc space-y-1">
          <li>Mapping, SMS, email and payment providers are stubbed behind documented interfaces until credentials are supplied.</li>
          <li>Recurring bookings are stored as a rule on the booking; a scheduler job is required to expand them into daily instances.</li>
          <li>Geofenced arrival detection is modelled (arrival timestamps, grace windows) but requires a telematics feed for automation.</li>
          <li>Two-factor authentication uses a server-side code for the demo; production should use TOTP or SMS.</li>
        </ul>
      </Section>

      <p className="mt-10 text-xs text-slate-400">
        See <code>README.md</code>, <code>docs/API.md</code>, <code>docs/OPERATIONS.md</code> and{" "}
        <code>tests/domain.test.ts</code> in the repository for the full deliverables.
      </p>
    </div>
  );
}
