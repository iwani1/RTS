import Link from "next/link";
import { and, desc, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { bookings, drivers, employees, gpsEvents, trips, vehicles } from "@/db/schema";
import { ActionForm, InlineActionForm } from "@/components/action-form";
import { MapCanvas, type MapPoint } from "@/components/live-map";
import { Card, DemoNotice, EmptyState, Field, LinkButton, PageHeader, StatCard, StatusBadge, Table, Td } from "@/components/ui";
import { cancelOwnBookingAction, submitFeedbackAction, createIncidentAction } from "@/app/actions/ops";
import { requireSection } from "@/lib/auth";
import { dateOnly, humanize, minutesBetween, timeOnly } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function PassengerTripsPage() {
  const user = await requireSection("passenger");
  const [employee] = await db.select().from(employees).where(eq(employees.userId, user.id)).limit(1);

  if (!employee) {
    return (
      <div>
        <PageHeader title="My trips" />
        <Card title="No employee record linked">
          <p className="text-sm text-slate-600 dark:text-slate-300">Ask HR to link your account, then return here.</p>
          <div className="mt-4">
            <LinkButton href="/passenger">Back</LinkButton>
          </div>
        </Card>
      </div>
    );
  }

  const rows = await db
    .select({ booking: bookings, trip: trips, vehicle: vehicles, driver: drivers })
    .from(bookings)
    .leftJoin(trips, eq(trips.id, bookings.tripId))
    .leftJoin(vehicles, eq(vehicles.id, trips.vehicleId))
    .leftJoin(drivers, eq(drivers.id, trips.driverId))
    .where(eq(bookings.employeeId, employee.id))
    .orderBy(desc(bookings.bookingDate), desc(bookings.id))
    .limit(30);

  const active = rows.filter((r) => r.trip && ["dispatching", "in_progress", "delayed"].includes(r.trip.status));
  const upcoming = rows.filter((r) => r.booking.status === "assigned" || r.booking.status === "approved");
  const completed = rows.filter((r) => ["completed", "no_show", "cancelled"].includes(r.booking.status));

  const activeTripIds = active.map((a) => a.trip!.id);
  const positions = activeTripIds.length
    ? await db
        .select({ tripId: gpsEvents.tripId, lat: gpsEvents.lat, lng: gpsEvents.lng, recordedAt: gpsEvents.recordedAt })
        .from(gpsEvents)
        .where(inArray(gpsEvents.tripId, activeTripIds))
        .orderBy(desc(gpsEvents.recordedAt))
        .limit(60)
    : [];

  const points: MapPoint[] = positions.slice(0, 1).map((p) => ({
    id: `p${p.tripId}`,
    lat: p.lat,
    lng: p.lng,
    label: "Your vehicle",
    kind: "vehicle",
    tone: "teal",
  }));
  if (employee.homeLat && employee.homeLng) {
    points.push({ id: "home", lat: employee.homeLat, lng: employee.homeLng, label: "Home pickup", kind: "stop", tone: "amber" });
  }

  return (
    <div>
      <PageHeader
        title="My trips & boarding"
        subtitle="Live tracking, driver details, your secure boarding code and trip history."
        actions={<LinkButton href="/passenger">Book transport</LinkButton>}
      />

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Active journey" value={active.length ? "Yes" : "None"} tone={active.length ? "info" : "default"} icon="🚏" />
        <StatCard label="Confirmed upcoming" value={upcoming.length} icon="🎫" />
        <StatCard label="Completed" value={completed.filter((c) => c.booking.status === "completed").length} tone="positive" icon="✅" />
        <StatCard label="Cancelled / no-show" value={completed.filter((c) => c.booking.status !== "completed").length} icon="🚫" />
      </div>

      {active.length ? (
        <div className="mt-6 grid gap-4 lg:grid-cols-3">
          {active.map((a) => {
            const eta = a.trip?.scheduledArrival ? minutesBetween(a.trip.scheduledArrival, new Date()) : 0;
            return (
              <Card key={a.booking.id} title="Live journey" subtitle={`${a.trip!.reference} · ${humanize(a.trip!.direction)}`}>
                <DefinitionListLike
                  items={[
                    { label: "Vehicle", value: a.vehicle ? `${a.vehicle.registrationNo} · ${a.vehicle.make} ${a.vehicle.model}` : "—" },
                    { label: "Driver", value: a.driver ? `${a.driver.fullName}` : "—" },
                    { label: "Driver contact", value: a.driver?.phone ?? "—" },
                    { label: "Departed", value: timeOnly(a.trip!.actualDeparture) },
                    { label: "Scheduled arrival", value: timeOnly(a.trip!.scheduledArrival) },
                    { label: "Status", value: <StatusBadge status={a.trip!.status} /> },
                  ]}
                />
                <p className="mt-3 text-xs text-slate-500">
                  {eta > 0 ? `Running about ${eta} minute(s) behind the planned arrival.` : "On schedule."}
                </p>
                <InlineActionForm
                  action={createIncidentAction}
                  hiddenFields={{ tripId: a.trip!.id, type: "sos", severity: "critical" }}
                  submitLabel="🆘 Raise SOS"
                  variant="danger"
                  confirm="Send an SOS alert to dispatch for this trip?"
                />
              </Card>
            );
          })}
          <Card title="Vehicle position" className="lg:col-span-2">
            {points.length ? <MapCanvas points={points} height={300} /> : <EmptyState title="No position reported yet" />}
            <DemoNotice>
              Live tracking shows the last position the driver shared. Configure a mapping provider key for a road
              basemap and turn-by-turn context.
            </DemoNotice>
          </Card>
        </div>
      ) : null}

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <Card title="Boarding codes & upcoming trips" className="lg:col-span-2" padded={false}>
          <Table head={["Trip", "Date", "Pickup", "Vehicle & driver", "Boarding code", "Status"]}>
            {[...active, ...upcoming].map((r) => (
              <tr key={r.booking.id}>
                <Td className="text-xs">{r.trip?.reference ?? "awaiting assignment"}</Td>
                <Td className="text-xs">{dateOnly(r.booking.bookingDate)}</Td>
                <Td className="text-xs">
                  {r.booking.pickupTime ?? "to be confirmed"}
                  <p className="text-slate-400">{r.booking.pickupAddress?.slice(0, 26) ?? "—"}</p>
                </Td>
                <Td className="text-xs">
                  {r.vehicle?.registrationNo ?? "—"}
                  <p className="text-slate-400">{r.driver?.fullName ?? "—"}</p>
                </Td>
                <Td className="font-mono text-sm font-semibold tracking-widest text-navy-800 dark:text-teal-300">{r.booking.otpCode ?? "—"}</Td>
                <Td>
                  <StatusBadge status={r.booking.status} />
                </Td>
              </tr>
            ))}
          </Table>
          {!active.length && !upcoming.length ? <div className="p-4"><EmptyState title="No upcoming trips" /></div> : null}
        </Card>

        <div className="space-y-4">
          <Card title="Cancel an eligible booking">
            <ActionForm action={cancelOwnBookingAction} submitLabel="Cancel booking">
              <Field
                label="Booking"
                name="bookingId"
                required
                options={[...active, ...upcoming]
                  .filter((r) => ["pending", "approved", "waitlisted"].includes(r.booking.status))
                  .map((r) => ({ value: String(r.booking.id), label: `${r.booking.reference} · ${dateOnly(r.booking.bookingDate)}` }))}
              />
              <div className="mt-3">
                <Field label="Reason" name="reason" rows={2} placeholder="Travelling, changed shift…" />
              </div>
            </ActionForm>
          </Card>

          <Card title="Rate a journey" subtitle="Feedback reaches the transport team">
            <ActionForm action={submitFeedbackAction} submitLabel="Submit feedback" resetOnSuccess>
              <div className="space-y-3">
                <Field
                  label="Trip"
                  name="tripId"
                  options={[{ value: "", label: "General feedback" }, ...completed.filter((c) => c.trip).map((c) => ({ value: String(c.trip!.id), label: `${c.trip!.reference} · ${dateOnly(c.booking.bookingDate)}` }))]}
                />
                <Field label="Type" name="category" options={[{ value: "feedback", label: "Feedback" }, { value: "complaint", label: "Complaint" }]} />
                <Field label="Rating" name="rating" options={["5", "4", "3", "2", "1"].map((r) => ({ value: r, label: `${r} star${r === "1" ? "" : "s"}` }))} />
                <Field label="Comments" name="comments" rows={3} required />
              </div>
            </ActionForm>
          </Card>

          <Card title="Emergency contacts">
            <ul className="space-y-1 text-xs text-slate-500">
              <li>Transport control room: +233 30 200 1122</li>
              <li>Dispatcher on duty: +233 24 111 0003</li>
              <li>
                <Link href="/incidents" className="text-teal-700 underline dark:text-teal-400">
                  Report a safety concern
                </Link>
              </li>
            </ul>
          </Card>
        </div>
      </div>

      <Card className="mt-6" title="Completed trips" padded={false}>
        <Table head={["Reference", "Date", "Leg", "Trip", "Status"]}>
          {completed.map((c) => (
            <tr key={c.booking.id}>
              <Td className="text-xs">{c.booking.reference}</Td>
              <Td className="text-xs">{dateOnly(c.booking.bookingDate)}</Td>
              <Td className="text-xs">{humanize(c.booking.direction)}</Td>
              <Td className="text-xs">{c.trip?.reference ?? "—"}</Td>
              <Td>
                <StatusBadge status={c.booking.status} />
              </Td>
            </tr>
          ))}
        </Table>
        {!completed.length ? <div className="p-4"><EmptyState title="No completed trips yet" /></div> : null}
      </Card>
    </div>
  );
}

function DefinitionListLike({ items }: { items: Array<{ label: string; value: React.ReactNode }> }) {
  return (
    <dl className="space-y-2">
      {items.map((i) => (
        <div key={i.label} className="flex items-center justify-between gap-3 text-sm">
          <dt className="text-xs uppercase tracking-wide text-slate-400">{i.label}</dt>
          <dd className="text-right font-medium text-slate-800 dark:text-slate-200">{i.value}</dd>
        </div>
      ))}
    </dl>
  );
}
