import Link from "next/link";
import { and, desc, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { bookings, companies, employees, incidents, routes, serviceAgreements, shifts, trips, vehicles, drivers } from "@/db/schema";
import { ActionForm, InlineActionForm } from "@/components/action-form";
import { Card, DefinitionList, DemoNotice, EmptyState, Field, LinkButton, PageHeader, StatCard, StatusBadge, Table, Td } from "@/components/ui";
import { cancelOwnBookingAction, createBookingAction, updateHomeAddressAction } from "@/app/actions/ops";
import { requireSection } from "@/lib/auth";
import { dateOnly, humanize, timeOnly, todayISO } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function PassengerPage() {
  const user = await requireSection("passenger");

  const [employee] = await db.select().from(employees).where(eq(employees.userId, user.id)).limit(1);

  if (!employee) {
    return (
      <div>
        <PageHeader title="My transport" subtitle="Employee self service" />
        <Card title="No employee record linked">
          <p className="text-sm text-slate-600 dark:text-slate-300">
            Your login is not yet linked to an employee record. Ask your HR / transport coordinator to register you, then
            sign in again — the link happens automatically when your work email matches.
          </p>
          <div className="mt-4">
            <LinkButton href="/settings">Account settings</LinkButton>
          </div>
        </Card>
      </div>
    );
  }

  const today = todayISO();
  const [shift] = employee.shiftId ? await db.select().from(shifts).where(eq(shifts.id, employee.shiftId)).limit(1) : [];
  const [company] = await db.select().from(companies).where(eq(companies.id, employee.companyId)).limit(1);
  const [agreement] = await db.select().from(serviceAgreements).where(eq(serviceAgreements.companyId, employee.companyId)).limit(1);

  const upcoming = await db
    .select({ booking: bookings, trip: trips, vehicle: vehicles, driver: drivers, route: routes.name })
    .from(bookings)
    .leftJoin(trips, eq(trips.id, bookings.tripId))
    .leftJoin(vehicles, eq(vehicles.id, trips.vehicleId))
    .leftJoin(drivers, eq(drivers.id, trips.driverId))
    .leftJoin(routes, eq(routes.id, bookings.routeId))
    .where(and(eq(bookings.employeeId, employee.id), inArray(bookings.status, ["pending", "approved", "waitlisted", "assigned", "in_progress"])))
    .orderBy(bookings.bookingDate)
    .limit(8);

  const history = await db
    .select({ booking: bookings, trip: trips })
    .from(bookings)
    .leftJoin(trips, eq(trips.id, bookings.tripId))
    .where(and(eq(bookings.employeeId, employee.id), inArray(bookings.status, ["completed", "cancelled", "no_show"])))
    .orderBy(desc(bookings.bookingDate))
    .limit(10);

  const routeOptions = await db.select({ id: routes.id, name: routes.name, direction: routes.direction }).from(routes).where(eq(routes.companyId, employee.companyId));

  return (
    <div>
      <PageHeader
        title={`Good day, ${employee.fullName.split(" ")[0]}`}
        subtitle={`${company?.name ?? "Your company"} · ${employee.employeeCode}${shift ? ` · ${shift.name}` : ""}`}
        actions={<LinkButton href="/passenger/trips">My trips & boarding code</LinkButton>}
      />

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Bookings on record" value={history.length + upcoming.length} icon="🎫" />
        <StatCard label="Completed journeys" value={history.filter((h) => h.booking.status === "completed").length} tone="positive" icon="✅" />
        <StatCard label="Upcoming" value={upcoming.length} tone="info" icon="🚌" />
        <StatCard label="Pickup zone" value={employee.zone ?? "Not set"} icon="📍" />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <Card title="Book transport" subtitle="Home to office, office to home or an ad-hoc request" className="lg:col-span-2">
          <ActionForm action={createBookingAction} submitLabel="Request transport" resetOnSuccess>
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Date of travel" name="bookingDate" type="date" required defaultValue={today} />
              <Field
                label="Trip direction"
                name="direction"
                options={[
                  { value: "home_to_office", label: "Home → Office (morning pickup)" },
                  { value: "office_to_home", label: "Office → Home (drop-off)" },
                  { value: "ad_hoc", label: "Ad-hoc / special request" },
                ]}
              />
              <Field label="Preferred pickup time" name="requestedTime" type="time" defaultValue={shift?.startTime ?? "07:00"} hint="Final time is confirmed after route planning." />
              <Field
                label="Repeat"
                name="recurring"
                options={[
                  { value: "none", label: "One time" },
                  { value: "daily", label: "Every working day" },
                  { value: "weekly", label: "Weekly" },
                  { value: "monthly", label: "Monthly" },
                ]}
              />
              <Field
                label="Preferred corridor (optional)"
                name="routeId"
                options={[{ value: "", label: "Let the planner choose" }, ...routeOptions.map((r) => ({ value: String(r.id), label: r.name }))]}
                className="sm:col-span-2"
              />
              <Field label="Notes for the transport team" name="notes" rows={2} className="sm:col-span-2" placeholder="e.g. I have a client meeting and need the earliest pickup" />
            </div>
          </ActionForm>
          <DemoNotice>
            Boarding codes are generated for every booking. Duplicate bookings for the same date and direction are
            rejected automatically.
          </DemoNotice>
        </Card>

        <div className="space-y-4">
          <Card title="My profile & saved addresses">
            <DefinitionList
              items={[
                { label: "Employee code", value: employee.employeeCode },
                { label: "Department", value: employee.department ?? "—" },
                { label: "Job title", value: employee.jobTitle ?? "—" },
                { label: "Work shift", value: shift ? `${shift.name}` : "—" },
                { label: "Home address", value: employee.homeAddress ?? "—" },
                { label: "VIP entitlement", value: employee.vip ? "Yes — priority pickup" : "Standard" },
              ]}
            />
            <div className="mt-4 border-t border-slate-100 pt-4 dark:border-slate-800">
              <ActionForm action={updateHomeAddressAction} submitLabel="Update home address">
                <div className="space-y-3">
                  <Field label="Home address" name="homeAddress" defaultValue={employee.homeAddress} required />
                  <Field label="Pickup zone" name="zone" defaultValue={employee.zone} placeholder="Dansoman" />
                  <div className="grid grid-cols-2 gap-2">
                    <Field label="Latitude" name="homeLat" type="number" step="0.0001" defaultValue={employee.homeLat} />
                    <Field label="Longitude" name="homeLng" type="number" step="0.0001" defaultValue={employee.homeLng} />
                  </div>
                </div>
              </ActionForm>
            </div>
          </Card>

          <Card title="Company transport policy">
            <ul className="list-inside list-disc space-y-1 text-xs text-slate-500">
              <li>One seat per employee per leg.</li>
              <li>Be at the pickup point 5 minutes before the confirmed time.</li>
              <li>Cancellations are accepted up to {agreement?.cancellationPolicyHours ?? 2} hours before departure.</li>
              <li>Pickup deviation target ±{agreement?.maxPickupDeviationMinutes ?? 10} minutes.</li>
              <li>Report safety concerns immediately — the SOS option is always available in the trip view.</li>
            </ul>
          </Card>
        </div>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <Card title="Upcoming bookings" padded={false}>
          <Table head={["Reference", "Date", "Leg", "Pickup", "Status", ""]}>
            {upcoming.map((u) => (
              <tr key={u.booking.id}>
                <Td className="text-xs font-medium">{u.booking.reference}</Td>
                <Td className="text-xs">{dateOnly(u.booking.bookingDate)}</Td>
                <Td className="text-xs">{humanize(u.booking.direction)}</Td>
                <Td className="text-xs">
                  {u.booking.pickupTime ?? "to be confirmed"}
                  {u.vehicle ? <p className="text-slate-400">{u.vehicle.registrationNo}</p> : null}
                  {u.driver ? <p className="text-slate-400">{u.driver.fullName}</p> : null}
                </Td>
                <Td>
                  <StatusBadge status={u.booking.status} />
                </Td>
                <Td>
                  {["pending", "approved", "waitlisted"].includes(u.booking.status) ? (
                    <InlineActionForm
                      action={cancelOwnBookingAction}
                      hiddenFields={{ bookingId: u.booking.id }}
                      submitLabel="Cancel"
                      variant="ghost"
                      confirm="Cancel this booking?"
                    />
                  ) : (
                    <Link href="/passenger/trips" className="text-xs font-medium text-teal-700 hover:underline dark:text-teal-400">
                      Track →
                    </Link>
                  )}
                </Td>
              </tr>
            ))}
          </Table>
          {!upcoming.length ? <div className="p-4"><EmptyState title="No upcoming bookings" hint="Use the booking form to request transport." /></div> : null}
        </Card>

        <Card title="Trip history" padded={false}>
          <Table head={["Reference", "Date", "Leg", "Status"]}>
            {history.map((h) => (
              <tr key={h.booking.id}>
                <Td className="text-xs">{h.booking.reference}</Td>
                <Td className="text-xs">{dateOnly(h.booking.bookingDate)}</Td>
                <Td className="text-xs">{humanize(h.booking.direction)}</Td>
                <Td>
                  <StatusBadge status={h.booking.status} />
                </Td>
              </tr>
            ))}
          </Table>
          {!history.length ? <div className="p-4"><EmptyState title="No completed trips yet" /></div> : null}
        </Card>
      </div>
    </div>
  );
}
