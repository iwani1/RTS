import Link from "next/link";
import { and, asc, desc, eq, ilike, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { branches, companies, employees, shifts } from "@/db/schema";
import { ActionForm, InlineActionForm } from "@/components/action-form";
import { Card, DemoNotice, EmptyState, Field, PageHeader, StatCard, StatusBadge, Table, Td, inputClass } from "@/components/ui";
import {
  assignEmployeeShiftAction,
  createEmployeeAction,
  createShiftAction,
  importEmployeesAction,
  toggleEmployeeAction,
} from "@/app/actions/admin";
import { companyScope, requireSection } from "@/lib/auth";

export const dynamic = "force-dynamic";

const CSV_TEMPLATE = "employee_code,full_name,email,phone,department,job_title,home_address,zone,home_lat,home_lng\nSFS-2001,Kofi Amankwa,kofi@example.com,+233241110001,Finance,Officer,Dansoman Accra,Dansoman,5.5490,-0.2401";

export default async function EmployeesPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; company?: string; status?: string; page?: string }>;
}) {
  const user = await requireSection("employees");
  const scope = companyScope(user);
  const { q = "", company = "", status = "" } = await searchParams;

  const filters = [
    scope ? eq(employees.companyId, scope) : undefined,
    company && !scope ? eq(employees.companyId, Number(company)) : undefined,
    q ? or(ilike(employees.fullName, `%${q}%`), ilike(employees.employeeCode, `%${q}%`), ilike(employees.email, `%${q}%`)) : undefined,
    status === "active" ? eq(employees.active, true) : status === "inactive" ? eq(employees.active, false) : undefined,
  ].filter(Boolean);

  const rows = await db
    .select({
      employee: employees,
      company: companies.name,
      branch: branches.name,
      shift: shifts.name,
      shiftStart: shifts.startTime,
      shiftEnd: shifts.endTime,
      bookingCount: sql<number>`(select count(*) from bookings b where b.employee_id = ${employees.id})`,
    })
    .from(employees)
    .innerJoin(companies, eq(companies.id, employees.companyId))
    .leftJoin(branches, eq(branches.id, employees.branchId))
    .leftJoin(shifts, eq(shifts.id, employees.shiftId))
    .where(filters.length ? and(...filters) : undefined)
    .orderBy(asc(employees.fullName))
    .limit(100);

  const [stats] = await db
    .select({
      total: sql<number>`count(*)`,
      active: sql<number>`sum(case when ${employees.active} then 1 else 0 end)`,
      vip: sql<number>`sum(case when ${employees.vip} then 1 else 0 end)`,
      zoned: sql<number>`sum(case when ${employees.zone} is not null then 1 else 0 end)`,
      geocoded: sql<number>`sum(case when ${employees.homeLat} is not null then 1 else 0 end)`,
    })
    .from(employees)
    .where(scope ? eq(employees.companyId, scope) : undefined);

  const companyOptions = await db.select({ id: companies.id, name: companies.name }).from(companies).orderBy(asc(companies.name));
  const branchOptions = await db.select({ id: branches.id, name: branches.name, companyId: branches.companyId }).from(branches);
  const shiftOptions = await db.select({ id: shifts.id, name: shifts.name, companyId: shifts.companyId }).from(shifts).orderBy(desc(shifts.id));

  const scopedCompanyId = scope ?? (companyOptions[0]?.id ?? 0);

  return (
    <div>
      <PageHeader
        title="Employee register"
        subtitle="Company employees, their work shifts, home pickup zones and portal account links."
      />

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        <StatCard label="Registered" value={Number(stats?.total ?? 0)} icon="👥" />
        <StatCard label="Active" value={Number(stats?.active ?? 0)} tone="positive" icon="✅" />
        <StatCard label="VIP entitlement" value={Number(stats?.vip ?? 0)} tone="info" icon="⭐" />
        <StatCard label="Zoned" value={Number(stats?.zoned ?? 0)} icon="📍" hint="Used for route clustering" />
        <StatCard label="Geocoded homes" value={Number(stats?.geocoded ?? 0)} tone="warning" icon="🗺️" hint="Required for optimised routing" />
      </div>

      <Card className="mt-6" title="Search & filter">
        <form className="grid gap-3 sm:grid-cols-4" method="get">
          <input name="q" defaultValue={q} placeholder="Name, code or email" className={inputClass} />
          <select name="company" defaultValue={company} className={inputClass} disabled={Boolean(scope)}>
            <option value="">All companies</option>
            {companyOptions.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
          <select name="status" defaultValue={status} className={inputClass}>
            <option value="">Any status</option>
            <option value="active">Active only</option>
            <option value="inactive">Deactivated</option>
          </select>
          <button type="submit" className="rounded-lg bg-navy-800 px-4 py-2 text-sm font-medium text-white dark:bg-teal-600">
            Apply filters
          </button>
        </form>
      </Card>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <Card title="Employees" className="lg:col-span-2" padded={false}>
          <Table head={["Employee", "Company", "Shift", "Zone", "Bookings", "Status", ""]}>
            {rows.map((r) => (
              <tr key={r.employee.id}>
                <Td>
                  <p className="font-medium text-slate-800 dark:text-slate-200">
                    {r.employee.fullName} {r.employee.vip ? <span className="text-xs text-teal-600">VIP</span> : null}
                  </p>
                  <p className="text-xs text-slate-400">
                    {r.employee.employeeCode} · {r.employee.email ?? "no email"}
                  </p>
                  <p className="text-xs text-slate-400">{r.employee.homeAddress ?? "no address on file"}</p>
                </Td>
                <Td className="text-xs">
                  {r.company}
                  <p className="text-slate-400">{r.branch ?? "—"}</p>
                </Td>
                <Td className="text-xs">
                  {r.shift ?? "—"}
                  <p className="text-slate-400">
                    {r.shiftStart ?? ""} {r.shiftEnd ? `– ${r.shiftEnd}` : ""}
                  </p>
                </Td>
                <Td className="text-xs">{r.employee.zone ?? "—"}</Td>
                <Td className="tabular-nums text-xs">{Number(r.bookingCount)}</Td>
                <Td>
                  <StatusBadge status={r.employee.active ? "active" : "inactive"} />
                </Td>
                <Td>
                  <InlineActionForm
                    action={toggleEmployeeAction}
                    hiddenFields={{ id: r.employee.id, active: r.employee.active ? "false" : "true" }}
                    submitLabel={r.employee.active ? "Deactivate" : "Activate"}
                    variant="ghost"
                    confirm={r.employee.active ? "Deactivate this employee?" : undefined}
                  />
                </Td>
              </tr>
            ))}
          </Table>
          {!rows.length ? <div className="p-4"><EmptyState title="No employees match your filters" /></div> : null}

          <div className="border-t border-slate-100 p-4 dark:border-slate-800">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">Change an employee&apos;s work shift</p>
            <ActionForm action={assignEmployeeShiftAction} submitLabel="Assign shift">
              <div className="grid gap-3 sm:grid-cols-2">
                <Field
                  label="Employee"
                  name="id"
                  required
                  options={rows.map((r) => ({ value: String(r.employee.id), label: `${r.employee.fullName} (${r.employee.employeeCode})` }))}
                />
                <Field
                  label="Shift"
                  name="shiftId"
                  required
                  options={shiftOptions
                    .filter((s) => !scope || s.companyId === scope)
                    .map((s) => ({ value: String(s.id), label: s.name }))}
                />
              </div>
            </ActionForm>
            <p className="mt-2 text-xs text-slate-400">
              Shift start time drives the calculated pickup time during route planning.
            </p>
          </div>
        </Card>

        <div className="space-y-4">
          <Card title="Register an employee">
            <ActionForm action={createEmployeeAction} submitLabel="Register employee" resetOnSuccess>
              <div className="space-y-3">
                {!scope ? <Field label="Company" name="companyId" required options={companyOptions.map((c) => ({ value: String(c.id), label: c.name }))} /> : null}
                <Field label="Full name" name="fullName" required />
                <Field label="Employee code" name="employeeCode" hint="Leave blank to auto-generate." />
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Email" name="email" type="email" />
                  <Field label="Phone" name="phone" />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Department" name="department" />
                  <Field label="Job title" name="jobTitle" />
                </div>
                <Field label="Home address" name="homeAddress" />
                <Field label="Pickup zone" name="zone" placeholder="Dansoman" hint="Zone is used to cluster passengers into routes." />
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Home latitude" name="homeLat" type="number" step="0.0001" />
                  <Field label="Home longitude" name="homeLng" type="number" step="0.0001" />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Branch" name="branchId" options={[{ value: "", label: "—" }, ...branchOptions.filter((b) => !scope || b.companyId === scope).map((b) => ({ value: String(b.id), label: b.name }))]} />
                  <Field label="Shift" name="shiftId" options={[{ value: "", label: "—" }, ...shiftOptions.filter((s) => !scope || s.companyId === scope).map((s) => ({ value: String(s.id), label: s.name }))]} />
                </div>
                <label className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300">
                  <input type="checkbox" name="vip" className="rounded" /> VIP / priority transport entitlement
                </label>
              </div>
            </ActionForm>
          </Card>

          <Card title="Bulk CSV import" subtitle="Header row required">
            <DemoNotice>
              Paste CSV content. In production this form accepts a file upload and runs asynchronously with row level validation.
            </DemoNotice>
            <ActionForm action={importEmployeesAction} submitLabel="Import employees" className="mt-3">
              {!scope ? <Field label="Company" name="companyId" required options={companyOptions.map((c) => ({ value: String(c.id), label: c.name }))} /> : null}
              <Field label="CSV data" name="csv" rows={6} placeholder={CSV_TEMPLATE} className="mt-3" />
            </ActionForm>
            <pre className="mt-3 overflow-x-auto rounded-lg bg-slate-50 p-2 text-[10px] leading-relaxed text-slate-500 dark:bg-slate-950">{CSV_TEMPLATE}</pre>
          </Card>

          <Card title="Configure a work shift">
            <ActionForm action={createShiftAction} submitLabel="Save shift">
              {!scope ? <Field label="Company" name="companyId" required options={companyOptions.map((c) => ({ value: String(c.id), label: c.name }))} /> : null}
              <div className="space-y-3">
                <Field label="Shift name" name="name" required placeholder="Morning (08:00 - 17:00)" />
                <div className="grid grid-cols-3 gap-2">
                  <Field label="Start" name="startTime" type="time" required defaultValue="08:00" />
                  <Field label="End" name="endTime" type="time" required defaultValue="17:00" />
                  <Field label="Grace (min)" name="graceMinutes" type="number" defaultValue={15} />
                </div>
              </div>
            </ActionForm>
            <p className="mt-2 text-xs text-slate-400">
              Current scope: {scope ? companyOptions.find((c) => c.id === scope)?.name : "all companies"} · {shiftOptions.filter((s) => !scope || s.companyId === scope).length} shift templates
            </p>
          </Card>

          <Card title="Transport policy" subtitle={`Company ID ${scopedCompanyId}`}>
            <ul className="list-inside list-disc space-y-1 text-xs text-slate-500">
              <li>One seat per employee per leg; duplicate bookings are rejected automatically.</li>
              <li>Pickup times are derived from shift start time minus the planned route duration plus a 10 minute buffer.</li>
              <li>Cancellations inside the policy window require coordinator approval.</li>
              <li>
                Full policy configuration lives in the service agreement —{" "}
                <Link href={`/companies/${scopedCompanyId}`} className="text-teal-700 underline dark:text-teal-400">
                  open client record
                </Link>
                .
              </li>
            </ul>
          </Card>
        </div>
      </div>
    </div>
  );
}
