import Link from "next/link";
import { notFound } from "next/navigation";
import { count, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { bookings, branches, companies, employees, invoices, routes, serviceAgreements, shifts, trips } from "@/db/schema";
import { ActionForm } from "@/components/action-form";
import { Card, DefinitionList, EmptyState, Field, LinkButton, PageHeader, StatCard, StatusBadge, Table, Td } from "@/components/ui";
import { createAgreementAction, createBranchAction, updateCompanyAction } from "@/app/actions/admin";
import { requireSection } from "@/lib/auth";
import { dateOnly, money, n } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function CompanyDetailPage({ params }: { params: Promise<{ id: string }> }) {
  await requireSection("companies");
  const { id } = await params;
  const companyId = Number(id);
  if (!Number.isFinite(companyId)) notFound();

  const [company] = await db.select().from(companies).where(eq(companies.id, companyId)).limit(1);
  if (!company) notFound();

  const [branchRows, agreementRows, shiftRows, routeRows, invoiceRows, employeeStats, tripStats] = await Promise.all([
    db.select().from(branches).where(eq(branches.companyId, companyId)),
    db.select().from(serviceAgreements).where(eq(serviceAgreements.companyId, companyId)).orderBy(desc(serviceAgreements.id)),
    db.select().from(shifts).where(eq(shifts.companyId, companyId)),
    db.select().from(routes).where(eq(routes.companyId, companyId)),
    db.select().from(invoices).where(eq(invoices.companyId, companyId)).orderBy(desc(invoices.issuedAt)),
    db
      .select({
        total: count(),
        active: sql<number>`sum(case when ${employees.active} then 1 else 0 end)`,
        vip: sql<number>`sum(case when ${employees.vip} then 1 else 0 end)`,
        linked: sql<number>`sum(case when ${employees.userId} is not null then 1 else 0 end)`,
      })
      .from(employees)
      .where(eq(employees.companyId, companyId)),
    db
      .select({
        total: count(),
        completed: sql<number>`sum(case when ${trips.status} = 'completed' then 1 else 0 end)`,
        passengers: sql<number>`coalesce(sum(${trips.bookedSeats}), 0)`,
        km: sql<number>`coalesce(sum(${trips.plannedKm}), 0)`,
      })
      .from(trips)
      .where(eq(trips.companyId, companyId)),
  ]);

  const [bookingStats] = await db
    .select({
      total: count(),
      cancelled: sql<number>`sum(case when ${bookings.status} = 'cancelled' then 1 else 0 end)`,
      noShow: sql<number>`sum(case when ${bookings.status} = 'no_show' then 1 else 0 end)`,
    })
    .from(bookings)
    .where(eq(bookings.companyId, companyId));

  const invoiced = invoiceRows.reduce((s, i) => s + n(i.total), 0);
  const collected = invoiceRows.reduce((s, i) => s + n(i.amountPaid), 0);

  return (
    <div>
      <PageHeader
        title={company.name}
        subtitle={`${company.industry ?? "Corporate client"} · ${company.city ?? "Ghana"} · billing ${company.billingModel.replace(/_/g, " ")}`}
        actions={
          <>
            <LinkButton href="/companies">All clients</LinkButton>
            <LinkButton href="/employees" variant="primary">
              Manage employees
            </LinkButton>
          </>
        }
      />

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Employees" value={Number(employeeStats[0]?.total ?? 0)} hint={`${Number(employeeStats[0]?.linked ?? 0)} portal accounts linked`} icon="👥" />
        <StatCard label="Trips operated" value={Number(tripStats[0]?.total ?? 0)} hint={`${Number(tripStats[0]?.completed ?? 0)} completed`} icon="🚌" />
        <StatCard label="Passengers carried" value={Number(tripStats[0]?.passengers ?? 0)} hint={`${n(tripStats[0]?.km).toFixed(0)} km planned`} icon="🎫" />
        <StatCard label="Outstanding balance" value={money(invoiced - collected)} tone={invoiced - collected > 0 ? "warning" : "positive"} icon="💰" />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <Card title="Client profile">
          <DefinitionList
            items={[
              { label: "Primary contact", value: company.contactPerson ?? "—" },
              { label: "Email", value: company.email ?? "—" },
              { label: "Phone", value: company.phone ?? "—" },
              { label: "Status", value: <StatusBadge status={company.status} /> },
              { label: "Billing model", value: company.billingModel.replace(/_/g, " ") },
              { label: "Monthly rate", value: money(company.monthlyRate) },
              { label: "Bookings", value: `${Number(bookingStats?.total ?? 0)} (${Number(bookingStats?.cancelled ?? 0)} cancelled, ${Number(bookingStats?.noShow ?? 0)} no-shows)` },
              { label: "Registered", value: dateOnly(company.createdAt) },
            ]}
          />
          <div className="mt-4 border-t border-slate-100 pt-4 dark:border-slate-800">
            <ActionForm action={updateCompanyAction} submitLabel="Update client">
              <input type="hidden" name="id" value={company.id} />
              <div className="space-y-3">
                <Field
                  label="Status"
                  name="status"
                  options={[
                    { value: company.status, label: `Keep: ${company.status}` },
                    { value: "active", label: "Active" },
                    { value: "suspended", label: "Suspended" },
                    { value: "inactive", label: "Inactive" },
                  ]}
                />
                <Field label="Billing model" name="billingModel" options={[{ value: company.billingModel, label: `Keep: ${company.billingModel}` }, ...["per_passenger", "per_trip", "monthly_fixed", "distance_based"].map((v) => ({ value: v, label: v.replace(/_/g, " ") }))]} />
                <Field label="Monthly rate (GHS)" name="monthlyRate" type="number" step="0.01" defaultValue={company.monthlyRate} />
                <Field label="Internal notes" name="notes" rows={3} defaultValue={company.notes} />
              </div>
            </ActionForm>
          </div>
        </Card>

        <Card title="Office locations & branches" padded={false}>
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {branchRows.map((b) => (
              <div key={b.id} className="px-4 py-3 text-sm">
                <p className="font-medium text-slate-800 dark:text-slate-200">
                  {b.name} {b.isHeadquarters ? <span className="ml-1 text-xs text-teal-600">HQ</span> : null}
                </p>
                <p className="text-xs text-slate-500">{b.address ?? "—"}</p>
                <p className="text-xs text-slate-400">
                  {b.lat ?? "—"}, {b.lng ?? "—"}
                </p>
              </div>
            ))}
            {!branchRows.length ? <div className="p-4"><EmptyState title="No branches" /></div> : null}
          </div>
          <div className="border-t border-slate-100 p-4 dark:border-slate-800">
            <ActionForm action={createBranchAction} submitLabel="Add branch">
              <input type="hidden" name="companyId" value={company.id} />
              <div className="space-y-3">
                <Field label="Branch name" name="name" required />
                <Field label="Address" name="address" />
                <div className="grid grid-cols-3 gap-2">
                  <Field label="City" name="city" />
                  <Field label="Latitude" name="lat" type="number" step="0.0001" placeholder="5.6037" />
                  <Field label="Longitude" name="lng" type="number" step="0.0001" placeholder="-0.1870" />
                </div>
                <label className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300">
                  <input type="checkbox" name="isHeadquarters" className="rounded" /> Set as headquarters
                </label>
              </div>
            </ActionForm>
          </div>
        </Card>

        <div className="space-y-4">
          <Card title="Service agreements & SLAs" padded={false}>
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {agreementRows.map((a) => (
                <div key={a.id} className="px-4 py-3 text-xs">
                  <p className="text-sm font-medium text-slate-800 dark:text-slate-200">{a.name}</p>
                  <p className="text-slate-500">
                    {a.pricingModel.replace(/_/g, " ")} · unit rate {money(a.unitRate)} · {dateOnly(a.startDate)} → {a.endDate ? dateOnly(a.endDate) : "open"}
                  </p>
                  <p className="text-slate-400">
                    SLA on-time {n(a.slaOnTimePercent).toFixed(0)}% · response {a.slaResponseMinutes} min · pickup deviation ±{a.maxPickupDeviationMinutes} min
                  </p>
                </div>
              ))}
              {!agreementRows.length ? <div className="p-4"><EmptyState title="No agreement on file" /></div> : null}
            </div>
            <div className="border-t border-slate-100 p-4 dark:border-slate-800">
              <ActionForm action={createAgreementAction} submitLabel="Save agreement">
                <input type="hidden" name="companyId" value={company.id} />
                <div className="space-y-3">
                  <Field label="Agreement name" name="name" required placeholder="2026 Staff Transport SLA" />
                  <Field
                    label="Pricing model"
                    name="pricingModel"
                    options={[
                      { value: "per_passenger", label: "Per passenger" },
                      { value: "per_trip", label: "Per trip" },
                      { value: "distance_based", label: "Distance based (per km)" },
                      { value: "monthly_fixed", label: "Fixed monthly" },
                    ]}
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <Field label="Unit rate (GHS)" name="unitRate" type="number" step="0.01" />
                    <Field label="Fixed monthly (GHS)" name="fixedMonthlyAmount" type="number" step="0.01" />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <Field label="Start date" name="startDate" type="date" />
                    <Field label="End date" name="endDate" type="date" />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <Field label="On-time SLA (%)" name="slaOnTimePercent" type="number" step="0.1" defaultValue={95} />
                    <Field label="Response (min)" name="slaResponseMinutes" type="number" defaultValue={15} />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <Field label="Pickup deviation (min)" name="maxPickupDeviationMinutes" type="number" defaultValue={10} />
                    <Field label="Cancellation policy (hrs)" name="cancellationPolicyHours" type="number" defaultValue={2} />
                  </div>
                </div>
              </ActionForm>
            </div>
          </Card>

          <Card title="Invoices" padded={false}>
            <Table head={["Invoice", "Period", "Total", "Paid", "Status"]}>
              {invoiceRows.map((i) => (
                <tr key={i.id}>
                  <Td>
                    <Link href="/finance" className="font-medium text-teal-700 hover:underline dark:text-teal-400">
                      {i.invoiceNo}
                    </Link>
                  </Td>
                  <Td className="text-xs">
                    {dateOnly(i.periodStart)} → {dateOnly(i.periodEnd)}
                  </Td>
                  <Td className="tabular-nums">{money(i.total)}</Td>
                  <Td className="tabular-nums">{money(i.amountPaid)}</Td>
                  <Td>
                    <StatusBadge status={i.status} />
                  </Td>
                </tr>
              ))}
            </Table>
            {!invoiceRows.length ? <div className="p-4"><EmptyState title="No invoices" /></div> : null}
          </Card>

          <Card title="Shifts & routes configured" padded={false}>
            <ul className="divide-y divide-slate-100 text-xs dark:divide-slate-800">
              {shiftRows.map((s) => (
                <li key={s.id} className="flex items-center justify-between px-4 py-2">
                  <span>{s.name}</span>
                  <span className="text-slate-400">
                    {s.startTime}–{s.endTime} (grace {s.graceMinutes}m)
                  </span>
                </li>
              ))}
              {routeRows.map((r) => (
                <li key={`r${r.id}`} className="flex items-center justify-between px-4 py-2">
                  <span>{r.name}</span>
                  <span className="text-slate-400">
                    {r.direction.replace(/_/g, " ")} · {n(r.estimatedKm)} km
                  </span>
                </li>
              ))}
            </ul>
          </Card>
        </div>
      </div>
    </div>
  );
}
