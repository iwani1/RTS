import Link from "next/link";
import { asc, count, sql } from "drizzle-orm";
import { db } from "@/db";
import { companies, invoices, serviceAgreements } from "@/db/schema";
import { ActionForm } from "@/components/action-form";
import { Card, EmptyState, Field, LinkButton, PageHeader, StatusBadge, Table, Td } from "@/components/ui";
import { createCompanyAction } from "@/app/actions/admin";
import { requireSection } from "@/lib/auth";
import { money, n } from "@/lib/utils";

export const dynamic = "force-dynamic";

const BILLING = [
  { value: "per_passenger", label: "Per passenger" },
  { value: "per_trip", label: "Per trip" },
  { value: "monthly_fixed", label: "Fixed monthly retainer" },
  { value: "distance_based", label: "Distance based (per km)" },
];

export default async function CompaniesPage() {
  await requireSection("companies");

  const rows = await db
    .select({
      company: companies,
      employeeCount: sql<number>`(select count(*) from employees e where e.company_id = ${companies.id})`,
      branchCount: sql<number>`(select count(*) from company_branches b where b.company_id = ${companies.id})`,
      bookingCount: sql<number>`(select count(*) from bookings bk where bk.company_id = ${companies.id})`,
      invoiced: sql<string>`(select coalesce(sum(i.total), 0) from invoices i where i.company_id = ${companies.id})`,
      paid: sql<string>`(select coalesce(sum(i.amount_paid), 0) from invoices i where i.company_id = ${companies.id})`,
    })
    .from(companies)
    .orderBy(asc(companies.name));

  const [agreementCount] = await db.select({ v: count() }).from(serviceAgreements);

  return (
    <div>
      <PageHeader
        title="Corporate clients"
        subtitle="Register companies, manage their service agreements and monitor transport spend per client."
        actions={<LinkButton href="/reports">Client reports</LinkButton>}
      />

      <div className="grid gap-4 lg:grid-cols-3">
        <Card title="Client register" className="lg:col-span-2" padded={false}>
          <Table head={["Company", "Status", "Employees", "Branches", "Bookings", "Invoiced", "Outstanding"]}>
            {rows.map((r) => (
              <tr key={r.company.id}>
                <Td>
                  <Link href={`/companies/${r.company.id}`} className="font-medium text-teal-700 hover:underline dark:text-teal-400">
                    {r.company.name}
                  </Link>
                  <p className="text-xs text-slate-400">{r.company.industry ?? "—"}</p>
                </Td>
                <Td>
                  <StatusBadge status={r.company.status} />
                </Td>
                <Td className="tabular-nums">{Number(r.employeeCount)}</Td>
                <Td className="tabular-nums">{Number(r.branchCount)}</Td>
                <Td className="tabular-nums">{Number(r.bookingCount)}</Td>
                <Td className="tabular-nums">{money(r.invoiced)}</Td>
                <Td className="tabular-nums">{money(n(r.invoiced) - n(r.paid))}</Td>
              </tr>
            ))}
          </Table>
          {!rows.length ? <div className="p-4"><EmptyState title="No corporate clients yet" hint="Register your first client using the form." /></div> : null}
        </Card>

        <Card title="Register a corporate client" subtitle="Company profile and billing basis">
          <ActionForm action={createCompanyAction} submitLabel="Register client" resetOnSuccess>
            <div className="space-y-3">
              <Field label="Company name" name="name" required />
              <Field label="Primary contact" name="contactPerson" />
              <Field label="Contact email" name="email" type="email" />
              <Field label="Contact phone" name="phone" />
              <div className="grid grid-cols-2 gap-3">
                <Field label="Industry" name="industry" placeholder="Financial services" />
                <Field label="City" name="city" placeholder="Accra" />
              </div>
              <Field label="Billing model" name="billingModel" options={BILLING} />
              <Field label="Monthly rate (GHS)" name="monthlyRate" type="number" step="0.01" placeholder="42000.00" />
            </div>
          </ActionForm>
          <p className="mt-3 text-xs text-slate-400">
            {Number(agreementCount?.v ?? 0)} service agreement(s) on file. Add branches, employees and SLAs from each client page.
          </p>
        </Card>
      </div>
    </div>
  );
}
