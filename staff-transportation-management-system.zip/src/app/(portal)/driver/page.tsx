import Link from "next/link";
import { and, desc, eq, gte, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import { driverEarnings, drivers, routes, trips, vehicles } from "@/db/schema";
import { ActionForm, InlineActionForm } from "@/components/action-form";
import { Card, DemoNotice, EmptyState, Field, PageHeader, StatCard, StatusBadge, Table, Td } from "@/components/ui";
import { setAvailabilityAction, driverTripAction } from "@/app/actions/ops";
import { requireSection } from "@/lib/auth";
import { dateOnly, humanize, money, n, timeOnly, todayISO } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function DriverAppPage() {
  const user = await requireSection("driverapp");
  const [driver] = await db.select().from(drivers).where(eq(drivers.userId, user.id)).limit(1);

  if (!driver) {
    return (
      <div>
        <PageHeader title="Driver app" />
        <Card title="No driver record linked">
          <p className="text-sm text-slate-600 dark:text-slate-300">
            Your login is not linked to a driver record. Contact the fleet manager to complete your onboarding.
          </p>
        </Card>
      </div>
    );
  }

  const today = todayISO();
  const duties = await db
    .select({ trip: trips, vehicle: vehicles, route: routes.name, company: sql<string>`(select name from companies c where c.id = ${trips.companyId})` })
    .from(trips)
    .leftJoin(vehicles, eq(vehicles.id, trips.vehicleId))
    .leftJoin(routes, eq(routes.id, trips.routeId))
    .where(and(eq(trips.driverId, driver.id), gte(trips.tripDate, today)))
    .orderBy(trips.scheduledDeparture)
    .limit(20);

  const recent = await db
    .select({ trip: trips, vehicle: vehicles })
    .from(trips)
    .leftJoin(vehicles, eq(vehicles.id, trips.vehicleId))
    .where(and(eq(trips.driverId, driver.id), inArray(trips.status, ["completed", "cancelled"])))
    .orderBy(desc(trips.tripDate))
    .limit(10);

  const [earnings] = await db
    .select({
      trips: sql<number>`count(*)`,
      total: sql<string>`coalesce(sum(${driverEarnings.total}), 0)`,
      overtime: sql<string>`coalesce(sum(${driverEarnings.overtimePay}), 0)`,
      unpaid: sql<string>`coalesce(sum(case when ${driverEarnings.status} <> 'paid' then ${driverEarnings.total} else 0 end), 0)`,
    })
    .from(driverEarnings)
    .where(eq(driverEarnings.driverId, driver.id));

  const nextDuty = duties.find((d) => ["scheduled", "dispatching"].includes(d.trip.status));
  const onDuty = duties.find((d) => ["in_progress", "delayed", "breakdown"].includes(d.trip.status));

  return (
    <div>
      <PageHeader
        title="Driver app"
        subtitle={`${driver.fullName} · licence ${driver.licenseNo} (exp ${dateOnly(driver.licenseExpiry)})`}
      />

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Duties remaining today" value={duties.filter((d) => ["scheduled", "dispatching"].includes(d.trip.status)).length} icon="🚏" />
        <StatCard label="On duty now" value={onDuty ? "Yes" : "No"} tone={onDuty ? "info" : "default"} icon="🚌" />
        <StatCard label="Earnings accrued" value={money(earnings?.unpaid)} tone="positive" icon="💰" hint={`${Number(earnings?.trips ?? 0)} trips · ${money(earnings?.overtime)} overtime`} />
        <StatCard label="Availability" value={humanize(driver.status)} tone={driver.status === "available" ? "positive" : "warning"} icon="📍" />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <Card title="Current duty" className="lg:col-span-2">
          {onDuty ? (
            <>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="text-lg font-semibold text-navy-900 dark:text-white">{onDuty.trip.reference}</p>
                  <p className="text-sm text-slate-500">
                    {humanize(onDuty.trip.direction)} · {onDuty.company} · {onDuty.route ?? "corridor"}
                  </p>
                  <p className="mt-1 text-sm text-slate-500">
                    {onDuty.vehicle ? `${onDuty.vehicle.registrationNo} · ${onDuty.vehicle.make} ${onDuty.vehicle.model}` : "No vehicle assigned"}
                  </p>
                </div>
                <StatusBadge status={onDuty.trip.status} />
              </div>
              <div className="mt-4 flex flex-wrap gap-2">
                <InlineActionForm action={driverTripAction} hiddenFields={{ tripId: onDuty.trip.id, op: "complete" }} submitLabel="Complete journey" variant="primary" />
                <InlineActionForm action={driverTripAction} hiddenFields={{ tripId: onDuty.trip.id, op: "delay" }} submitLabel="Report delay" variant="secondary" />
                <Link href={`/driver/trip/${onDuty.trip.id}`} className="rounded-lg border border-slate-300 px-3 py-2 text-sm font-medium text-slate-700 dark:border-slate-700 dark:text-slate-200">
                  Open manifest & boarding
                </Link>
              </div>
              {onDuty.vehicle ? (
                <a
                  href={`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(onDuty.vehicle.registrationNo)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="mt-3 inline-block text-xs font-medium text-teal-700 underline dark:text-teal-400"
                >
                  Open navigation for the assigned corridor →
                </a>
              ) : null}
            </>
          ) : nextDuty ? (
            <>
              <p className="text-sm text-slate-500">Next duty</p>
              <p className="text-lg font-semibold text-navy-900 dark:text-white">
                {nextDuty.trip.reference} · {timeOnly(nextDuty.trip.scheduledDeparture)}
              </p>
              <p className="text-sm text-slate-500">
                {nextDuty.company} · {nextDuty.vehicle?.registrationNo ?? "vehicle to be assigned"} ·{" "}
                {nextDuty.trip.bookedSeats} passengers
              </p>
              <div className="mt-4 flex flex-wrap gap-2">
                <Link href={`/driver/trip/${nextDuty.trip.id}`} className="rounded-lg bg-navy-800 px-3 py-2 text-sm font-medium text-white dark:bg-teal-600">
                  View trip sheet
                </Link>
                <InlineActionForm action={driverTripAction} hiddenFields={{ tripId: nextDuty.trip.id, op: "start" }} submitLabel="Start journey" />
              </div>
            </>
          ) : (
            <EmptyState title="No duties assigned" hint="New assignments appear here and in your notifications." />
          )}
        </Card>

        <div className="space-y-4">
          <Card title="My availability">
            <ActionForm action={setAvailabilityAction} submitLabel="Update availability">
              <Field
                label="Duty status"
                name="status"
                options={[
                  { value: "available", label: "Available for assignment" },
                  { value: "off_duty", label: "Off duty" },
                  { value: "unavailable", label: "Unavailable (leave / sick)" },
                ]}
              />
            </ActionForm>
            <DemoNotice>Changing to unavailable immediately blocks new trip assignments for you.</DemoNotice>
          </Card>

          <Card title="Earnings summary">
            <Table head={["Item", "Amount"]}>
              <tr>
                <Td>Trip earnings (all time)</Td>
                <Td className="tabular-nums">{money(earnings?.total)}</Td>
              </tr>
              <tr>
                <Td>Overtime</Td>
                <Td className="tabular-nums">{money(earnings?.overtime)}</Td>
              </tr>
              <tr>
                <Td>Pending payroll</Td>
                <Td className="tabular-nums font-medium">{money(earnings?.unpaid)}</Td>
              </tr>
              <tr>
                <Td>Trip allowance per trip</Td>
                <Td className="tabular-nums">{money(driver.tripAllowance)}</Td>
              </tr>
            </Table>
            <p className="mt-2 text-xs text-slate-400">Overtime is paid at GHS 30.00 per hour beyond the planned arrival.</p>
          </Card>
        </div>
      </div>

      <Card className="mt-6" title="My schedule" padded={false}>
        <Table head={["Trip", "Date", "Departure", "Vehicle", "Passengers", "Status", ""]}>
          {duties.map((d) => (
            <tr key={d.trip.id}>
              <Td className="text-xs font-medium">{d.trip.reference}</Td>
              <Td className="text-xs">{dateOnly(d.trip.tripDate)}</Td>
              <Td className="text-xs">{timeOnly(d.trip.scheduledDeparture)}</Td>
              <Td className="text-xs">{d.vehicle?.registrationNo ?? "—"}</Td>
              <Td className="tabular-nums text-xs">
                {d.trip.bookedSeats}/{d.trip.capacity}
              </Td>
              <Td>
                <StatusBadge status={d.trip.status} />
              </Td>
              <Td>
                <Link href={`/driver/trip/${d.trip.id}`} className="text-xs font-medium text-teal-700 hover:underline dark:text-teal-400">
                  Open →
                </Link>
              </Td>
            </tr>
          ))}
        </Table>
        {!duties.length ? <div className="p-4"><EmptyState title="No scheduled duties" /></div> : null}
      </Card>

      <Card className="mt-6" title="Recently completed" padded={false}>
        <Table head={["Trip", "Date", "Departure", "Arrival", "Passengers", "Status"]}>
          {recent.map((r) => (
            <tr key={r.trip.id}>
              <Td className="text-xs">{r.trip.reference}</Td>
              <Td className="text-xs">{dateOnly(r.trip.tripDate)}</Td>
              <Td className="text-xs">{timeOnly(r.trip.actualDeparture)}</Td>
              <Td className="text-xs">{timeOnly(r.trip.actualArrival)}</Td>
              <Td className="tabular-nums text-xs">{r.trip.bookedSeats}</Td>
              <Td>
                <StatusBadge status={r.trip.status} />
              </Td>
            </tr>
          ))}
        </Table>
        {!recent.length ? <div className="p-4"><EmptyState title="No completed trips yet" /></div> : null}
      </Card>
    </div>
  );
}
