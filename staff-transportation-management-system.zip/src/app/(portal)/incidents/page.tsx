import { desc, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { companies, drivers, incidents, trips, users, vehicles } from "@/db/schema";
import { ActionForm, InlineActionForm } from "@/components/action-form";
import { Card, EmptyState, Field, PageHeader, StatCard, StatusBadge, Table, Td } from "@/components/ui";
import { createIncidentAction, updateIncidentAction } from "@/app/actions/ops";
import { companyScope, requireSection } from "@/lib/auth";
import { getDocumentExpiries } from "@/lib/queries";
import { dateOnly, humanize } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function IncidentsPage() {
  const user = await requireSection("incidents");
  const scope = companyScope(user);

  const rows = await db
    .select({
      incident: incidents,
      company: companies.name,
      vehicle: vehicles.registrationNo,
      driver: drivers.fullName,
      tripRef: trips.reference,
      reporter: users.fullName,
    })
    .from(incidents)
    .leftJoin(companies, eq(companies.id, incidents.companyId))
    .leftJoin(vehicles, eq(vehicles.id, incidents.vehicleId))
    .leftJoin(drivers, eq(drivers.id, incidents.driverId))
    .leftJoin(trips, eq(trips.id, incidents.tripId))
    .leftJoin(users, eq(users.id, incidents.reportedById))
    .where(scope ? eq(incidents.companyId, scope) : undefined)
    .orderBy(desc(incidents.reportedAt))
    .limit(60);

  const { vehicleDocs, driverDocs } = await getDocumentExpiries(60);
  const open = rows.filter((r) => r.incident.status !== "resolved");
  const critical = rows.filter((r) => r.incident.severity === "critical" || r.incident.severity === "high");

  const activeTrips = await db
    .select({ id: trips.id, reference: trips.reference })
    .from(trips)
    .where(inArray(trips.status, ["scheduled", "dispatching", "in_progress", "delayed", "breakdown"]))
    .limit(30);
  const vehicleOptions = await db.select({ id: vehicles.id, registrationNo: vehicles.registrationNo }).from(vehicles);
  const companyOptions = await db.select({ id: companies.id, name: companies.name }).from(companies);

  return (
    <div>
      <PageHeader
        title="Safety & compliance"
        subtitle="Incidents, breakdowns, SOS reports, no-shows, document expiries and safety inspections."
      />

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Open incidents" value={open.length} tone={open.length ? "warning" : "positive"} icon="🚨" />
        <StatCard label="High / critical" value={critical.length} tone={critical.length ? "danger" : "positive"} icon="⚠️" />
        <StatCard label="Vehicle document alerts" value={vehicleDocs.length} tone={vehicleDocs.length ? "warning" : "positive"} icon="📄" />
        <StatCard label="Licence alerts" value={driverDocs.length} tone={driverDocs.length ? "warning" : "positive"} icon="🪪" />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <Card title="Incident register" className="lg:col-span-2" padded={false}>
          <Table head={["Reported", "Type", "Severity", "Client / vehicle", "Description", "Status", ""]}>
            {rows.map((r) => (
              <tr key={r.incident.id}>
                <Td className="text-xs">{dateOnly(r.incident.reportedAt)}</Td>
                <Td className="text-xs font-medium">{humanize(r.incident.type)}</Td>
                <Td>
                  <StatusBadge status={r.incident.severity} />
                </Td>
                <Td className="text-xs">
                  {r.company ?? "Platform"}
                  <p className="text-slate-400">
                    {r.vehicle ?? "—"} {r.tripRef ? `· ${r.tripRef}` : ""}
                  </p>
                  <p className="text-slate-400">{r.driver ?? "—"}</p>
                </Td>
                <Td className="max-w-xs text-xs">
                  {r.incident.description}
                  <p className="text-slate-400">{r.incident.actionTaken ?? "Awaiting action"}</p>
                  <p className="text-slate-400">Reported by {r.reporter ?? "system"}</p>
                </Td>
                <Td>
                  <StatusBadge status={r.incident.status} />
                </Td>
                <Td>
                  {r.incident.status !== "resolved" ? (
                    <div className="flex flex-wrap gap-1.5">
                      <InlineActionForm action={updateIncidentAction} hiddenFields={{ id: r.incident.id, status: "acknowledged" }} submitLabel="Ack" variant="ghost" />
                      <InlineActionForm action={updateIncidentAction} hiddenFields={{ id: r.incident.id, status: "resolved" }} submitLabel="Resolve" variant="ghost" />
                    </div>
                  ) : null}
                </Td>
              </tr>
            ))}
          </Table>
          {!rows.length ? <div className="p-4"><EmptyState title="No incidents recorded" /></div> : null}
        </Card>

        <div className="space-y-4">
          <Card title="Report an incident" subtitle="Driver SOS, breakdown, accident or safety concern">
            <ActionForm action={createIncidentAction} submitLabel="Submit report" resetOnSuccess>
              <div className="space-y-3">
                <Field label="Type" name="type" options={["breakdown", "accident", "sos", "missed_pickup", "delay", "no_show", "complaint", "safety"].map((t) => ({ value: t, label: humanize(t) }))} />
                <Field label="Severity" name="severity" options={["low", "medium", "high", "critical"].map((s) => ({ value: s, label: s }))} />
                {!scope ? <Field label="Client" name="companyId" options={[{ value: "", label: "Platform / internal" }, ...companyOptions.map((c) => ({ value: String(c.id), label: c.name }))]} /> : null}
                <Field label="Trip" name="tripId" options={[{ value: "", label: "—" }, ...activeTrips.map((t) => ({ value: String(t.id), label: t.reference }))]} />
                <Field label="Vehicle" name="vehicleId" options={[{ value: "", label: "—" }, ...vehicleOptions.map((v) => ({ value: String(v.id), label: v.registrationNo }))]} />
                <Field label="Location" name="location" placeholder="Spintex Road, Accra" />
                <Field label="What happened?" name="description" rows={3} required />
              </div>
            </ActionForm>
          </Card>

          <Card title="Close an incident">
            <ActionForm action={updateIncidentAction} submitLabel="Update incident">
              <Field label="Incident" name="id" required options={rows.map((r) => ({ value: String(r.incident.id), label: `#${r.incident.id} · ${humanize(r.incident.type)} · ${r.company ?? "Platform"}` }))} />
              <div className="mt-3 space-y-3">
                <Field label="Status" name="status" options={[{ value: "acknowledged", label: "Acknowledged" }, { value: "resolved", label: "Resolved" }]} />
                <Field label="Action taken" name="actionTaken" rows={3} />
              </div>
            </ActionForm>
          </Card>

          <Card title="Document expiry watchlist" padded={false}>
            <ul className="divide-y divide-slate-100 text-xs dark:divide-slate-800">
              {vehicleDocs.slice(0, 6).map((v) => (
                <li key={`v${v.id}`} className="px-4 py-2">
                  <span className="font-semibold">{v.label}</span>
                  <p className="text-slate-500">
                    Insurance {dateOnly(v.insurance)} · Roadworthiness {dateOnly(v.roadworthy)} · Registration {dateOnly(v.registration)}
                  </p>
                </li>
              ))}
              {driverDocs.slice(0, 6).map((d) => (
                <li key={`d${d.id}`} className="px-4 py-2">
                  <span className="font-semibold">{d.label}</span>
                  <p className="text-slate-500">Licence expires {dateOnly(d.license)}</p>
                </li>
              ))}
              {!vehicleDocs.length && !driverDocs.length ? <li className="px-4 py-3 text-slate-400">All documents are valid for the next 60 days.</li> : null}
            </ul>
          </Card>
        </div>
      </div>
    </div>
  );
}
