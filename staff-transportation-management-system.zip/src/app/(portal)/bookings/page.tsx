import { and, desc, eq, ilike, or } from "drizzle-orm";
import { db } from "@/db";
import { bookings, companies, employees, trips, users } from "@/db/schema";
import { ActionForm, InlineActionForm } from "@/components/action-form";
import { Card, EmptyState, Field, PageHeader, StatCard, StatusBadge, Table, Td, inputClass } from "@/components/ui";
import { decideBookingAction, moveBookingAction, planTripsAction } from "@/app/actions/ops";
import { companyScope, requireSection } from "@/lib/auth";
import { dateOnly, humanize, n, timeOnly, todayISO } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function BookingsPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; status?: string; company?: string; date?: string }>;
}) {
  const user = await requireSection("bookings");
  const scope = companyScope(user);
  const { q = "", status = "", company = "", date = "" } = await searchParams;

  const filters = [
    scope ? eq(bookings.companyId, scope) : undefined,
    company && !scope ? eq(bookings.companyId, Number(company)) : undefined,
    status ? eq(bookings.status, status as "pending") : undefined,
    date ? eq(bookings.bookingDate, date) : undefined,
    q ? or(ilike(employees.fullName, `%${q}%`), ilike(bookings.reference, `%${q}%`), ilike(employees.employeeCode, `%${q}%`)) : undefined,
  ].filter(Boolean);

  const rows = await db
    .select({
      booking: bookings,
      employee: employees,
      company: companies.name,
      tripRef: trips.reference,
      tripCapacity: trips.capacity,
      approver: users.fullName,
    })
    .from(bookings)
    .innerJoin(employees, eq(employees.id, bookings.employeeId))
    .innerJoin(companies, eq(companies.id, bookings.companyId))
    .leftJoin(trips, eq(trips.id, bookings.tripId))
    .leftJoin(users, eq(users.id, bookings.approvedById))
    .where(filters.length ? and(...filters) : undefined)
    .orderBy(desc(bookings.bookingDate), desc(bookings.id))
    .limit(80);

  const statusCounts = await db
    .select({ status: bookings.status, v: bookings.id })
    .from(bookings)
    .where(scope ? eq(bookings.companyId, scope) : undefined);

  const tally = statusCounts.reduce<Record<string, number>>((acc, r) => {
    acc[r.status] = (acc[r.status] ?? 0) + 1;
    return acc;
  }, {});

  const companyOptions = await db.select({ id: companies.id, name: companies.name }).from(companies);
  const tripOptions = await db
    .select({ id: trips.id, reference: trips.reference, capacity: trips.capacity, bookedSeats: trips.bookedSeats, tripDate: trips.tripDate })
    .from(trips)
    .orderBy(desc(trips.tripDate))
    .limit(40);

  return (
    <div>
      <PageHeader
        title="Bookings & reservations"
        subtitle="Approve requests, manage waiting lists, move passengers between trips and audit cancellations."
      />

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        <StatCard label="Total bookings" value={Number(tally.total ?? 0) || statusCounts.length} icon="🎫" />
        <StatCard label="Pending approval" value={Number(tally.pending ?? 0)} tone={Number(tally.pending ?? 0) ? "warning" : "positive"} icon="⏳" />
        <StatCard label="Waitlisted" value={Number(tally.waitlisted ?? 0)} tone="info" icon="📋" />
        <StatCard label="Assigned to trips" value={Number(tally.assigned ?? 0)} icon="🚌" />
        <StatCard label="Cancelled / no-show" value={Number(tally.cancelled ?? 0) + Number(tally.no_show ?? 0)} tone="danger" icon="🚫" />
      </div>

      <Card className="mt-6" title="Search bookings">
        <form className="grid gap-3 sm:grid-cols-5" method="get">
          <input name="q" defaultValue={q} placeholder="Employee, code or reference" className={inputClass} />
          <select name="status" defaultValue={status} className={inputClass}>
            <option value="">Any status</option>
            {["pending", "approved", "waitlisted", "assigned", "in_progress", "completed", "no_show", "cancelled", "rejected"].map((s) => (
              <option key={s} value={s}>
                {humanize(s)}
              </option>
            ))}
          </select>
          <select name="company" defaultValue={company} className={inputClass} disabled={Boolean(scope)}>
            <option value="">All clients</option>
            {companyOptions.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
          <input name="date" type="date" defaultValue={date} className={inputClass} />
          <button type="submit" className="rounded-lg bg-navy-800 px-4 py-2 text-sm font-medium text-white dark:bg-teal-600">
            Apply
          </button>
        </form>
      </Card>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <Card title="Booking register" className="lg:col-span-2" padded={false}>
          <Table head={["Reference", "Employee", "Leg & date", "Trip", "Pickup", "Status", "Actions"]}>
            {rows.map((r) => (
              <tr key={r.booking.id}>
                <Td className="text-xs font-medium">{r.booking.reference}</Td>
                <Td className="text-xs">
                  <p className="font-medium text-slate-800 dark:text-slate-200">{r.employee.fullName}</p>
                  <p className="text-slate-400">
                    {r.employee.employeeCode} · {r.company}
                  </p>
                </Td>
                <Td className="text-xs">
                  {humanize(r.booking.direction)}
                  <p className="text-slate-400">{dateOnly(r.booking.bookingDate)}</p>
                </Td>
                <Td className="text-xs">
                  {r.tripRef ?? <span className="text-amber-600">not assigned</span>}
                  {r.booking.pickupTime ? <p className="text-slate-400">Pickup {r.booking.pickupTime}</p> : null}
                </Td>
                <Td className="text-xs">
                  {r.booking.pickupAddress?.slice(0, 24) ?? "—"}
                  <p className="text-slate-400">Code {r.booking.otpCode ?? "—"}</p>
                </Td>
                <Td>
                  <StatusBadge status={r.booking.status} />
                </Td>
                <Td>
                  <div className="flex flex-wrap gap-1.5">
                    {["pending", "waitlisted"].includes(r.booking.status) ? (
                      <>
                        <InlineActionForm action={decideBookingAction} hiddenFields={{ bookingId: r.booking.id, decision: "approve" }} submitLabel="Approve" />
                        <InlineActionForm action={decideBookingAction} hiddenFields={{ bookingId: r.booking.id, decision: "reject" }} submitLabel="Reject" variant="ghost" />
                      </>
                    ) : null}
                    {!["completed", "cancelled", "no_show"].includes(r.booking.status) ? (
                      <InlineActionForm
                        action={decideBookingAction}
                        hiddenFields={{ bookingId: r.booking.id, decision: "cancel" }}
                        submitLabel="Cancel"
                        variant="danger"
                        confirm={`Cancel booking ${r.booking.reference}?`}
                      />
                    ) : null}
                  </div>
                </Td>
              </tr>
            ))}
          </Table>
          {!rows.length ? <div className="p-4"><EmptyState title="No bookings match your filters" /></div> : null}
        </Card>

        <div className="space-y-4">
          <Card title="Waiting list decision" subtitle="Move a waitlisted passenger onto a trip">
            <ActionForm action={moveBookingAction} submitLabel="Move booking">
              <div className="space-y-3">
                <Field
                  label="Booking"
                  name="bookingId"
                  required
                  options={rows
                    .filter((r) => !r.booking.tripId)
                    .map((r) => ({ value: String(r.booking.id), label: `${r.booking.reference} · ${r.employee.fullName} (${humanize(r.booking.status)})` }))}
                />
                <Field
                  label="Target trip"
                  name="tripId"
                  required
                  options={tripOptions.map((t) => ({ value: String(t.id), label: `${t.reference} · ${dateOnly(t.tripDate)} · ${t.bookedSeats}/${t.capacity} seats` }))}
                />
              </div>
            </ActionForm>
            <p className="mt-2 text-xs text-slate-400">
              Capacity is validated before the move — overbooking is rejected with the remaining seat count.
            </p>
          </Card>

          <Card title="Approve all eligible requests" subtitle="Then run the planner">
            <ActionForm action={planTripsAction} submitLabel="Plan trips for approved bookings">
              <div className="space-y-3">
                <Field label="Service date" name="tripDate" type="date" required defaultValue={todayISO()} />
                <Field
                  label="Direction"
                  name="direction"
                  options={[
                    { value: "home_to_office", label: "Home to office" },
                    { value: "office_to_home", label: "Office to home" },
                  ]}
                />
                {!scope ? (
                  <Field label="Client" name="companyId" options={[{ value: "", label: "All clients" }, ...companyOptions.map((c) => ({ value: String(c.id), label: c.name }))]} />
                ) : null}
              </div>
            </ActionForm>
          </Card>

          <Card title="Recent decisions">
            <ul className="space-y-2 text-xs">
              {rows
                .filter((r) => r.approver)
                .slice(0, 6)
                .map((r) => (
                  <li key={`a${r.booking.id}`} className="rounded-lg border border-slate-200 p-2 dark:border-slate-800">
                    <span className="font-medium">{r.employee.fullName}</span> — {humanize(r.booking.status)} by {r.approver}
                    <p className="text-slate-400">
                      {dateOnly(r.booking.bookingDate)} · {humanize(r.booking.direction)} · pickup {r.booking.pickupTime ?? "TBC"}
                    </p>
                  </li>
                ))}
              {!rows.some((r) => r.approver) ? <li className="text-slate-400">No decisions recorded yet.</li> : null}
            </ul>
          </Card>
        </div>
      </div>
      <p className="mt-4 text-xs text-slate-400">
        Bookings are matched to trips with a hard capacity check; duplicates for the same employee,
        date and direction are rejected at creation.
      </p>
    </div>
  );
}
