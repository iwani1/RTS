import Link from "next/link";
import { and, asc, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { branches, companies, drivers, routes, trips, vehicles } from "@/db/schema";
import { ActionForm } from "@/components/action-form";
import { Card, EmptyState, Field, LinkButton, PageHeader, StatCard, StatusBadge, Table, Td } from "@/components/ui";
import { createTripAction, planTripsAction } from "@/app/actions/ops";
import { companyScope, requireSection } from "@/lib/auth";
import { dateOnly, humanize, n, timeOnly, todayISO } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function TripsPage({
  searchParams,
}: {
  searchParams: Promise<{ date?: string; company?: string; status?: string }>;
}) {
  const user = await requireSection("trips");
  const scope = companyScope(user);
  const { date = todayISO(), company = "", status = "" } = await searchParams;

  const filters = [
    eq(trips.tripDate, date),
    scope ? eq(trips.companyId, scope) : undefined,
    company && !scope ? eq(trips.companyId, Number(company)) : undefined,
    status ? eq(trips.status, status as "scheduled") : undefined,
  ].filter(Boolean);

  const rows = await db
    .select({
      trip: trips,
      company: companies.name,
      route: routes.name,
      vehicle: vehicles.registrationNo,
      capacity: vehicles.capacity,
      driver: drivers.fullName,
      driverPhone: drivers.phone,
    })
    .from(trips)
    .innerJoin(companies, eq(companies.id, trips.companyId))
    .leftJoin(routes, eq(routes.id, trips.routeId))
    .leftJoin(vehicles, eq(vehicles.id, trips.vehicleId))
    .leftJoin(drivers, eq(drivers.id, trips.driverId))
    .where(and(...filters))
    .orderBy(asc(trips.scheduledDeparture))
    .limit(100);

  const [summary] = await db
    .select({
      total: sql<number>`count(*)`,
      completed: sql<number>`sum(case when ${trips.status} = 'completed' then 1 else 0 end)`,
      inProgress: sql<number>`sum(case when ${trips.status} = 'in_progress' then 1 else 0 end)`,
      unassigned: sql<number>`sum(case when ${trips.vehicleId} is null or ${trips.driverId} is null then 1 else 0 end)`,
      seats: sql<number>`coalesce(sum(${trips.bookedSeats}), 0)`,
      capacity: sql<number>`coalesce(sum(${trips.capacity}), 0)`,
      km: sql<number>`coalesce(sum(${trips.plannedKm}), 0)`,
    })
    .from(trips)
    .where(and(eq(trips.tripDate, date), scope ? eq(trips.companyId, scope) : undefined));

  const companyOptions = await db.select({ id: companies.id, name: companies.name }).from(companies).orderBy(asc(companies.name));
  const vehicleOptions = await db.select().from(vehicles).orderBy(asc(vehicles.registrationNo));
  const driverOptions = await db.select().from(drivers).orderBy(asc(drivers.fullName));
  const routeOptions = await db
    .select({ id: routes.id, name: routes.name, companyId: routes.companyId, direction: routes.direction })
    .from(routes)
    .orderBy(asc(routes.name));
  const branchOptions = await db.select({ id: branches.id, name: branches.name, companyId: branches.companyId }).from(branches);

  return (
    <div>
      <PageHeader
        title="Trip management"
        subtitle="Scheduled journeys, assigned vehicles and drivers, seat load and lifecycle status."
        actions={<LinkButton href="/dispatch">Live dispatch board</LinkButton>}
      />

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        <StatCard label="Trips on date" value={Number(summary?.total ?? 0)} icon="🚌" />
        <StatCard label="Completed" value={Number(summary?.completed ?? 0)} tone="positive" icon="✅" />
        <StatCard label="In progress" value={Number(summary?.inProgress ?? 0)} tone="info" icon="🚏" />
        <StatCard label="Missing vehicle/driver" value={Number(summary?.unassigned ?? 0)} tone={Number(summary?.unassigned ?? 0) ? "warning" : "positive"} icon="⚠️" />
        <StatCard label="Seat fill" value={`${Number(summary?.capacity ?? 0) ? ((Number(summary?.seats ?? 0) / Number(summary?.capacity ?? 1)) * 100).toFixed(0) : 0}%`} icon="🪑" hint={`${n(summary?.km).toFixed(0)} km planned`} />
      </div>

      <Card className="mt-6" title="Filter trips">
        <form className="grid gap-3 sm:grid-cols-4" method="get">
          <Field label="Service date" name="date" type="date" defaultValue={date} />
          {!scope ? (
            <Field label="Client" name="company" options={[{ value: "", label: "All clients" }, ...companyOptions.map((c) => ({ value: String(c.id), label: c.name }))]} />
          ) : null}
          <Field
            label="Status"
            name="status"
            options={[{ value: "", label: "Any status" }, ...["scheduled", "dispatching", "in_progress", "delayed", "breakdown", "completed", "cancelled"].map((s) => ({ value: s, label: humanize(s) }))]}
          />
          <button type="submit" className="self-end rounded-lg bg-navy-800 px-4 py-2 text-sm font-medium text-white dark:bg-teal-600">
            Apply
          </button>
        </form>
      </Card>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <Card title={`Trips for ${dateOnly(date)}`} className="lg:col-span-2" padded={false}>
          <Table head={["Reference", "Client / route", "Departure", "Vehicle & driver", "Seats", "Status"]}>
            {rows.map((r) => (
              <tr key={r.trip.id}>
                <Td>
                  <Link href={`/trips/${r.trip.id}`} className="font-medium text-teal-700 hover:underline dark:text-teal-400">
                    {r.trip.reference}
                  </Link>
                  <p className="text-xs text-slate-400">{humanize(r.trip.direction)}</p>
                </Td>
                <Td className="text-xs">
                  {r.company}
                  <p className="text-slate-400">{r.route ?? "Unassigned corridor"}</p>
                </Td>
                <Td className="text-xs">
                  {timeOnly(r.trip.scheduledDeparture)}
                  <p className="text-slate-400">→ {timeOnly(r.trip.scheduledArrival)}</p>
                </Td>
                <Td className="text-xs">
                  {r.vehicle ?? <span className="text-amber-600">no vehicle</span>}
                  <p className="text-slate-400">{r.driver ?? <span className="text-amber-600">no driver</span>}</p>
                </Td>
                <Td className="tabular-nums text-xs">
                  {r.trip.bookedSeats}/{r.trip.capacity}
                </Td>
                <Td>
                  <StatusBadge status={r.trip.status} />
                </Td>
              </tr>
            ))}
          </Table>
          {!rows.length ? <div className="p-4"><EmptyState title="No trips for this date" hint="Create one manually or run the route planner." /></div> : null}
        </Card>

        <div className="space-y-4">
          <Card title="Run the planner" subtitle="Creates trips from approved bookings">
            <ActionForm action={planTripsAction} submitLabel="Plan trips">
              <div className="space-y-3">
                <Field label="Service date" name="tripDate" type="date" required defaultValue={date} />
                <Field
                  label="Direction"
                  name="direction"
                  options={[
                    { value: "home_to_office", label: "Home to office" },
                    { value: "office_to_home", label: "Office to home" },
                  ]}
                />
                {!scope ? (
                  <Field label="Client (optional)" name="companyId" options={[{ value: "", label: "All clients" }, ...companyOptions.map((c) => ({ value: String(c.id), label: c.name }))]} />
                ) : null}
              </div>
            </ActionForm>
          </Card>

          <Card title="Create a trip manually" subtitle="Emergency or ad-hoc duties">
            <ActionForm action={createTripAction} submitLabel="Create trip" resetOnSuccess>
              <div className="space-y-3">
                {!scope ? <Field label="Client" name="companyId" required options={companyOptions.map((c) => ({ value: String(c.id), label: c.name }))} /> : null}
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Service date" name="tripDate" type="date" required defaultValue={date} />
                  <Field
                    label="Direction"
                    name="direction"
                    options={[
                      { value: "home_to_office", label: "Home to office" },
                      { value: "office_to_home", label: "Office to home" },
                      { value: "inter_office", label: "Inter office" },
                      { value: "ad_hoc", label: "Ad hoc / emergency" },
                    ]}
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Departure" name="scheduledDeparture" type="time" required defaultValue="05:30" />
                  <Field label="Arrival (planned)" name="scheduledArrival" type="time" defaultValue="07:00" />
                </div>
                <Field label="Route" name="routeId" options={[{ value: "", label: "—" }, ...routeOptions.filter((r) => !scope || r.companyId === scope).map((r) => ({ value: String(r.id), label: r.name }))]} />
                <Field
                  label="Vehicle"
                  name="vehicleId"
                  options={[{ value: "", label: "Assign later" }, ...vehicleOptions.filter((v) => v.status === "available" || v.status === "assigned").map((v) => ({ value: String(v.id), label: `${v.registrationNo} · ${v.capacity} seats` }))]}
                  hint="Vehicles under maintenance or out of service are excluded."
                />
                <Field
                  label="Driver"
                  name="driverId"
                  options={[{ value: "", label: "Assign later" }, ...driverOptions.filter((d) => d.status !== "unavailable").map((d) => ({ value: String(d.id), label: `${d.fullName} · ${d.phone}` }))]}
                />
                <Field label="Planned distance (km)" name="plannedKm" type="number" step="0.1" />
                <Field label="Notes" name="notes" rows={2} />
              </div>
            </ActionForm>
          </Card>
        </div>
      </div>
    </div>
  );
}
