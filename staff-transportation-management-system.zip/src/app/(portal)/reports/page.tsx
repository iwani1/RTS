import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { bookings, companies, drivers, employees, incidents, invoices, maintenanceRecords, trips, vehicles } from "@/db/schema";
import { BarChart, LineChart } from "@/components/charts";
import { Card, EmptyState, Field, PageHeader, StatCard, Table, Td, inputClass } from "@/components/ui";
import { companyScope, requireSection } from "@/lib/auth";
import { getDriverPerformance, getKpis, getRouteEfficiency, getTripsPerDay } from "@/lib/queries";
import { dateOnly, humanize, isoDaysFromNow, money, n, todayISO } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function ReportsPage({
  searchParams,
}: {
  searchParams: Promise<{ from?: string; to?: string; company?: string }>;
}) {
  const user = await requireSection("reports");
  const scope = companyScope(user);
  const { from = isoDaysFromNow(-30), to = todayISO(), company = "" } = await searchParams;
  const companyId = scope ?? (company ? Number(company) : null);

  const [kpis, perDay, driverPerf, routeEff, companyOptions, incidentAgg, maintenanceAgg, bookingAgg, revenueAgg] = await Promise.all([
    getKpis(companyId),
    getTripsPerDay(companyId, 30),
    getDriverPerformance(10),
    getRouteEfficiency(companyId),
    db.select({ id: companies.id, name: companies.name }).from(companies),
    db
      .select({ type: incidents.type, severity: incidents.severity, v: sql<number>`count(*)` })
      .from(incidents)
      .where(companyId ? eq(incidents.companyId, companyId) : undefined)
      .groupBy(incidents.type, incidents.severity)
      .orderBy(sql`count(*) desc`),
    db
      .select({ total: sql<string>`coalesce(sum(${maintenanceRecords.cost}), 0)`, records: sql<number>`count(*)` })
      .from(maintenanceRecords),
    db
      .select({
        total: sql<number>`count(*)`,
        cancelled: sql<number>`sum(case when ${bookings.status} = 'cancelled' then 1 else 0 end)`,
        noShow: sql<number>`sum(case when ${bookings.status} = 'no_show' then 1 else 0 end)`,
        completed: sql<number>`sum(case when ${bookings.status} = 'completed' then 1 else 0 end)`,
      })
      .from(bookings)
      .where(companyId ? eq(bookings.companyId, companyId) : undefined),
    db
      .select({ company: companies.name, invoiced: sql<string>`coalesce(sum(${invoices.total}), 0)`, paid: sql<string>`coalesce(sum(${invoices.amountPaid}), 0)` })
      .from(invoices)
      .innerJoin(companies, eq(companies.id, invoices.companyId))
      .where(companyId ? eq(invoices.companyId, companyId) : undefined)
      .groupBy(companies.name),
  ]);

  const vehicleUtil = await db
    .select({
      registrationNo: vehicles.registrationNo,
      model: vehicles.model,
      status: vehicles.status,
      capacity: vehicles.capacity,
      trips: sql<number>`(select count(*) from trips t where t.vehicle_id = ${vehicles.id})`,
      seats: sql<number>`(select coalesce(sum(t.booked_seats), 0) from trips t where t.vehicle_id = ${vehicles.id})`,
      cost: sql<string>`(select coalesce(sum(m.cost), 0) from maintenance_records m where m.vehicle_id = ${vehicles.id})`,
    })
    .from(vehicles)
    .orderBy(sql`(select count(*) from trips t where t.vehicle_id = ${vehicles.id}) desc`)
    .limit(10);

  const staffCount = await db
    .select({ company: companies.name, employees: sql<number>`count(*)` })
    .from(employees)
    .innerJoin(companies, eq(companies.id, employees.companyId))
    .where(companyId ? eq(employees.companyId, companyId) : undefined)
    .groupBy(companies.name);

  const [driverStats] = await db
    .select({ total: sql<number>`count(*)`, avgRating: sql<string>`coalesce(avg(${drivers.ratingAvg}), 0)` })
    .from(drivers);

  const exportUrl = `/api/reports/export?from=${from}&to=${to}${companyId ? `&company=${companyId}` : ""}`;

  return (
    <div>
      <PageHeader
        title="Reports & business intelligence"
        subtitle="Operational, financial and safety analytics with CSV and print-to-PDF export."
        actions={
          <>
            <a href={exportUrl} className="rounded-lg border border-slate-300 px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200">
              ⬇️ Export operating report CSV
            </a>
            <a href="/api/reports/export?type=trips" className="rounded-lg border border-slate-300 px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200">
              ⬇️ Trips CSV
            </a>
          </>
        }
      />

      <Card title="Filter the analysis">
        <form className="grid gap-3 sm:grid-cols-4" method="get">
          <Field label="From" name="from" type="date" defaultValue={from} />
          <Field label="To" name="to" type="date" defaultValue={to} />
          {!scope ? (
            <Field label="Client" name="company" options={[{ value: "", label: "All clients" }, ...companyOptions.map((c) => ({ value: String(c.id), label: c.name }))]} />
          ) : (
            <div className="text-xs text-slate-400">Scoped to your company</div>
          )}
          <button type="submit" className="self-end rounded-lg bg-navy-800 px-4 py-2 text-sm font-medium text-white dark:bg-teal-600">
            Apply
          </button>
        </form>
      </Card>

      <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-6">
        <StatCard label="Corporate clients" value={kpis.companies} icon="🏢" />
        <StatCard label="Employees" value={kpis.employees} icon="👥" />
        <StatCard label="Bookings" value={kpis.bookings} icon="🎫" />
        <StatCard label="Completed journeys" value={kpis.completedTrips} tone="positive" icon="🚌" />
        <StatCard label="Cancelled" value={kpis.cancelledBookings} tone="danger" icon="🚫" />
        <StatCard label="Fleet utilisation" value={`${kpis.fleetUtilisation.toFixed(0)}%`} tone="info" icon="📈" />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <Card title="Trip volume trend" subtitle="Last 30 days" className="lg:col-span-2">
          <LineChart
            labels={perDay.map((d) => d.day.slice(5))}
            series={[
              { name: "Trips", color: "#12355b", points: perDay.map((d) => d.total) },
              { name: "Completed", color: "#0d9488", points: perDay.map((d) => d.completed) },
              { name: "Passengers", color: "#d97706", points: perDay.map((d) => d.passengers) },
            ]}
          />
        </Card>
        <Card title="Service quality">
          <Table head={["Metric", "Value"]}>
            <tr>
              <Td>On-time arrivals</Td>
              <Td className="tabular-nums font-medium">{kpis.onTimePct.toFixed(1)}%</Td>
            </tr>
            <tr>
              <Td>Average delay</Td>
              <Td className="tabular-nums">{kpis.avgDelayMinutes} min</Td>
            </tr>
            <tr>
              <Td>Cost per passenger</Td>
              <Td className="tabular-nums">{money(kpis.costPerPassenger)}</Td>
            </tr>
            <tr>
              <Td>Open incidents</Td>
              <Td className="tabular-nums">{kpis.openIncidents}</Td>
            </tr>
            <tr>
              <Td>Maintenance spend</Td>
              <Td className="tabular-nums">{money(maintenanceAgg[0]?.total)}</Td>
            </tr>
            <tr>
              <Td>Driver average rating</Td>
              <Td className="tabular-nums">{n(driverStats?.avgRating).toFixed(2)} ★</Td>
            </tr>
            <tr>
              <Td>Completed bookings</Td>
              <Td className="tabular-nums">{Number(bookingAgg[0]?.completed ?? 0)}</Td>
            </tr>
            <tr>
              <Td>No-shows</Td>
              <Td className="tabular-nums">{Number(bookingAgg[0]?.noShow ?? 0)}</Td>
            </tr>
          </Table>
        </Card>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <Card title="Revenue per client" padded={false}>
          <Table head={["Client", "Invoiced", "Collected", "Outstanding"]}>
            {revenueAgg.map((r) => (
              <tr key={r.company}>
                <Td className="text-xs">{r.company}</Td>
                <Td className="tabular-nums text-xs">{money(r.invoiced)}</Td>
                <Td className="tabular-nums text-xs">{money(r.paid)}</Td>
                <Td className="tabular-nums text-xs">{money(n(r.invoiced) - n(r.paid))}</Td>
              </tr>
            ))}
          </Table>
          <div className="p-4">
            <BarChart data={revenueAgg.map((r) => ({ label: r.company.split(" ")[0], value: n(r.invoiced) }))} />
          </div>
        </Card>

        <Card title="Driver performance" padded={false}>
          <Table head={["Driver", "Trips", "On time", "Passengers", "Rating"]}>
            {driverPerf.map((d) => (
              <tr key={d.driverId ?? d.driver}>
                <Td className="text-xs font-medium">{d.driver}</Td>
                <Td className="tabular-nums text-xs">{d.tripsCompleted}</Td>
                <Td className="tabular-nums text-xs">{d.tripsCompleted ? `${((d.onTime / d.tripsCompleted) * 100).toFixed(0)}%` : "—"}</Td>
                <Td className="tabular-nums text-xs">{d.passengers}</Td>
                <Td className="tabular-nums text-xs">{n(d.rating).toFixed(1)} ★</Td>
              </tr>
            ))}
          </Table>
          {!driverPerf.length ? <div className="p-4"><EmptyState title="No trip data yet" /></div> : null}
        </Card>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <Card title="Vehicle utilisation & maintenance cost" padded={false}>
          <Table head={["Vehicle", "Status", "Trips", "Seats sold", "Fill", "Maintenance"]}>
            {vehicleUtil.map((v) => (
              <tr key={v.registrationNo}>
                <Td className="text-xs">
                  <p className="font-medium">{v.registrationNo}</p>
                  <p className="text-slate-400">{v.model}</p>
                </Td>
                <Td className="text-xs">{humanize(v.status)}</Td>
                <Td className="tabular-nums text-xs">{Number(v.trips)}</Td>
                <Td className="tabular-nums text-xs">{Number(v.seats)}</Td>
                <Td className="tabular-nums text-xs">
                  {Number(v.trips) ? ((Number(v.seats) / (Number(v.trips) * v.capacity)) * 100).toFixed(0) : 0}%
                </Td>
                <Td className="tabular-nums text-xs">{money(v.cost)}</Td>
              </tr>
            ))}
          </Table>
        </Card>

        <Card title="Route efficiency" padded={false}>
          <Table head={["Client", "Avg planned km", "Avg passengers", "Trips"]}>
            {routeEff.map((r, i) => (
              <tr key={`${r.routeId}-${i}`}>
                <Td className="text-xs">{r.company}</Td>
                <Td className="tabular-nums text-xs">{r.plannedKm.toFixed(1)}</Td>
                <Td className="tabular-nums text-xs">{r.passengers.toFixed(1)}</Td>
                <Td className="tabular-nums text-xs">{r.tripsCount}</Td>
              </tr>
            ))}
          </Table>
          <div className="border-t border-slate-100 p-4 dark:border-slate-800">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">Incident frequency</p>
            <Table head={["Type", "Severity", "Count"]}>
              {incidentAgg.map((i) => (
                <tr key={`${i.type}-${i.severity}`}>
                  <Td className="text-xs">{humanize(i.type)}</Td>
                  <Td className="text-xs">{i.severity}</Td>
                  <Td className="tabular-nums text-xs">{Number(i.v)}</Td>
                </tr>
              ))}
            </Table>
          </div>
        </Card>
      </div>

      <Card className="mt-6" title="Employees per client" subtitle="Service coverage" padded={false}>
        <Table head={["Client", "Registered employees"]}>
          {staffCount.map((s) => (
            <tr key={s.company}>
              <Td className="text-xs">{s.company}</Td>
              <Td className="tabular-nums text-xs">{Number(s.employees)}</Td>
            </tr>
          ))}
        </Table>
      </Card>

      <p className="mt-4 text-xs text-slate-400">
        Reporting period {dateOnly(from)} → {dateOnly(to)}. PDF export uses the browser print dialog (optimised print
        stylesheet); CSV exports are generated server side.
      </p>
    </div>
  );
}
