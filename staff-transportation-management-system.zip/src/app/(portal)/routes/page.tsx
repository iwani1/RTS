import { asc, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import { branches, companies, employees, routeStops, routes, stops, trips } from "@/db/schema";
import { ActionForm, InlineActionForm } from "@/components/action-form";
import { Card, DemoNotice, EmptyState, Field, PageHeader, StatCard, StatusBadge, Table, Td } from "@/components/ui";
import { createRouteAction, createStopAction, toggleRouteAction } from "@/app/actions/admin";
import { planTripsAction } from "@/app/actions/ops";
import { companyScope, requireSection } from "@/lib/auth";
import { distanceKm, humanize, n, todayISO } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function RoutesPage() {
  const user = await requireSection("routes");
  const scope = companyScope(user);

  const routeRows = await db
    .select({
      route: routes,
      company: companies.name,
      branch: branches.name,
      stopCount: sql<number>`(select count(*) from route_stops rs where rs.route_id = ${routes.id})`,
      tripCount: sql<number>`(select count(*) from trips t where t.route_id = ${routes.id})`,
      avgLoad: sql<string>`(select coalesce(avg(t.booked_seats), 0) from trips t where t.route_id = ${routes.id})`,
    })
    .from(routes)
    .innerJoin(companies, eq(companies.id, routes.companyId))
    .leftJoin(branches, eq(branches.id, routes.branchId))
    .where(scope ? eq(routes.companyId, scope) : undefined)
    .orderBy(asc(companies.name), asc(routes.name));

  const stopRows = await db
    .select({
      stop: stops,
      company: companies.name,
      pickupCount: sql<number>`(select count(*) from bookings b where b.pickup_stop_id = ${stops.id})`,
    })
    .from(stops)
    .innerJoin(companies, eq(companies.id, stops.companyId))
    .where(scope ? eq(stops.companyId, scope) : undefined)
    .orderBy(asc(stops.name));

  const routeStopRows = routeRows.length
    ? await db
        .select({ routeId: routeStops.routeId, sequence: routeStops.sequence, name: stops.name, offsetMinutes: routeStops.offsetMinutes })
        .from(routeStops)
        .innerJoin(stops, eq(stops.id, routeStops.stopId))
        .where(inArray(routeStops.routeId, routeRows.map((r) => r.route.id)))
        .orderBy(asc(routeStops.routeId), asc(routeStops.sequence))
    : [];

  const companyOptions = await db.select({ id: companies.id, name: companies.name }).from(companies).orderBy(asc(companies.name));
  const branchOptions = await db.select({ id: branches.id, name: branches.name, companyId: branches.companyId }).from(branches);

  const zoneStats = await db
    .select({ zone: employees.zone, total: sql<number>`count(*)` })
    .from(employees)
    .where(scope ? eq(employees.companyId, scope) : undefined)
    .groupBy(employees.zone)
    .orderBy(sql`count(*) desc`);

  const [tripLoad] = await db
    .select({
      avgSeats: sql<number>`coalesce(avg(${trips.bookedSeats}), 0)`,
      avgCapacity: sql<number>`coalesce(avg(${trips.capacity}), 0)`,
      avgKm: sql<number>`coalesce(avg(${trips.plannedKm}), 0)`,
    })
    .from(trips)
    .where(scope ? eq(trips.companyId, scope) : undefined);

  const fill = n(tripLoad?.avgCapacity) ? (n(tripLoad?.avgSeats) / n(tripLoad?.avgCapacity)) * 100 : 0;

  return (
    <div>
      <PageHeader
        title="Routes & stops"
        subtitle="Define corridors, stop sequences and let the planner group passengers into capacity-aware trips."
      />

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Active routes" value={routeRows.filter((r) => r.route.active).length} icon="🧭" hint={`${routeRows.length} total`} />
        <StatCard label="Stops" value={stopRows.length} icon="📍" />
        <StatCard label="Average seat fill" value={`${fill.toFixed(0)}%`} tone="info" icon="🪑" hint={`${n(tripLoad?.avgSeats).toFixed(1)} of ${n(tripLoad?.avgCapacity).toFixed(1)} seats`} />
        <StatCard label="Average planned distance" value={`${n(tripLoad?.avgKm).toFixed(1)} km`} icon="📏" />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <Card title="Route register" className="lg:col-span-2" padded={false}>
          <Table head={["Route", "Client", "Direction", "Corridor", "Stops", "Trips", "Avg load", "Status", ""]}>
            {routeRows.map((r) => (
              <tr key={r.route.id}>
                <Td>
                  <p className="font-medium text-slate-800 dark:text-slate-200">{r.route.name}</p>
                  <p className="text-xs text-slate-400">
                    {n(r.route.estimatedKm)} km · {r.route.estimatedMinutes} min
                  </p>
                  <ol className="mt-1 space-y-0.5 text-[10px] text-slate-400">
                    {routeStopRows
                      .filter((rs) => rs.routeId === r.route.id)
                      .map((rs) => (
                        <li key={`${rs.routeId}-${rs.sequence}`}>
                          {rs.sequence}. {rs.name} (+{rs.offsetMinutes}m)
                        </li>
                      ))}
                  </ol>
                </Td>
                <Td className="text-xs">
                  {r.company}
                  <p className="text-slate-400">{r.branch ?? "—"}</p>
                </Td>
                <Td className="text-xs">{humanize(r.route.direction)}</Td>
                <Td className="text-xs">{r.route.zone ?? "—"}</Td>
                <Td className="tabular-nums">{Number(r.stopCount)}</Td>
                <Td className="tabular-nums">{Number(r.tripCount)}</Td>
                <Td className="tabular-nums text-xs">{n(r.avgLoad).toFixed(1)}</Td>
                <Td>
                  <StatusBadge status={r.route.active ? "active" : "inactive"} />
                </Td>
                <Td>
                  <InlineActionForm
                    action={toggleRouteAction}
                    hiddenFields={{ id: r.route.id, active: r.route.active ? "false" : "true" }}
                    submitLabel={r.route.active ? "Deactivate" : "Activate"}
                    variant="ghost"
                  />
                </Td>
              </tr>
            ))}
          </Table>
          {!routeRows.length ? <div className="p-4"><EmptyState title="No routes defined" /></div> : null}
        </Card>

        <div className="space-y-4">
          <Card title="Run the route planner" subtitle="Groups approved bookings into trips">
            <DemoNotice>
              Heuristic planner: zone clustering, nearest-neighbour sequencing, smallest-suitable-vehicle allocation. The
              interface is ready for an OR-Tools VRP solver or live traffic feed.
            </DemoNotice>
            <ActionForm action={planTripsAction} submitLabel="Plan trips" className="mt-3">
              <div className="space-y-3">
                <Field label="Service date" name="tripDate" type="date" required defaultValue={todayISO()} />
                <Field
                  label="Direction"
                  name="direction"
                  options={[
                    { value: "home_to_office", label: "Home to office (pickup)" },
                    { value: "office_to_home", label: "Office to home (drop-off)" },
                  ]}
                />
                {!scope ? (
                  <Field
                    label="Client (optional)"
                    name="companyId"
                    options={[{ value: "", label: "All clients" }, ...companyOptions.map((c) => ({ value: String(c.id), label: c.name }))]}
                  />
                ) : null}
              </div>
            </ActionForm>
          </Card>

          <Card title="Create a route">
            <ActionForm action={createRouteAction} submitLabel="Create route" resetOnSuccess>
              <div className="space-y-3">
                {!scope ? <Field label="Client" name="companyId" required options={companyOptions.map((c) => ({ value: String(c.id), label: c.name }))} /> : null}
                <Field label="Route name" name="name" required placeholder="Morning pickup — Dansaman / Lapaz" />
                <Field
                  label="Direction"
                  name="direction"
                  options={[
                    { value: "home_to_office", label: "Home to office" },
                    { value: "office_to_home", label: "Office to home" },
                    { value: "inter_office", label: "Inter office" },
                    { value: "ad_hoc", label: "Ad hoc" },
                  ]}
                />
                <Field label="Corridor / zone" name="zone" placeholder="Western corridor" />
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Estimated km" name="estimatedKm" type="number" step="0.1" />
                  <Field label="Estimated minutes" name="estimatedMinutes" type="number" />
                </div>
                <Field
                  label="Branch served"
                  name="branchId"
                  options={[{ value: "", label: "—" }, ...branchOptions.filter((b) => !scope || b.companyId === scope).map((b) => ({ value: String(b.id), label: b.name }))]}
                />
                <fieldset>
                  <legend className="mb-1 text-xs font-medium text-slate-600 dark:text-slate-300">Stop sequence (ctrl/cmd-click for multiple)</legend>
                  <select name="stopIds" multiple size={6} className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950">
                    {stopRows.map((s) => (
                      <option key={s.stop.id} value={s.stop.id}>
                        {s.stop.name} ({s.stop.zone ?? "—"})
                      </option>
                    ))}
                  </select>
                </fieldset>
              </div>
            </ActionForm>
          </Card>

          <Card title="Add a stop">
            <ActionForm action={createStopAction} submitLabel="Add stop" resetOnSuccess>
              {!scope ? <Field label="Client" name="companyId" required options={companyOptions.map((c) => ({ value: String(c.id), label: c.name }))} /> : null}
              <div className="space-y-3">
                <Field label="Stop name" name="name" required placeholder="Dansoman Junction" />
                <Field label="Zone" name="zone" placeholder="Dansoman" />
                <Field label="Address" name="address" />
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Latitude" name="lat" type="number" step="0.0001" defaultValue={5.548} />
                  <Field label="Longitude" name="lng" type="number" step="0.0001" defaultValue={-0.241} />
                </div>
              </div>
            </ActionForm>
          </Card>
        </div>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <Card title="Stop register" padded={false}>
          <Table head={["Stop", "Client", "Zone", "Coordinates", "Bookings"]}>
            {stopRows.map((s) => (
              <tr key={s.stop.id}>
                <Td className="font-medium">{s.stop.name}</Td>
                <Td className="text-xs">{s.company}</Td>
                <Td className="text-xs">{s.stop.zone ?? "—"}</Td>
                <Td className="text-xs tabular-nums">
                  {s.stop.lat ?? "—"}, {s.stop.lng ?? "—"}
                </Td>
                <Td className="tabular-nums text-xs">{Number(s.pickupCount)}</Td>
              </tr>
            ))}
          </Table>
          {!stopRows.length ? <div className="p-4"><EmptyState title="No stops" /></div> : null}
        </Card>

        <Card title="Passenger density by zone" subtitle="Drives corridor planning and vehicle sizing">
          <Table head={["Zone", "Employees", "Suggested vehicle"]}>
            {zoneStats.map((z) => (
              <tr key={z.zone ?? "none"}>
                <Td className="font-medium">{z.zone ?? "Unzoned"}</Td>
                <Td className="tabular-nums">{Number(z.total)}</Td>
                <Td className="text-xs">
                  {Number(z.total) > 20 ? "33-seat coach" : Number(z.total) > 12 ? "18–24 seat bus" : Number(z.total) > 5 ? "14-seat minibus" : "Sedan / SUV"}
                </Td>
              </tr>
            ))}
          </Table>
          <p className="mt-3 text-xs text-slate-400">
            Distances are computed with the haversine formula; the current corridor sample spans{" "}
            {distanceKm({ lat: 5.534, lng: -0.416 }, { lat: 5.6837, lng: -0.1664 }).toFixed(1)} km (Kasoa → Madina).
          </p>
        </Card>
      </div>
    </div>
  );
}
