import { desc, eq, ilike, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { auditLogs, companies } from "@/db/schema";
import { Card, EmptyState, PageHeader, StatCard, Table, Td, inputClass } from "@/components/ui";
import { requireSection } from "@/lib/auth";
import { dateTime } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function AuditPage({ searchParams }: { searchParams: Promise<{ q?: string; action?: string }> }) {
  await requireSection("audit");
  const { q = "", action = "" } = await searchParams;

  const filters = [
    q ? or(ilike(auditLogs.actorEmail, `%${q}%`), ilike(auditLogs.action, `%${q}%`), ilike(auditLogs.entity, `%${q}%`)) : undefined,
    action ? eq(auditLogs.action, action) : undefined,
  ].filter(Boolean);

  const rows = await db
    .select({ log: auditLogs, company: companies.name })
    .from(auditLogs)
    .leftJoin(companies, eq(companies.id, auditLogs.companyId))
    .where(filters.length ? filters[0] : undefined)
    .orderBy(desc(auditLogs.createdAt))
    .limit(150);

  const byAction = await db
    .select({ action: auditLogs.action, v: sql<number>`count(*)` })
    .from(auditLogs)
    .groupBy(auditLogs.action)
    .orderBy(sql`count(*) desc`)
    .limit(8);

  return (
    <div>
      <PageHeader
        title="Audit trail"
        subtitle="Immutable record of every privileged action, with actor, entity, tenant and payload."
      />

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Log entries" value={byAction.reduce((s, a) => s + Number(a.v), 0)} icon="🗂️" />
        <StatCard label="Distinct actions" value={byAction.length} icon="🔍" />
        <StatCard label="Most frequent" value={byAction[0]?.action ?? "—"} icon="📈" />
        <StatCard label="Retention policy" value="24 months" icon="🗄️" hint="GPS events 90 days, sessions 7 days" />
      </div>

      <Card className="mt-6" title="Search the trail">
        <form className="grid gap-3 sm:grid-cols-3" method="get">
          <input name="q" defaultValue={q} placeholder="Actor email, action or entity" className={inputClass} />
          <select name="action" defaultValue={action} className={inputClass}>
            <option value="">All actions</option>
            {byAction.map((a) => (
              <option key={a.action} value={a.action}>
                {a.action} ({Number(a.v)})
              </option>
            ))}
          </select>
          <button type="submit" className="rounded-lg bg-navy-800 px-4 py-2 text-sm font-medium text-white dark:bg-teal-600">
            Search
          </button>
        </form>
      </Card>

      <Card className="mt-6" title="Recent activity" padded={false}>
        <Table head={["Timestamp", "Actor", "Action", "Entity", "Client", "Details", "IP"]}>
          {rows.map((r) => (
            <tr key={r.log.id}>
              <Td className="whitespace-nowrap text-xs">{dateTime(r.log.createdAt)}</Td>
              <Td className="text-xs">{r.log.actorEmail ?? "system"}</Td>
              <Td className="text-xs font-medium">{r.log.action}</Td>
              <Td className="text-xs">
                {r.log.entity}
                {r.log.entityId ? ` #${r.log.entityId}` : ""}
              </Td>
              <Td className="text-xs">{r.company ?? "—"}</Td>
              <Td className="max-w-xs truncate text-xs text-slate-400">{r.log.details ? JSON.stringify(r.log.details) : "—"}</Td>
              <Td className="text-xs">{r.log.ip ?? "—"}</Td>
            </tr>
          ))}
        </Table>
        {!rows.length ? <div className="p-4"><EmptyState title="No audit entries match your search" /></div> : null}
      </Card>
    </div>
  );
}
