import Link from "next/link";
import { and, asc, desc, eq, inArray, isNull, sql } from "drizzle-orm";
import { db } from "@/db";
import { bookings, companies, drivers, employees, incidents, trips, vehicles } from "@/db/schema";
import { ActionForm, InlineActionForm } from "@/components/action-form";
import { LiveMap, type MapPoint } from "@/components/live-map";
import { Card, DemoNotice, EmptyState, Field, PageHeader, StatCard, StatusBadge, Table, Td } from "@/components/ui";
import { assignResourcesAction, createIncidentAction, updateTripStatusAction } from "@/app/actions/ops";
import { companyScope, requireSection } from "@/lib/auth";
import { getLatestPositions, getLiveTrips } from "@/lib/queries";
import { dateOnly, humanize, timeOnly, todayISO } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function DispatchPage() {
  const user = await requireSection("dispatch");
  const scope = companyScope(user);

  const [live, pendingRows, openIncidents, driverRows, vehicleRows] = await Promise.all([
    getLiveTrips(scope),
    db
      .select({ booking: bookings, employee: employees, company: companies.name })
      .from(bookings)
      .innerJoin(employees, eq(employees.id, bookings.employeeId))
      .innerJoin(companies, eq(companies.id, bookings.companyId))
      .where(and(inArray(bookings.status, ["pending", "waitlisted"]), scope ? eq(bookings.companyId, scope) : undefined))
      .orderBy(asc(bookings.bookingDate))
      .limit(20),
    db
      .select({ incident: incidents, company: companies.name, vehicle: vehicles.registrationNo })
      .from(incidents)
      .leftJoin(companies, eq(companies.id, incidents.companyId))
      .leftJoin(vehicles, eq(vehicles.id, incidents.vehicleId))
      .where(inArray(incidents.status, ["open", "acknowledged"]))
      .orderBy(desc(incidents.reportedAt))
      .limit(10),
    db.select().from(drivers).orderBy(asc(drivers.fullName)),
    db.select().from(vehicles).orderBy(asc(vehicles.registrationNo)),
  ]);

  const positions = await getLatestPositions(live.map((l) => l.trip.id));
  const points: MapPoint[] = [];
  for (const l of live) {
    const pos = positions.find((p) => p.tripId === l.trip.id);
    if (!pos) continue;
    points.push({
      id: `t${l.trip.id}`,
      lat: pos.lat,
      lng: pos.lng,
      label: `${l.vehicle?.registrationNo ?? "TBC"}`,
      kind: "vehicle",
      tone: l.trip.status === "in_progress" ? "teal" : l.trip.status === "delayed" || l.trip.status === "breakdown" ? "rose" : "navy",
    });
  }

  const [unassignedTrips] = await db
    .select({ v: sql<number>`count(*)` })
    .from(trips)
    .where(and(inArray(trips.status, ["scheduled", "dispatching"]), sql`(${trips.vehicleId} is null or ${trips.driverId} is null)`));

  const [departures] = await db
    .select({ v: sql<number>`count(*)` })
    .from(trips)
    .where(and(eq(trips.tripDate, todayISO()), inArray(trips.status, ["scheduled", "dispatching"])));

  const [delayed] = await db
    .select({ v: sql<number>`count(*)` })
    .from(trips)
    .where(and(eq(trips.tripDate, todayISO()), inArray(trips.status, ["delayed", "breakdown"])));

  const [notificationsToday] = await db
    .select({ v: sql<number>`count(*)` })
    .from(bookings)
    .where(and(isNull(bookings.cancelledAt), eq(bookings.bookingDate, todayISO())));

  return (
    <div>
      <PageHeader
        title="Live dispatch"
        subtitle="Command centre for today's journeys: assignments, departures, delays, breakdowns and passenger status."
      />

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        <StatCard label="Active duties" value={live.length} tone="info" icon="🛰️" />
        <StatCard label="Departures pending" value={Number(departures?.v ?? 0)} icon="⏱️" />
        <StatCard label="Delayed / breakdown" value={Number(delayed?.v ?? 0)} tone={Number(delayed?.v ?? 0) ? "danger" : "positive"} icon="⚠️" />
        <StatCard label="Awaiting resources" value={Number(unassignedTrips?.v ?? 0)} tone={Number(unassignedTrips?.v ?? 0) ? "warning" : "positive"} icon="🔧" />
        <StatCard label="Passengers today" value={Number(notificationsToday?.v ?? 0)} icon="👥" />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <Card title="Live map" subtitle="Vehicle positions refresh every 15 seconds" className="lg:col-span-2">
          {points.length ? (
            <>
              <LiveMap initial={points} pollUrl="/api/dispatch/live" />
              <DemoNotice>
                Positions come from the driver app / manual dispatcher entry while no telematics provider key is
                configured. Configure NEXT_PUBLIC_MAP_PROVIDER and a basemap key for a real road map.
              </DemoNotice>
            </>
          ) : (
            <EmptyState title="No vehicles are reporting positions" hint="Drivers share their location when they start a trip from the driver app." />
          )}
        </Card>

        <Card title="Operational alerts" padded={false}>
          <ul className="divide-y divide-slate-100 text-xs dark:divide-slate-800">
            {openIncidents.map((i) => (
              <li key={i.incident.id} className="px-4 py-3">
                <div className="flex items-center justify-between">
                  <span className="font-semibold capitalize text-slate-700 dark:text-slate-200">
                    {i.incident.type.replace("_", " ")}
                  </span>
                  <StatusBadge status={i.incident.status} />
                </div>
                <p className="mt-1 text-slate-500">{i.incident.description}</p>
                <p className="mt-1 text-slate-400">
                  {i.company ?? "Platform"} {i.vehicle ? `· ${i.vehicle}` : ""} · {dateOnly(i.incident.reportedAt)}
                </p>
              </li>
            ))}
            {!openIncidents.length ? <li className="px-4 py-4 text-slate-400">No open incidents.</li> : null}
          </ul>
          <div className="border-t border-slate-100 p-4 dark:border-slate-800">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">Report an operational event</p>
            <ActionForm action={createIncidentAction} submitLabel="Raise incident" resetOnSuccess>
              <div className="space-y-3">
                <Field
                  label="Type"
                  name="type"
                  options={["breakdown", "accident", "sos", "missed_pickup", "delay", "no_show", "safety"].map((t) => ({ value: t, label: humanize(t) }))}
                />
                <Field label="Severity" name="severity" options={["low", "medium", "high", "critical"].map((s) => ({ value: s, label: s }))} />
                <Field label="Trip" name="tripId" options={[{ value: "", label: "—" }, ...live.map((l) => ({ value: String(l.trip.id), label: `${l.trip.reference} · ${l.company}` }))]} />
                <Field label="Vehicle" name="vehicleId" options={[{ value: "", label: "—" }, ...vehicleRows.map((v) => ({ value: String(v.id), label: v.registrationNo }))]} />
                <Field label="Description" name="description" rows={2} required />
                <Field label="Location" name="location" />
              </div>
            </ActionForm>
          </div>
        </Card>
      </div>

      <Card className="mt-6" title="Active & scheduled duties" padded={false}>
        <Table head={["Trip", "Client", "Departure", "Vehicle", "Driver", "Seats", "Status", "Actions"]}>
          {live.map((l) => (
            <tr key={l.trip.id}>
              <Td>
                <Link href={`/trips/${l.trip.id}`} className="font-medium text-teal-700 hover:underline dark:text-teal-400">
                  {l.trip.reference}
                </Link>
                <p className="text-xs text-slate-400">{humanize(l.trip.direction)}</p>
              </Td>
              <Td className="text-xs">{l.company.name}</Td>
              <Td className="text-xs">
                {timeOnly(l.trip.scheduledDeparture)}
                <p className="text-slate-400">{dateOnly(l.trip.tripDate)}</p>
              </Td>
              <Td className="text-xs">{l.vehicle ? `${l.vehicle.registrationNo} (${l.vehicle.capacity})` : <span className="text-amber-600">unassigned</span>}</Td>
              <Td className="text-xs">
                {l.driver ? l.driver.fullName : <span className="text-amber-600">unassigned</span>}
                <p className="text-slate-400">{l.driver?.phone ?? ""}</p>
              </Td>
              <Td className="tabular-nums text-xs">
                {l.trip.bookedSeats}/{l.trip.capacity}
              </Td>
              <Td>
                <StatusBadge status={l.trip.status} />
              </Td>
              <Td>
                <div className="flex flex-wrap gap-1.5">
                  <InlineActionForm action={updateTripStatusAction} hiddenFields={{ tripId: l.trip.id, status: "in_progress" }} submitLabel="Start" />
                  <InlineActionForm action={updateTripStatusAction} hiddenFields={{ tripId: l.trip.id, status: "delayed" }} submitLabel="Delay" variant="ghost" />
                  <InlineActionForm action={updateTripStatusAction} hiddenFields={{ tripId: l.trip.id, status: "completed" }} submitLabel="Complete" variant="ghost" />
                </div>
              </Td>
            </tr>
          ))}
        </Table>
        {!live.length ? <div className="p-4"><EmptyState title="No active duties" hint="Create or plan trips to populate the board." /></div> : null}
      </Card>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <Card title="Assign resources to a duty">
          <ActionForm action={assignResourcesAction} submitLabel="Assign">
            <Field label="Trip" name="tripId" required options={live.map((l) => ({ value: String(l.trip.id), label: `${l.trip.reference} · ${l.company} · ${timeOnly(l.trip.scheduledDeparture)}` }))} />
            <div className="mt-3 space-y-3">
              <Field
                label="Vehicle"
                name="vehicleId"
                options={[
                  { value: "", label: "Keep current" },
                  ...vehicleRows.filter((v) => !["under_maintenance", "out_of_service"].includes(v.status)).map((v) => ({ value: String(v.id), label: `${v.registrationNo} · ${v.capacity} seats · ${v.status.replace("_", " ")}` })),
                ]}
              />
              <Field
                label="Driver"
                name="driverId"
                options={[{ value: "", label: "Keep current" }, ...driverRows.filter((d) => d.status !== "unavailable").map((d) => ({ value: String(d.id), label: `${d.fullName} · ${d.status.replace("_", " ")}` }))]}
              />
            </div>
          </ActionForm>
          <p className="mt-2 text-xs text-slate-400">
            Vehicle capacity must cover the booked passengers and unavailable vehicles are blocked automatically.
          </p>
        </Card>

        <Card title="Pending & waitlisted requests" padded={false}>
          <Table head={["Employee", "Client", "Date", "Leg", "Status", ""]}>
            {pendingRows.map((p) => (
              <tr key={p.booking.id}>
                <Td className="text-xs">
                  <p className="font-medium">{p.employee.fullName}</p>
                  <p className="text-slate-400">{p.booking.reference}</p>
                </Td>
                <Td className="text-xs">{p.company}</Td>
                <Td className="text-xs">{dateOnly(p.booking.bookingDate)}</Td>
                <Td className="text-xs">{humanize(p.booking.direction)}</Td>
                <Td>
                  <StatusBadge status={p.booking.status} />
                </Td>
                <Td>
                  <Link href="/bookings" className="text-xs font-medium text-teal-700 hover:underline dark:text-teal-400">
                    Review →
                  </Link>
                </Td>
              </tr>
            ))}
          </Table>
          {!pendingRows.length ? <div className="p-4"><EmptyState title="No pending requests" /></div> : null}
        </Card>
      </div>

      <Card className="mt-6" title="Driver availability" padded={false}>
        <Table head={["Driver", "Phone", "Licence", "Status", "Rating"]}>
          {driverRows.slice(0, 12).map((d) => (
            <tr key={d.id}>
              <Td className="font-medium">{d.fullName}</Td>
              <Td className="text-xs">{d.phone}</Td>
              <Td className="text-xs">
                {d.licenseNo} · exp {dateOnly(d.licenseExpiry)}
              </Td>
              <Td>
                <StatusBadge status={d.status} />
              </Td>
              <Td className="tabular-nums text-xs">{Number(d.ratingAvg ?? 0).toFixed(1)} ★</Td>
            </tr>
          ))}
        </Table>
      </Card>
    </div>
  );
}
