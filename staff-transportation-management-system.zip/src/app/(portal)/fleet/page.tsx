import { asc, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { companies, maintenanceRecords, vehicles } from "@/db/schema";
import { ActionForm, InlineActionForm } from "@/components/action-form";
import { Card, EmptyState, Field, PageHeader, ProgressBar, StatCard, StatusBadge, Table, Td } from "@/components/ui";
import { createVehicleAction, scheduleMaintenanceAction, updateVehicleAction } from "@/app/actions/admin";
import { requireSection } from "@/lib/auth";
import { getDocumentExpiries, getMaintenanceDue } from "@/lib/queries";
import { dateOnly, isoDaysFromNow, money, n, todayISO } from "@/lib/utils";

export const dynamic = "force-dynamic";

const VEHICLE_STATUS = ["available", "assigned", "on_trip", "under_maintenance", "out_of_service"];

export default async function FleetPage() {
  await requireSection("fleet");

  const rows = await db
    .select({
      vehicle: vehicles,
      company: companies.name,
      trips: sql<number>`(select count(*) from trips t where t.vehicle_id = ${vehicles.id})`,
      completed: sql<number>`(select count(*) from trips t where t.vehicle_id = ${vehicles.id} and t.status = 'completed')`,
      maintenanceCost: sql<string>`(select coalesce(sum(m.cost), 0) from maintenance_records m where m.vehicle_id = ${vehicles.id})`,
    })
    .from(vehicles)
    .leftJoin(companies, eq(companies.id, vehicles.assignedCompanyId))
    .orderBy(asc(vehicles.registrationNo));

  const maintenance = await db
    .select({ record: maintenanceRecords, vehicle: vehicles.registrationNo })
    .from(maintenanceRecords)
    .innerJoin(vehicles, eq(vehicles.id, maintenanceRecords.vehicleId))
    .orderBy(desc(maintenanceRecords.serviceDate))
    .limit(10);

  const [{ vehicleDocs }, due] = await Promise.all([getDocumentExpiries(60), getMaintenanceDue()]);
  const companyOptions = await db.select({ id: companies.id, name: companies.name }).from(companies);

  const utilisation = rows.length
    ? (rows.filter((r) => ["assigned", "on_trip"].includes(r.vehicle.status)).length / rows.length) * 100
    : 0;

  return (
    <div>
      <PageHeader title="Fleet management" subtitle="Vehicles, documents, availability, maintenance and utilisation." />

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Vehicles" value={rows.length} icon="🚐" hint={`${rows.filter((r) => r.vehicle.status === "available").length} available now`} />
        <StatCard label="Fleet utilisation" value={`${utilisation.toFixed(0)}%`} tone="info" icon="📈" />
        <StatCard label="Maintenance / out of service" value={rows.filter((r) => ["under_maintenance", "out_of_service"].includes(r.vehicle.status)).length} tone="warning" icon="🔧" />
        <StatCard label="Document alerts (60d)" value={vehicleDocs.length} tone={vehicleDocs.length ? "danger" : "positive"} icon="📄" />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <Card title="Vehicle register" className="lg:col-span-2" padded={false}>
          <Table head={["Vehicle", "Type", "Seats", "Assigned client", "Documents", "Trips", "Status", ""]}>
            {rows.map((r) => {
              const expiring = [r.vehicle.insuranceExpiry, r.vehicle.roadworthinessExpiry, r.vehicle.registrationExpiry]
                .filter((d) => d && d <= isoDaysFromNow(45))
                .map((d) => dateOnly(d));
              return (
                <tr key={r.vehicle.id}>
                  <Td>
                    <p className="font-medium text-slate-800 dark:text-slate-200">{r.vehicle.registrationNo}</p>
                    <p className="text-xs text-slate-400">
                      {r.vehicle.make} {r.vehicle.model} {r.vehicle.year ? `· ${r.vehicle.year}` : ""}
                    </p>
                    <p className="text-xs text-slate-400">{n(r.vehicle.odometerKm).toLocaleString()} km · {n(r.vehicle.avgKmPerLitre)} km/L</p>
                  </Td>
                  <Td className="text-xs capitalize">
                    {r.vehicle.vehicleType}
                    <p className="capitalize text-slate-400">{r.vehicle.fuelType} · {r.vehicle.ownership}</p>
                  </Td>
                  <Td className="tabular-nums">{r.vehicle.capacity}</Td>
                  <Td className="text-xs">{r.company ?? "Shared fleet"}</Td>
                  <Td className="text-xs">
                    <p>Ins {dateOnly(r.vehicle.insuranceExpiry)}</p>
                    <p className="text-slate-400">Road {dateOnly(r.vehicle.roadworthinessExpiry)}</p>
                    {expiring.length ? <p className="text-amber-600 dark:text-amber-400">{expiring.length} expiring soon</p> : null}
                  </Td>
                  <Td className="tabular-nums text-xs">
                    {Number(r.completed)}/{Number(r.trips)}
                    <p className="text-slate-400">{money(r.maintenanceCost)}</p>
                  </Td>
                  <Td>
                    <StatusBadge status={r.vehicle.status} />
                  </Td>
                  <Td>
                    <InlineActionForm
                      action={updateVehicleAction}
                      hiddenFields={{ id: r.vehicle.id }}
                      submitLabel="Update"
                      variant="ghost"
                    />
                  </Td>
                </tr>
              );
            })}
          </Table>
          {!rows.length ? <div className="p-4"><EmptyState title="No vehicles registered" /></div> : null}
        </Card>

        <div className="space-y-4">
          <Card title="Add a vehicle">
            <ActionForm action={createVehicleAction} submitLabel="Add vehicle" resetOnSuccess>
              <div className="space-y-3">
                <Field label="Registration number" name="registrationNo" required placeholder="GR-1234-25" />
                <div className="grid grid-cols-3 gap-2">
                  <Field label="Make" name="make" required placeholder="Toyota" />
                  <Field label="Model" name="model" placeholder="Hiace" />
                  <Field label="Year" name="year" type="number" placeholder="2024" />
                </div>
                <div className="grid grid-cols-3 gap-2">
                  <Field label="Seats" name="capacity" type="number" required defaultValue={14} />
                  <Field
                    label="Type"
                    name="vehicleType"
                    options={["sedan", "suv", "minibus", "van", "bus"].map((v) => ({ value: v, label: v }))}
                  />
                  <Field label="Fuel" name="fuelType" options={["diesel", "petrol", "electric", "hybrid", "cng"].map((v) => ({ value: v, label: v }))} />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Ownership" name="ownership" options={["owned", "leased", "contracted"].map((v) => ({ value: v, label: v }))} />
                  <Field label="Cost per km (GHS)" name="costPerKm" type="number" step="0.01" defaultValue={0.9} />
                </div>
                <Field label="Assigned client" name="assignedCompanyId" options={[{ value: "", label: "Shared fleet" }, ...companyOptions.map((c) => ({ value: String(c.id), label: c.name }))]} />
                <div className="grid grid-cols-3 gap-2">
                  <Field label="Insurance expiry" name="insuranceExpiry" type="date" />
                  <Field label="Roadworthiness" name="roadworthinessExpiry" type="date" />
                  <Field label="Registration" name="registrationExpiry" type="date" />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Odometer (km)" name="odometerKm" type="number" />
                  <Field label="Avg km / litre" name="avgKmPerLitre" type="number" step="0.1" />
                </div>
              </div>
            </ActionForm>
          </Card>

          <Card title="Update vehicle status & documents">
            <ActionForm action={updateVehicleAction} submitLabel="Save changes">
              <Field
                label="Vehicle"
                name="id"
                required
                options={rows.map((r) => ({ value: String(r.vehicle.id), label: `${r.vehicle.registrationNo} · ${r.vehicle.make} ${r.vehicle.model}` }))}
              />
              <div className="mt-3 space-y-3">
                <Field label="Status" name="status" options={VEHICLE_STATUS.map((s) => ({ value: s, label: s.replace(/_/g, " ") }))} />
                <div className="grid grid-cols-3 gap-2">
                  <Field label="Insurance expiry" name="insuranceExpiry" type="date" />
                  <Field label="Roadworthiness" name="roadworthinessExpiry" type="date" />
                  <Field label="Registration" name="registrationExpiry" type="date" />
                </div>
                <Field label="Odometer (km)" name="odometerKm" type="number" />
                <Field label="Assigned client" name="assignedCompanyId" options={[{ value: "", label: "Shared fleet" }, ...companyOptions.map((c) => ({ value: String(c.id), label: c.name }))]} />
                <Field label="Notes" name="notes" rows={2} />
              </div>
            </ActionForm>
            <p className="mt-2 text-xs text-slate-400">Vehicles under maintenance or out of service are blocked from trip assignment.</p>
          </Card>

          <Card title="Log maintenance" subtitle="Preventive service, repairs and inspections">
            <ActionForm action={scheduleMaintenanceAction} submitLabel="Log maintenance" resetOnSuccess>
              <div className="space-y-3">
                <Field label="Vehicle" name="vehicleId" required options={rows.map((r) => ({ value: String(r.vehicle.id), label: r.vehicle.registrationNo }))} />
                <Field label="Type" name="type" options={[{ value: "preventive", label: "Preventive service" }, { value: "repair", label: "Repair" }, { value: "inspection", label: "Safety inspection" }]} />
                <Field label="Description" name="description" required rows={2} />
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Service date" name="serviceDate" type="date" required defaultValue={todayISO()} />
                  <Field label="Next service due" name="nextServiceDate" type="date" />
                </div>
                <div className="grid grid-cols-3 gap-2">
                  <Field label="Cost (GHS)" name="cost" type="number" step="0.01" />
                  <Field label="Odometer" name="odometerKm" type="number" />
                  <Field label="Garage" name="garageName" />
                </div>
                <label className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300">
                  <input type="checkbox" name="takeOffline" className="rounded" /> Take vehicle offline for this work
                </label>
              </div>
            </ActionForm>
          </Card>
        </div>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <Card title="Maintenance history" padded={false}>
          <Table head={["Vehicle", "Type", "Description", "Cost", "Service date", "Next due"]}>
            {maintenance.map((m) => (
              <tr key={m.record.id}>
                <Td className="font-medium">{m.vehicle}</Td>
                <Td className="text-xs capitalize">{m.record.type}</Td>
                <Td className="text-xs">{m.record.description}</Td>
                <Td className="tabular-nums">{money(m.record.cost)}</Td>
                <Td className="text-xs">{dateOnly(m.record.serviceDate)}</Td>
                <Td className="text-xs">{dateOnly(m.record.nextServiceDate)}</Td>
              </tr>
            ))}
          </Table>
          {!maintenance.length ? <div className="p-4"><EmptyState title="No maintenance records" /></div> : null}
        </Card>

        <Card title="Upcoming service & document reminders">
          <ul className="space-y-2 text-xs">
            {due.slice(0, 6).map((v) => (
              <li key={v.id} className="rounded-lg border border-slate-200 p-3 dark:border-slate-800">
                <p className="font-semibold text-slate-700 dark:text-slate-200">
                  {v.registrationNo} · {v.model}
                </p>
                <p className="text-slate-500">
                  Odometer {n(v.odometerKm).toLocaleString()} km · last service {v.lastService ? dateOnly(v.lastService) : "never"}
                </p>
                <div className="mt-2">
                  <ProgressBar value={Math.min(100, (n(v.odometerKm) / 300000) * 100)} tone="amber" />
                </div>
              </li>
            ))}
            {vehicleDocs.slice(0, 4).map((v) => (
              <li key={`d${v.id}`} className="rounded-lg border border-amber-200 bg-amber-50 p-3 text-amber-800 dark:border-amber-800 dark:bg-amber-950/40 dark:text-amber-200">
                <span className="font-semibold">{v.label}</span> — insurance {dateOnly(v.insurance)}, roadworthiness {dateOnly(v.roadworthy)}
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </div>
  );
}
