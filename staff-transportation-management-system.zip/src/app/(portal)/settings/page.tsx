import { desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { companies, notifications, users } from "@/db/schema";
import { ActionForm, InlineActionForm } from "@/components/action-form";
import { Card, DefinitionList, DemoNotice, EmptyState, Field, PageHeader, StatCard, StatusBadge, Table, Td } from "@/components/ui";
import { inviteUserAction, updateUserStatusAction } from "@/app/actions/admin";
import { markNotificationsReadAction } from "@/app/actions/ops";
import { requireUser } from "@/lib/auth";
import { ROLE_LABELS, can, type Role } from "@/lib/rbac";
import { dateTime, n } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function SettingsPage() {
  const user = await requireUser();
  const role = user.role as Role;
  const canManageUsers = can(role, "user.manage");

  const userRows = await db
    .select({ user: users, company: companies.name })
    .from(users)
    .leftJoin(companies, eq(companies.id, users.companyId))
    .orderBy(desc(users.createdAt))
    .limit(60);

  const myNotifications = await db
    .select()
    .from(notifications)
    .where(eq(notifications.userId, user.id))
    .orderBy(desc(notifications.createdAt))
    .limit(15);

  const [sessionStats] = await db.execute<{ active: string; total: string }>(sql`select (select count(*) from sessions where expires_at > now())::text as active, (select count(*) from users)::text as total`).then((r) => r.rows);

  const companyOptions = await db.select({ id: companies.id, name: companies.name }).from(companies);

  return (
    <div>
      <PageHeader title="Settings & user administration" subtitle="Your profile, portal users, invitations and notification centre." />

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Portal users" value={n(sessionStats?.total)} icon="👤" />
        <StatCard label="Active sessions" value={n(sessionStats?.active)} tone="info" icon="🔐" />
        <StatCard label="Roles available" value={Object.keys(ROLE_LABELS).length} icon="🎭" />
        <StatCard label="Unread notifications" value={myNotifications.filter((n) => !n.readAt).length} tone={myNotifications.some((n) => !n.readAt) ? "warning" : "positive"} icon="🔔" />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <Card title="My profile">
          <DefinitionList
            items={[
              { label: "Name", value: user.fullName },
              { label: "Email", value: user.email },
              { label: "Role", value: ROLE_LABELS[role] },
              { label: "Client scope", value: user.companyId ? (companyOptions.find((c) => c.id === user.companyId)?.name ?? "—") : "Platform (all clients)" },
              { label: "Two-factor", value: user.twoFactorEnabled ? "Enabled" : "Disabled" },
            ]}
          />
          <div className="mt-4 rounded-lg bg-slate-50 p-3 text-xs text-slate-500 dark:bg-slate-950">
            <p className="font-semibold text-slate-600 dark:text-slate-300">Role permissions</p>
            <p className="mt-1">
              Your role grants access to: company management, employee registration, fleet and driver administration,
              dispatch, bookings, incidents{can(role, "finance.manage") ? ", finance" : ""}
              {can(role, "audit.view") ? " and the audit trail" : ""}.
            </p>
          </div>
          <form action="/api/auth/logout" method="post" className="mt-4">
            <button type="submit" className="w-full rounded-lg bg-rose-600 px-3 py-2 text-sm font-medium text-white hover:bg-rose-500">
              Sign out of this device
            </button>
          </form>
        </Card>

        <Card title="Notification centre" className="lg:col-span-2" padded={false}>
          <div className="flex items-center justify-between border-b border-slate-100 px-4 py-2 dark:border-slate-800">
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">Latest notifications</p>
            <InlineActionForm action={markNotificationsReadAction} hiddenFields={{}} submitLabel="Mark all read" variant="ghost" />
          </div>
          <ul className="divide-y divide-slate-100 text-xs dark:divide-slate-800">
            {myNotifications.map((n) => (
              <li key={n.id} className="flex items-start justify-between gap-3 px-4 py-3">
                <div>
                  <p className="font-medium text-slate-700 dark:text-slate-200">{n.title}</p>
                  <p className="text-slate-500">{n.body}</p>
                  <p className="text-slate-400">
                    {n.category} · {n.channel} · {dateTime(n.createdAt)}
                  </p>
                </div>
                <StatusBadge status={n.readAt ? "resolved" : "open"} />
              </li>
            ))}
            {!myNotifications.length ? <li className="px-4 py-6 text-slate-400">No notifications yet.</li> : null}
          </ul>
          <div className="border-t border-slate-100 p-3 dark:border-slate-800">
            <DemoNotice>
              In-app notifications are persisted and delivered on login. Email/SMS/push delivery requires provider
              credentials (SMTP, Arkesel, SMS gateway or Firebase) — not configured in this environment.
            </DemoNotice>
          </div>
        </Card>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <Card title="Portal users & invitations" className="lg:col-span-2" padded={false}>
          <Table head={["User", "Role", "Client scope", "2FA", "Status", "Last login", ""]}>
            {userRows.map((u) => (
              <tr key={u.user.id}>
                <Td className="text-xs">
                  <p className="font-medium">{u.user.fullName}</p>
                  <p className="text-slate-400">{u.user.email}</p>
                </Td>
                <Td className="text-xs">{ROLE_LABELS[u.user.role as Role]}</Td>
                <Td className="text-xs">{u.company ?? "Platform"}</Td>
                <Td className="text-xs">{u.user.twoFactorEnabled ? "✅" : "—"}</Td>
                <Td>
                  <StatusBadge status={u.user.status} />
                </Td>
                <Td className="text-xs">{u.user.lastLoginAt ? dateTime(u.user.lastLoginAt) : "never"}</Td>
                <Td>
                  {canManageUsers ? (
                    <InlineActionForm
                      action={updateUserStatusAction}
                      hiddenFields={{ id: u.user.id, status: u.user.status === "active" ? "suspended" : "active" }}
                      submitLabel={u.user.status === "active" ? "Suspend" : "Activate"}
                      variant="ghost"
                      confirm={u.user.status === "active" ? `Suspend ${u.user.email}?` : undefined}
                    />
                  ) : null}
                </Td>
              </tr>
            ))}
          </Table>
          {!userRows.length ? <div className="p-4"><EmptyState title="No users" /></div> : null}
        </Card>

        {canManageUsers ? (
          <Card title="Invite a user" subtitle="Temporary password is shown once">
            <ActionForm action={inviteUserAction} submitLabel="Create account" resetOnSuccess>
              <div className="space-y-3">
                <Field label="Full name" name="fullName" required />
                <Field label="Email" name="email" type="email" required />
                <Field label="Phone" name="phone" />
                <Field
                  label="Role"
                  name="role"
                  required
                  options={Object.entries(ROLE_LABELS).map(([value, label]) => ({ value, label }))}
                />
                <Field
                  label="Client scope"
                  name="companyId"
                  options={[{ value: "", label: "Platform (all clients)" }, ...companyOptions.map((c) => ({ value: String(c.id), label: c.name }))]}
                  hint="Corporate HR and employee accounts must be scoped to a client."
                />
              </div>
            </ActionForm>
            <p className="mt-3 text-xs text-slate-400">
              Privileged roles (super admin, operations manager, finance officer) are provisioned with two-factor
              authentication enabled.
            </p>
          </Card>
        ) : (
          <Card title="Platform configuration">
            <DefinitionList
              items={[
                { label: "Currency", value: "GHS (Ghana Cedi)" },
                { label: "Timezone", value: "Africa/Accra (GMT)" },
                { label: "Mapping provider", value: "Demo vector map" },
                { label: "Payment provider", value: "Interface only — no credentials" },
                { label: "Session lifetime", value: "7 days" },
                { label: "GPS retention", value: "90 days" },
              ]}
            />
          </Card>
        )}
      </div>
    </div>
  );
}
