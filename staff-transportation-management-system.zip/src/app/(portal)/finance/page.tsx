import { asc, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { companies, driverEarnings, drivers, invoiceLines, invoices, payments, serviceAgreements, trips } from "@/db/schema";
import { ActionForm } from "@/components/action-form";
import { BarChart } from "@/components/charts";
import { Card, DemoNotice, EmptyState, Field, PageHeader, StatCard, StatusBadge, Table, Td } from "@/components/ui";
import { approveEarningsAction, generateInvoiceAction, recordPaymentAction } from "@/app/actions/admin";
import { companyScope, requireSection } from "@/lib/auth";
import { getRevenueByCompany } from "@/lib/queries";
import { dateOnly, humanize, isoDaysFromNow, money, n, todayISO } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function FinancePage() {
  const user = await requireSection("finance");
  const scope = companyScope(user);

  const invoiceRows = await db
    .select({ invoice: invoices, company: companies.name })
    .from(invoices)
    .innerJoin(companies, eq(companies.id, invoices.companyId))
    .where(scope ? eq(invoices.companyId, scope) : undefined)
    .orderBy(desc(invoices.issuedAt))
    .limit(30);

  const paymentRows = await db
    .select({ payment: payments, company: companies.name, invoiceNo: invoices.invoiceNo })
    .from(payments)
    .innerJoin(companies, eq(companies.id, payments.companyId))
    .leftJoin(invoices, eq(invoices.id, payments.invoiceId))
    .where(scope ? eq(payments.companyId, scope) : undefined)
    .orderBy(desc(payments.createdAt))
    .limit(20);

  const lineRows = invoiceRows.length
    ? await db
        .select({ line: invoiceLines, invoiceNo: invoices.invoiceNo })
        .from(invoiceLines)
        .innerJoin(invoices, eq(invoices.id, invoiceLines.invoiceId))
        .orderBy(desc(invoiceLines.id))
        .limit(24)
    : [];

  const earnings = await db
    .select({
      driver: drivers.fullName,
      base: sql<string>`sum(${driverEarnings.basePay})`,
      overtime: sql<string>`sum(${driverEarnings.overtimePay})`,
      allowance: sql<string>`sum(${driverEarnings.allowance})`,
      total: sql<string>`sum(${driverEarnings.total})`,
      trips: sql<number>`count(*)`,
      period: sql<string>`min(${driverEarnings.periodStart})`,
      status: sql<string>`min(${driverEarnings.status})`,
    })
    .from(driverEarnings)
    .innerJoin(drivers, eq(drivers.id, driverEarnings.driverId))
    .groupBy(drivers.fullName)
    .orderBy(desc(sql`sum(${driverEarnings.total})`));

  const companyOptions = await db.select({ id: companies.id, name: companies.name }).from(companies).orderBy(asc(companies.name));
  const agreementRows = await db.select().from(serviceAgreements).orderBy(desc(serviceAgreements.id));
  const revenue = await getRevenueByCompany();

  const [totals] = await db
    .select({
      invoiced: sql<string>`coalesce(sum(${invoices.total}), 0)`,
      paid: sql<string>`coalesce(sum(${invoices.amountPaid}), 0)`,
      overdue: sql<string>`coalesce(sum(case when ${invoices.status} = 'overdue' then ${invoices.total} - ${invoices.amountPaid} else 0 end), 0)`,
    })
    .from(invoices)
    .where(scope ? eq(invoices.companyId, scope) : undefined);

  const payrollTotal = earnings.reduce((s, e) => s + n(e.total), 0);
  const [tripCosts] = await db
    .select({
      trips: sql<number>`count(*)`,
      km: sql<string>`coalesce(sum(${trips.plannedKm}), 0)`,
    })
    .from(trips)
    .where(scope ? eq(trips.companyId, scope) : undefined);

  return (
    <div>
      <PageHeader title="Billing, invoicing & driver payroll" subtitle="Corporate contracts, monthly invoicing in GHS, collections and driver earnings." />

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        <StatCard label="Invoiced" value={money(totals?.invoiced)} icon="🧾" />
        <StatCard label="Collected" value={money(totals?.paid)} tone="positive" icon="✅" />
        <StatCard label="Outstanding" value={money(n(totals?.invoiced) - n(totals?.paid))} tone="warning" icon="⏳" />
        <StatCard label="Overdue" value={money(totals?.overdue)} tone={n(totals?.overdue) ? "danger" : "positive"} icon="🚨" />
        <StatCard label="Driver payroll accrued" value={money(payrollTotal)} icon="👷" hint={`${Number(tripCosts?.trips ?? 0)} trips · ${n(tripCosts?.km).toFixed(0)} km`} />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <Card title="Invoices" className="lg:col-span-2" padded={false}>
          <Table head={["Invoice", "Client", "Period", "Subtotal", "Tax", "Total", "Paid", "Status"]}>
            {invoiceRows.map((i) => (
              <tr key={i.invoice.id}>
                <Td className="text-xs font-medium">{i.invoice.invoiceNo}</Td>
                <Td className="text-xs">{i.company}</Td>
                <Td className="text-xs">
                  {dateOnly(i.invoice.periodStart)}
                  <p className="text-slate-400">→ {dateOnly(i.invoice.periodEnd)}</p>
                </Td>
                <Td className="tabular-nums text-xs">{money(i.invoice.subtotal)}</Td>
                <Td className="tabular-nums text-xs">{money(i.invoice.tax)}</Td>
                <Td className="tabular-nums text-xs font-medium">{money(i.invoice.total)}</Td>
                <Td className="tabular-nums text-xs">{money(i.invoice.amountPaid)}</Td>
                <Td>
                  <StatusBadge status={i.invoice.status} />
                </Td>
              </tr>
            ))}
          </Table>
          {!invoiceRows.length ? <div className="p-4"><EmptyState title="No invoices yet" hint="Generate one from completed trips." /></div> : null}
          <div className="border-t border-slate-100 p-4 dark:border-slate-800">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">Invoice lines</p>
            <Table head={["Invoice", "Description", "Qty", "Unit price", "Amount"]}>
              {lineRows.map((l) => (
                <tr key={l.line.id}>
                  <Td className="text-xs">{l.invoiceNo}</Td>
                  <Td className="text-xs">{l.line.description}</Td>
                  <Td className="tabular-nums text-xs">{n(l.line.quantity)}</Td>
                  <Td className="tabular-nums text-xs">{money(l.line.unitPrice)}</Td>
                  <Td className="tabular-nums text-xs">{money(l.line.amount)}</Td>
                </tr>
              ))}
            </Table>
          </div>
        </Card>

        <div className="space-y-4">
          <Card title="Generate an invoice" subtitle="Derived from completed trips">
            <ActionForm action={generateInvoiceAction} submitLabel="Generate invoice" resetOnSuccess>
              <div className="space-y-3">
                {!scope ? <Field label="Client" name="companyId" required options={companyOptions.map((c) => ({ value: String(c.id), label: c.name }))} /> : null}
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Period start" name="periodStart" type="date" required defaultValue={isoDaysFromNow(-30)} />
                  <Field label="Period end" name="periodEnd" type="date" required defaultValue={todayISO()} />
                </div>
                <Field label="Due date" name="dueDate" type="date" />
              </div>
            </ActionForm>
            <DemoNotice>
              Payment collection is not live: no Paystack/Flutterwave or bank transfer credentials are configured. The
              payment interface below records reconciled settlements only.
            </DemoNotice>
          </Card>

          <Card title="Record a payment">
            <ActionForm action={recordPaymentAction} submitLabel="Record payment" resetOnSuccess>
              <div className="space-y-3">
                {!scope ? <Field label="Client" name="companyId" required options={companyOptions.map((c) => ({ value: String(c.id), label: c.name }))} /> : null}
                <Field
                  label="Invoice (optional)"
                  name="invoiceId"
                  options={[{ value: "", label: "Unallocated payment" }, ...invoiceRows.map((i) => ({ value: String(i.invoice.id), label: `${i.invoice.invoiceNo} · ${money(i.invoice.total)}` }))]}
                />
                <Field label="Amount (GHS)" name="amount" type="number" step="0.01" required />
                <Field
                  label="Method"
                  name="method"
                  options={[
                    { value: "bank_transfer", label: "Bank transfer" },
                    { value: "mobile_money", label: "Mobile money" },
                    { value: "paystack", label: "Paystack" },
                    { value: "flutterwave", label: "Flutterwave" },
                    { value: "cheque", label: "Cheque" },
                    { value: "cash", label: "Cash" },
                  ]}
                />
                <Field label="Reference" name="reference" placeholder="TRF-0099123" />
                <Field label="Notes" name="notes" rows={2} />
              </div>
            </ActionForm>
          </Card>

          <Card title="Revenue by client">
            <BarChart data={revenue.map((r) => ({ label: r.company.split(" ")[0], invoiced: r.total, collected: r.paid }))} valueKey="invoiced" />
          </Card>
        </div>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <Card title="Driver earnings & payroll" className="lg:col-span-2" padded={false}>
          <Table head={["Driver", "Trips", "Base", "Overtime", "Allowance", "Total", "Period", "Status"]}>
            {earnings.map((e) => (
              <tr key={e.driver}>
                <Td className="font-medium">{e.driver}</Td>
                <Td className="tabular-nums text-xs">{Number(e.trips)}</Td>
                <Td className="tabular-nums text-xs">{money(e.base)}</Td>
                <Td className="tabular-nums text-xs">{money(e.overtime)}</Td>
                <Td className="tabular-nums text-xs">{money(e.allowance)}</Td>
                <Td className="tabular-nums text-xs font-medium">{money(e.total)}</Td>
                <Td className="text-xs">{dateOnly(e.period)}</Td>
                <Td>
                  <StatusBadge status={e.status ?? "accrued"} />
                </Td>
              </tr>
            ))}
          </Table>
          {!earnings.length ? <div className="p-4"><EmptyState title="No driver earnings yet" hint="Earnings accrue automatically when a driver completes a trip." /></div> : null}
          <div className="flex flex-wrap items-center gap-3 border-t border-slate-100 p-4 dark:border-slate-800">
            <a href="/api/reports/export?type=payroll" className="rounded-lg border border-slate-300 px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200">
              ⬇️ Export payroll CSV
            </a>
            <ActionForm action={approveEarningsAction} submitLabel="Approve accrued earnings">
              <Field label="Period start" name="periodStart" type="date" required defaultValue={isoDaysFromNow(-30)} />
            </ActionForm>
          </div>
        </Card>

        <Card title="Contracts & pricing" padded={false}>
          <ul className="divide-y divide-slate-100 text-xs dark:divide-slate-800">
            {agreementRows.map((a) => (
              <li key={a.id} className="px-4 py-3">
                <p className="font-semibold text-slate-700 dark:text-slate-200">{a.name}</p>
                <p className="text-slate-500">
                  {humanize(a.pricingModel)} · unit rate {money(a.unitRate)} · fixed {money(a.fixedMonthlyAmount)}
                </p>
                <p className="text-slate-400">
                  {dateOnly(a.startDate)} → {a.endDate ? dateOnly(a.endDate) : "open"} · {a.currency}
                </p>
              </li>
            ))}
          </ul>
          <div className="border-t border-slate-100 p-4 dark:border-slate-800">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">Recent payments</p>
            <ul className="space-y-1 text-xs">
              {paymentRows.map((p) => (
                <li key={p.payment.id} className="flex items-center justify-between">
                  <span>
                    {p.company} · {p.invoiceNo ?? "unallocated"}
                  </span>
                  <span className="tabular-nums">
                    {money(p.payment.amount)} · {humanize(p.payment.method)}
                  </span>
                </li>
              ))}
              {!paymentRows.length ? <li className="text-slate-400">No payments recorded.</li> : null}
            </ul>
          </div>
        </Card>
      </div>
    </div>
  );
}
