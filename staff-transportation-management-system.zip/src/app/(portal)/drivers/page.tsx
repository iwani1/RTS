import { asc, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { companies, driverEarnings, driverShifts, drivers, feedback, trips, users, vehicles } from "@/db/schema";
import { ActionForm, InlineActionForm } from "@/components/action-form";
import { Card, EmptyState, Field, PageHeader, StatCard, StatusBadge, Table, Td } from "@/components/ui";
import { createDriverAction, updateDriverAction } from "@/app/actions/admin";
import { requireSection } from "@/lib/auth";
import { getDriverPerformance } from "@/lib/queries";
import { dateOnly, isoDaysFromNow, money, n, todayISO } from "@/lib/utils";

export const dynamic = "force-dynamic";

const DRIVER_STATUS = ["available", "on_trip", "off_duty", "unavailable"];

export default async function DriversPage() {
  await requireSection("drivers");

  const rows = await db
    .select({
      driver: drivers,
      vehicle: vehicles.registrationNo,
      email: users.email,
      trips: sql<number>`(select count(*) from trips t where t.driver_id = ${drivers.id})`,
      completed: sql<number>`(select count(*) from trips t where t.driver_id = ${drivers.id} and t.status = 'completed')`,
      incidents: sql<number>`(select count(*) from incidents i where i.driver_id = ${drivers.id})`,
      earnings: sql<string>`(select coalesce(sum(de.total), 0) from driver_earnings de where de.driver_id = ${drivers.id} and de.status <> 'paid')`,
      login: users.lastLoginAt,
    })
    .from(drivers)
    .leftJoin(vehicles, eq(vehicles.id, sql`(select v.id from vehicles v where v.assigned_driver_id = ${drivers.id} limit 1)`))
    .leftJoin(users, eq(users.id, drivers.userId))
    .orderBy(asc(drivers.fullName));

  const roster = await db
    .select({ shift: driverShifts, driver: drivers.fullName })
    .from(driverShifts)
    .innerJoin(drivers, eq(drivers.id, driverShifts.driverId))
    .where(eq(driverShifts.shiftDate, todayISO()))
    .orderBy(asc(driverShifts.startTime));

  const performance = await getDriverPerformance(8);
  const complaints = await db.select().from(feedback).where(eq(feedback.category, "complaint")).orderBy(desc(feedback.createdAt)).limit(5);
  const companyOptions = await db.select({ id: companies.id, name: companies.name }).from(companies);
  const licenseAlerts = rows.filter((r) => r.driver.licenseExpiry && r.driver.licenseExpiry <= isoDaysFromNow(60));

  const totalEarnings = rows.reduce((s, r) => s + n(r.earnings), 0);

  return (
    <div>
      <PageHeader title="Driver management" subtitle="Driver records, licences, availability, duty roster, performance and earnings." />

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Drivers" value={rows.length} icon="🧑‍✈️" hint={`${rows.filter((r) => r.driver.status === "available").length} available now`} />
        <StatCard label="On duty / on trip" value={rows.filter((r) => r.driver.status === "on_trip").length} tone="info" icon="🚏" />
        <StatCard label="Licence alerts (60d)" value={licenseAlerts.length} tone={licenseAlerts.length ? "warning" : "positive"} icon="📄" />
        <StatCard label="Accrued earnings" value={money(totalEarnings)} icon="💰" hint="Pending payroll approval" />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <Card title="Driver register" className="lg:col-span-2" padded={false}>
          <Table head={["Driver", "Licence", "Vehicle", "Trips", "Rating", "Earnings", "Status", ""]}>
            {rows.map((r) => (
              <tr key={r.driver.id}>
                <Td>
                  <p className="font-medium text-slate-800 dark:text-slate-200">{r.driver.fullName}</p>
                  <p className="text-xs text-slate-400">{r.driver.phone}</p>
                  <p className="text-xs text-slate-400">{r.email ?? "no portal account"}</p>
                </Td>
                <Td className="text-xs">
                  {r.driver.licenseNo}
                  <p className="text-slate-400">Class {r.driver.licenseClass ?? "—"}</p>
                  <p className={r.driver.licenseExpiry && r.driver.licenseExpiry <= isoDaysFromNow(60) ? "text-amber-600" : "text-slate-400"}>
                    Exp {dateOnly(r.driver.licenseExpiry)}
                  </p>
                </Td>
                <Td className="text-xs">{r.vehicle ?? "—"}</Td>
                <Td className="tabular-nums text-xs">
                  {Number(r.completed)}/{Number(r.trips)}
                  <p className="text-slate-400">{Number(r.incidents)} incidents</p>
                </Td>
                <Td className="tabular-nums text-xs">
                  {n(r.driver.ratingAvg).toFixed(1)} ★
                  <p className="text-slate-400">{r.driver.ratingCount ?? 0} ratings</p>
                </Td>
                <Td className="tabular-nums text-xs">{money(r.earnings)}</Td>
                <Td>
                  <StatusBadge status={r.driver.status} />
                </Td>
                <Td>
                  <InlineActionForm action={updateDriverAction} hiddenFields={{ id: r.driver.id }} submitLabel="Edit" variant="ghost" />
                </Td>
              </tr>
            ))}
          </Table>
          {!rows.length ? <div className="p-4"><EmptyState title="No drivers registered" /></div> : null}
        </Card>

        <div className="space-y-4">
          <Card title="Register a driver" subtitle="A driver app account is created when an email is supplied">
            <ActionForm action={createDriverAction} submitLabel="Register driver" resetOnSuccess>
              <div className="space-y-3">
                <Field label="Full name" name="fullName" required />
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Phone" name="phone" required placeholder="+233 24 000 0000" />
                  <Field label="Email" name="email" type="email" hint="Used for the driver app login." />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Licence number" name="licenseNo" required />
                  <Field label="Licence class" name="licenseClass" options={["B", "C", "D"].map((v) => ({ value: v, label: `Class ${v}` }))} />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Licence expiry" name="licenseExpiry" type="date" />
                  <Field label="Hired on" name="hiredAt" type="date" />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Base salary (GHS)" name="baseSalary" type="number" step="0.01" defaultValue={1400} />
                  <Field label="Trip allowance (GHS)" name="tripAllowance" type="number" step="0.01" defaultValue={35} />
                </div>
                <Field label="Emergency contact name" name="emergencyContactName" />
                <Field label="Emergency contact phone" name="emergencyContactPhone" />
                <Field label="Assigned company" name="companyId" options={[{ value: "", label: "Platform pool" }, ...companyOptions.map((c) => ({ value: String(c.id), label: c.name }))]} />
              </div>
            </ActionForm>
          </Card>

          <Card title="Update driver record">
            <ActionForm action={updateDriverAction} submitLabel="Save driver">
              <Field label="Driver" name="id" required options={rows.map((r) => ({ value: String(r.driver.id), label: r.driver.fullName }))} />
              <div className="mt-3 space-y-3">
                <Field label="Availability" name="status" options={DRIVER_STATUS.map((s) => ({ value: s, label: s.replace(/_/g, " ") }))} />
                <Field label="Licence expiry" name="licenseExpiry" type="date" />
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Base salary (GHS)" name="baseSalary" type="number" step="0.01" />
                  <Field label="Trip allowance (GHS)" name="tripAllowance" type="number" step="0.01" />
                </div>
                <Field label="Notes" name="notes" rows={2} />
              </div>
            </ActionForm>
          </Card>
        </div>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <Card title="Today's duty roster" className="lg:col-span-2" padded={false}>
          <Table head={["Driver", "Shift", "Window", "Status"]}>
            {roster.map((r) => (
              <tr key={r.shift.id}>
                <Td className="font-medium">{r.driver}</Td>
                <Td className="text-xs capitalize">{r.shift.label}</Td>
                <Td className="text-xs">
                  {r.shift.startTime} – {r.shift.endTime}
                </Td>
                <Td>
                  <StatusBadge status={r.shift.status} />
                </Td>
              </tr>
            ))}
          </Table>
          {!roster.length ? <div className="p-4"><EmptyState title="No roster entries for today" hint="Driver shifts are created when trips are planned or manually scheduled." /></div> : null}
        </Card>

        <Card title="Performance leaderboard" padded={false}>
          <Table head={["Driver", "Trips", "On time", "Rating"]}>
            {performance.map((p) => (
              <tr key={p.driverId}>
                <Td className="text-xs font-medium">{p.driver}</Td>
                <Td className="tabular-nums text-xs">{p.tripsCompleted}</Td>
                <Td className="tabular-nums text-xs">{p.tripsCompleted ? `${((p.onTime / p.tripsCompleted) * 100).toFixed(0)}%` : "—"}</Td>
                <Td className="tabular-nums text-xs">{n(p.rating).toFixed(1)} ★</Td>
              </tr>
            ))}
          </Table>
          <div className="border-t border-slate-100 p-3 dark:border-slate-800">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">Recent complaints</p>
            <ul className="space-y-1 text-xs text-slate-500">
              {complaints.map((c) => (
                <li key={c.id} className="truncate">
                  {c.rating ? `${c.rating}★ ` : ""}
                  {c.comments}
                </li>
              ))}
              {!complaints.length ? <li>No complaints on record.</li> : null}
            </ul>
          </div>
        </Card>
      </div>
    </div>
  );
}
