import Link from "next/link";
import { and, desc, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { bookings, companies, employees, incidents, trips, vehicles } from "@/db/schema";
import { BarChart, DonutStat, LineChart } from "@/components/charts";
import { LiveMap, type MapPoint } from "@/components/live-map";
import { Card, EmptyState, LinkButton, PageHeader, ProgressBar, StatCard, StatusBadge, Table, Td } from "@/components/ui";
import { requireSection } from "@/lib/auth";
import { companyScope } from "@/lib/auth";
import {
  getDocumentExpiries,
  getDriverPerformance,
  getKpis,
  getLatestPositions,
  getLiveTrips,
  getRevenueByCompany,
  getTripsPerDay,
} from "@/lib/queries";
import { dateOnly, money, n, timeOnly } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const user = await requireSection("dashboard");
  const scope = companyScope(user);

  const [kpis, perDay, revenue, driverPerf, live, expiries, upcoming] = await Promise.all([
    getKpis(scope),
    getTripsPerDay(scope, 14),
    getRevenueByCompany(),
    getDriverPerformance(6),
    getLiveTrips(scope),
    getDocumentExpiries(),
    db
      .select({
        trip: trips,
        company: companies.name,
        vehicle: vehicles.registrationNo,
      })
      .from(trips)
      .innerJoin(companies, eq(companies.id, trips.companyId))
      .leftJoin(vehicles, eq(vehicles.id, trips.vehicleId))
      .where(and(eq(trips.tripDate, new Date().toISOString().slice(0, 10)), scope ? eq(trips.companyId, scope) : undefined))
      .orderBy(trips.scheduledDeparture)
      .limit(8),
  ]);

  const positions = await getLatestPositions(live.map((l) => l.trip.id));
  const points: MapPoint[] = [];
  for (const l of live) {
    const pos = positions.find((p) => p.tripId === l.trip.id);
    if (!pos) continue;
    points.push({
      id: `t${l.trip.id}`,
      lat: pos.lat,
      lng: pos.lng,
      label: `${l.vehicle?.registrationNo ?? "unassigned"} · ${l.company.name}`,
      kind: "vehicle",
      tone: l.trip.status === "in_progress" ? "teal" : l.trip.status === "delayed" ? "amber" : "navy",
    });
  }

  const openIncidents = await db
    .select({ incident: incidents, company: companies.name })
    .from(incidents)
    .leftJoin(companies, eq(companies.id, incidents.companyId))
    .where(inArray(incidents.status, ["open", "acknowledged"]))
    .orderBy(desc(incidents.severity), desc(incidents.reportedAt))
    .limit(5);

  const [pendingBookings] = await db
    .select({ v: bookings.id })
    .from(bookings)
    .innerJoin(employees, eq(employees.id, bookings.employeeId))
    .where(and(eq(bookings.status, "pending"), scope ? eq(bookings.companyId, scope) : undefined))
    .limit(50);

  return (
    <div>
      <PageHeader
        title="Operations dashboard"
        subtitle={
          scope
            ? "Company scoped overview of your staff transportation programme."
            : "Platform wide view across every corporate client and the operating fleet."
        }
        actions={
          <>
            <LinkButton href="/dispatch">Open dispatch</LinkButton>
            <LinkButton href="/reports" variant="primary">
              Reports
            </LinkButton>
          </>
        }
      />

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Corporate clients" value={kpis.companies} icon="🏢" hint={`${kpis.employees} registered employees`} />
        <StatCard label="Trips today" value={kpis.tripsToday} icon="🚌" hint={`${kpis.completedTrips} completed all time`} />
        <StatCard label="Fleet utilisation" value={`${kpis.fleetUtilisation.toFixed(0)}%`} tone="info" icon="🚐" hint={`${kpis.activeVehicles}/${kpis.totalVehicles} vehicles engaged`} />
        <StatCard label="On-time pickup" value={`${kpis.onTimePct.toFixed(1)}%`} tone={kpis.onTimePct >= 95 ? "positive" : "warning"} icon="⏱️" hint={`Avg delay ${kpis.avgDelayMinutes} min`} />
        <StatCard label="Bookings" value={kpis.bookings} icon="🎫" hint={`${kpis.cancelledBookings} cancelled`} />
        <StatCard label="Revenue invoiced" value={money(kpis.revenue)} tone="positive" icon="💰" />
        <StatCard label="Outstanding" value={money(kpis.outstanding)} tone={kpis.outstanding > 0 ? "warning" : "positive"} icon="📉" />
        <StatCard label="Open incidents" value={kpis.openIncidents} tone={kpis.openIncidents > 0 ? "danger" : "positive"} icon="🚨" />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <Card title="Trips per day" subtitle="Last 14 days" className="lg:col-span-2">
          <LineChart
            labels={perDay.map((d) => d.day.slice(5))}
            series={[
              { name: "Trips operated", color: "#12355b", points: perDay.map((d) => d.total) },
              { name: "Completed", color: "#0d9488", points: perDay.map((d) => d.completed) },
              { name: "Passengers carried", color: "#d97706", points: perDay.map((d) => d.passengers) },
            ]}
          />
        </Card>
        <Card title="Service quality">
          <div className="space-y-4">
            <DonutStat value={kpis.onTimePct} label="Arrivals within the 10 minute grace window" />
            <div>
              <p className="mb-1 flex items-center justify-between text-xs text-slate-500">
                <span>Fleet utilisation</span>
                <span>{kpis.fleetUtilisation.toFixed(0)}%</span>
              </p>
              <ProgressBar value={kpis.fleetUtilisation} />
            </div>
            <div>
              <p className="mb-1 flex items-center justify-between text-xs text-slate-500">
                <span>Seats filled today</span>
                <span>
                  {upcoming.reduce((sum, t) => sum + t.trip.bookedSeats, 0)} / {upcoming.reduce((sum, t) => sum + t.trip.capacity, 0)}
                </span>
              </p>
              <ProgressBar
                tone="amber"
                value={
                  upcoming.reduce((sum, t) => sum + t.trip.capacity, 0)
                    ? (upcoming.reduce((sum, t) => sum + t.trip.bookedSeats, 0) /
                        upcoming.reduce((sum, t) => sum + t.trip.capacity, 0)) *
                      100
                    : 0
                }
              />
            </div>
            <div className="rounded-lg bg-slate-50 p-3 text-xs text-slate-600 dark:bg-slate-950 dark:text-slate-300">
              <p className="font-medium">Cost per passenger</p>
              <p className="mt-1 text-lg font-semibold text-navy-900 dark:text-white">{money(kpis.costPerPassenger)}</p>
              <p className="mt-1">Based on recorded maintenance spend against passengers carried.</p>
            </div>
          </div>
        </Card>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <Card title="Live fleet positions" subtitle="Vehicles on active duties" className="lg:col-span-2">
          {points.length ? (
            <LiveMap initial={points} pollUrl="/api/dispatch/live" />
          ) : (
            <EmptyState title="No active GPS positions" hint="Positions appear once a driver starts a trip from the driver app." />
          )}
        </Card>
        <Card title="Operational alerts">
          <ul className="space-y-2 text-sm">
            {pendingBookings ? (
              <li className="rounded-lg border border-amber-200 bg-amber-50 p-3 text-xs text-amber-800 dark:border-amber-800 dark:bg-amber-950/40 dark:text-amber-200">
                <Link href="/bookings" className="font-semibold underline">
                  Pending booking requests
                </Link>{" "}
                need approval before tonight&apos;s planning run.
              </li>
            ) : null}
            {expiries.vehicleDocs.slice(0, 3).map((v) => (
              <li key={`v${v.id}`} className="rounded-lg border border-slate-200 p-3 text-xs dark:border-slate-800">
                <span className="font-semibold">{v.label}</span> — insurance {dateOnly(v.insurance)}, roadworthiness{" "}
                {dateOnly(v.roadworthy)}
              </li>
            ))}
            {expiries.driverDocs.slice(0, 2).map((d) => (
              <li key={`d${d.id}`} className="rounded-lg border border-slate-200 p-3 text-xs dark:border-slate-800">
                <span className="font-semibold">{d.label}</span> — licence expires {dateOnly(d.license)}
              </li>
            ))}
            {openIncidents.length === 0 && !expiries.vehicleDocs.length ? (
              <li className="text-xs text-slate-400">No open alerts. All documents valid and no live incidents.</li>
            ) : null}
          </ul>
        </Card>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <Card title="Today's departures" padded={false}>
          <Table head={["Trip", "Company", "Depart", "Vehicle", "Seats", "Status"]}>
            {upcoming.map((row) => (
              <tr key={row.trip.id}>
                <Td>
                  <Link href={`/trips/${row.trip.id}`} className="font-medium text-teal-700 hover:underline dark:text-teal-400">
                    {row.trip.reference}
                  </Link>
                </Td>
                <Td className="text-xs">{row.company}</Td>
                <Td>{timeOnly(row.trip.scheduledDeparture)}</Td>
                <Td className="text-xs">{row.vehicle ?? "—"}</Td>
                <Td className="tabular-nums">
                  {row.trip.bookedSeats}/{row.trip.capacity}
                </Td>
                <Td>
                  <StatusBadge status={row.trip.status} />
                </Td>
              </tr>
            ))}
          </Table>
          {!upcoming.length ? <div className="p-4"><EmptyState title="No trips scheduled for today" hint="Create one from the Trips module." /></div> : null}
        </Card>

        <Card title="Revenue by corporate client" subtitle="Invoiced vs collected (GHS)">
          <BarChart data={revenue.map((r) => ({ label: r.company.split(" ")[0], invoiced: r.total, collected: r.paid }))} valueKey="invoiced" />
          <Table head={["Client", "Invoiced", "Collected", "Outstanding"]}>
            {revenue.map((r) => (
              <tr key={r.companyId}>
                <Td className="text-xs">{r.company}</Td>
                <Td className="tabular-nums">{money(r.total)}</Td>
                <Td className="tabular-nums">{money(r.paid)}</Td>
                <Td className="tabular-nums">{money(r.total - r.paid)}</Td>
              </tr>
            ))}
          </Table>
        </Card>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <Card title="Driver performance" subtitle="Completed trips and punctuality" padded={false}>
          <Table head={["Driver", "Trips", "On time", "Passengers", "Rating"]}>
            {driverPerf.map((d) => (
              <tr key={d.driverId}>
                <Td className="font-medium">{d.driver ?? "—"}</Td>
                <Td className="tabular-nums">{d.tripsCompleted}</Td>
                <Td className="tabular-nums">{d.tripsCompleted ? `${((d.onTime / d.tripsCompleted) * 100).toFixed(0)}%` : "—"}</Td>
                <Td className="tabular-nums">{d.passengers}</Td>
                <Td className="tabular-nums">{n(d.rating).toFixed(1)} ★</Td>
              </tr>
            ))}
          </Table>
          {!driverPerf.length ? <div className="p-4"><EmptyState title="No completed trips yet" /></div> : null}
        </Card>

        <Card title="Incident feed" subtitle="Open and acknowledged cases" padded={false}>
          <Table head={["Type", "Severity", "Client", "Status", "Reported"]}>
            {openIncidents.map((i) => (
              <tr key={i.incident.id}>
                <Td className="font-medium">{i.incident.type.replace("_", " ")}</Td>
                <Td>
                  <StatusBadge status={i.incident.severity} />
                </Td>
                <Td className="text-xs">{i.company ?? "Platform"}</Td>
                <Td>
                  <StatusBadge status={i.incident.status} />
                </Td>
                <Td className="text-xs">{dateOnly(i.incident.reportedAt)}</Td>
              </tr>
            ))}
          </Table>
          {!openIncidents.length ? <div className="p-4"><EmptyState title="No open incidents" /></div> : null}
        </Card>
      </div>
    </div>
  );
}
