import Link from "next/link";
import { ActionForm } from "@/components/action-form";
import { Card, Field } from "@/components/ui";
import { registerAction } from "@/app/actions/auth";

export const dynamic = "force-dynamic";

export default function RegisterPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-navy-900 dark:text-white">Create your account</h1>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
          Employees whose work email is already registered by their HR team are activated instantly.
        </p>
      </div>
      <Card title="Employee self registration">
        <ActionForm action={registerAction} submitLabel="Register" resetOnSuccess>
          <div className="space-y-3">
            <Field label="Full name" name="fullName" required placeholder="Ama Serwaa" />
            <Field label="Work email" name="email" type="email" required placeholder="ama@sikamanfinancial.com" />
            <Field label="Mobile number" name="phone" placeholder="+233 24 000 0000" />
            <Field label="Password" name="password" type="password" required hint="Minimum 8 characters." />
          </div>
        </ActionForm>
      </Card>
      <p className="text-xs text-slate-500">
        Already registered?{" "}
        <Link href="/login" className="font-medium text-teal-700 hover:underline dark:text-teal-400">
          Sign in
        </Link>
      </p>
    </div>
  );
}
