import Link from "next/link";
import { ActionForm } from "@/components/action-form";
import { Card, Field } from "@/components/ui";
import { requestPasswordResetAction } from "@/app/actions/auth";

export const dynamic = "force-dynamic";

export default function ForgotPasswordPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-navy-900 dark:text-white">Recover access</h1>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
          We generate a one hour reset link. No email provider is configured in this environment, so the link is shown
          on screen instead of being emailed.
        </p>
      </div>
      <Card title="Request password reset">
        <ActionForm action={requestPasswordResetAction} submitLabel="Generate reset link" resetOnSuccess>
          <Field label="Account email" name="email" type="email" required placeholder="you@company.com" />
        </ActionForm>
      </Card>
      <p className="text-xs text-slate-500">
        <Link href="/login" className="font-medium text-teal-700 hover:underline dark:text-teal-400">
          Back to sign in
        </Link>
      </p>
    </div>
  );
}
