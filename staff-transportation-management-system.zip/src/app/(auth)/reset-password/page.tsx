import Link from "next/link";
import { ActionForm } from "@/components/action-form";
import { Card, Field } from "@/components/ui";
import { resetPasswordAction } from "@/app/actions/auth";

export const dynamic = "force-dynamic";

export default async function ResetPasswordPage({
  searchParams,
}: {
  searchParams: Promise<{ token?: string }>;
}) {
  const { token } = await searchParams;
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-navy-900 dark:text-white">Set a new password</h1>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">Paste the reset token and choose a new password.</p>
      </div>
      <Card title="Password reset">
        <ActionForm action={resetPasswordAction} submitLabel="Update password">
          <div className="space-y-3">
            <Field label="Reset token" name="token" required defaultValue={token ?? ""} />
            <Field label="New password" name="password" type="password" required hint="Minimum 8 characters." />
          </div>
        </ActionForm>
      </Card>
      <p className="text-xs text-slate-500">
        <Link href="/login" className="font-medium text-teal-700 hover:underline dark:text-teal-400">
          Back to sign in
        </Link>
      </p>
    </div>
  );
}
