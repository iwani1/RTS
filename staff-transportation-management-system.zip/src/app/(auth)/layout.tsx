import type { ReactNode } from "react";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

export default async function AuthLayout({ children }: { children: ReactNode }) {
  // Seeds the demonstration dataset the first time the app is opened.
  try {
    await ensureSeeded();
  } catch {
    /* database may not be migrated yet - the login page still renders */
  }
  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="hidden flex-col justify-between bg-navy-900 p-10 text-navy-100 lg:flex">
        <div className="flex items-center gap-2">
          <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-teal-500 font-bold text-navy-950">SR</span>
          <div>
            <p className="font-semibold text-white">StaffRide TMS</p>
            <p className="text-xs text-navy-300">Staff Transportation Management</p>
          </div>
        </div>
        <div className="space-y-6">
          <h2 className="max-w-md text-3xl font-semibold leading-tight text-white">
            One platform for corporate staff transport — bookings, routing, dispatch, fleet, safety and billing.
          </h2>
          <ul className="space-y-2 text-sm text-navy-200">
            {[
              "Role based portals for operations, HR, drivers and employees",
              "Capacity aware route planning with pickup time windows",
              "Live dispatch board with boarding OTP verification",
              "Corporate invoicing in GHS with driver payroll exports",
            ].map((f) => (
              <li key={f} className="flex items-start gap-2">
                <span className="mt-1 text-teal-400">▸</span>
                {f}
              </li>
            ))}
          </ul>
        </div>
        <p className="text-xs text-navy-400">Greater Accra · Ghana · GHS</p>
      </div>
      <div className="flex items-center justify-center p-6">
        <div className="w-full max-w-md">{children}</div>
      </div>
    </div>
  );
}
