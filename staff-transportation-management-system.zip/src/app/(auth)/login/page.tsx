import Link from "next/link";
import { redirect } from "next/navigation";
import { ActionForm } from "@/components/action-form";
import { Field, Card } from "@/components/ui";
import { loginAction } from "@/app/actions/auth";
import { getSessionUser, homeFor } from "@/lib/auth";
import type { Role } from "@/lib/rbac";

export const dynamic = "force-dynamic";

const DEMO = [
  ["Super Administrator", "admin@staffridegh.com", "2FA code 246810"],
  ["Operations Manager", "ops@staffridegh.com", "—"],
  ["Dispatcher", "dispatch@staffridegh.com", "—"],
  ["Fleet Manager", "fleet@staffridegh.com", "—"],
  ["Finance Officer", "finance@staffridegh.com", "—"],
  ["Corporate HR (Sikaman)", "hr@sikamanfinancial.com", "—"],
  ["Employee (Sikaman)", "ama@sikamanfinancial.com", "—"],
  ["Driver (Kwesi)", "driver.kwesi@staffridegh.com", "—"],
];

export default async function LoginPage() {
  const user = await getSessionUser();
  if (user) redirect(homeFor(user.role as Role));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-navy-900 dark:text-white">Sign in</h1>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
          Secure access to the StaffRide transportation platform.
        </p>
      </div>

      <Card title="Account login">
        <ActionForm action={loginAction} submitLabel="Sign in" resetOnSuccess>
          <div className="space-y-3">
            <Field label="Email address" name="email" type="email" required placeholder="you@company.com" />
            <Field label="Password" name="password" type="password" required placeholder="••••••••" />
            <Field
              label="Two-factor code (privileged accounts only)"
              name="code"
              placeholder="123456"
              hint="Only required for accounts with 2FA enabled."
            />
          </div>
        </ActionForm>
        <div className="mt-4 flex justify-between text-xs">
          <Link href="/forgot-password" className="font-medium text-teal-700 hover:underline dark:text-teal-400">
            Forgot password?
          </Link>
          <Link href="/register" className="font-medium text-teal-700 hover:underline dark:text-teal-400">
            Create an account
          </Link>
        </div>
      </Card>

      <Card title="Demonstration accounts" subtitle="Password for all demo users: Password123!">
        <ul className="divide-y divide-slate-100 text-xs dark:divide-slate-800">
          {DEMO.map(([role, email, note]) => (
            <li key={email} className="flex flex-wrap items-center justify-between gap-2 py-2">
              <span className="font-medium text-slate-700 dark:text-slate-200">{role}</span>
              <span className="flex items-center gap-2">
                <code className="rounded bg-slate-100 px-1.5 py-0.5 dark:bg-slate-800">{email}</code>
                {note !== "—" ? <span className="text-amber-600 dark:text-amber-400">{note}</span> : null}
              </span>
            </li>
          ))}
        </ul>
      </Card>
    </div>
  );
}
