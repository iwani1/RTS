"use server";

import { revalidatePath } from "next/cache";
import { and, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  branches,
  companies,
  driverEarnings,
  drivers,
  employees,
  invoiceLines,
  invoices,
  maintenanceRecords,
  payments,
  routeStops,
  routes,
  serviceAgreements,
  shifts,
  stops,
  users,
  vehicles,
} from "@/db/schema";
import type { ActionState } from "@/components/action-form";
import { hashPassword, logAudit, requireUser, type SessionUser } from "@/lib/auth";
import { can, type Role } from "@/lib/rbac";
import { generateToken, parseCsvSafe } from "@/lib/csv-helpers";
import { ref } from "@/lib/utils";

async function guard(permission: Parameters<typeof can>[1], user?: SessionUser) {
  const current = user ?? (await requireUser());
  if (!can(current.role as Role, permission)) {
    throw new Error("You do not have permission to perform this action.");
  }
  return current;
}

const str = (fd: FormData, key: string) => String(fd.get(key) ?? "").trim();
const num = (fd: FormData, key: string) => {
  const raw = str(fd, key);
  return raw === "" ? null : Number(raw);
};
const dec = (fd: FormData, key: string) => {
  const raw = str(fd, key);
  return raw === "" ? null : String(Number(raw));
};

/* ------------------------------------------------------------- companies */

export async function createCompanyAction(_p: ActionState, fd: FormData): Promise<ActionState> {
  const user = await guard("company.manage");
  const name = str(fd, "name");
  if (!name) return { ok: false, message: "Company name is required." };
  const [created] = await db
    .insert(companies)
    .values({
      name,
      contactPerson: str(fd, "contactPerson") || null,
      email: str(fd, "email") || null,
      phone: str(fd, "phone") || null,
      industry: str(fd, "industry") || null,
      city: str(fd, "city") || null,
      billingModel: (str(fd, "billingModel") || "per_passenger") as "per_passenger",
      monthlyRate: dec(fd, "monthlyRate") ?? "0",
    })
    .returning({ id: companies.id });
  await logAudit({ user, action: "company.create", entity: "company", entityId: created.id, companyId: created.id });
  revalidatePath("/companies");
  return { ok: true, message: `${name} registered as a corporate client.` };
}

export async function updateCompanyAction(_p: ActionState, fd: FormData): Promise<ActionState> {
  const user = await guard("company.manage");
  const id = num(fd, "id");
  if (!id) return { ok: false, message: "Missing company." };
  await db
    .update(companies)
    .set({
      status: str(fd, "status") as "active",
      billingModel: (str(fd, "billingModel") || undefined) as "per_passenger" | undefined,
      monthlyRate: dec(fd, "monthlyRate") ?? undefined,
      notes: str(fd, "notes") || null,
      updatedAt: new Date(),
    })
    .where(eq(companies.id, id));
  await logAudit({ user, action: "company.update", entity: "company", entityId: id, companyId: id });
  revalidatePath("/companies");
  revalidatePath(`/companies/${id}`);
  return { ok: true, message: "Company profile updated." };
}

export async function createBranchAction(_p: ActionState, fd: FormData): Promise<ActionState> {
  const user = await guard("company.manage");
  const companyId = num(fd, "companyId");
  const name = str(fd, "name");
  if (!companyId || !name) return { ok: false, message: "Company and branch name are required." };
  const [created] = await db
    .insert(branches)
    .values({
      companyId,
      name,
      address: str(fd, "address") || null,
      city: str(fd, "city") || null,
      lat: num(fd, "lat"),
      lng: num(fd, "lng"),
      isHeadquarters: str(fd, "isHeadquarters") === "on",
    })
    .returning({ id: branches.id });
  await logAudit({ user, action: "branch.create", entity: "branch", entityId: created.id, companyId });
  revalidatePath(`/companies/${companyId}`);
  return { ok: true, message: `Branch ${name} added.` };
}

export async function createAgreementAction(_p: ActionState, fd: FormData): Promise<ActionState> {
  const user = await guard("company.manage");
  const companyId = num(fd, "companyId");
  const name = str(fd, "name");
  if (!companyId || !name) return { ok: false, message: "Company and agreement name are required." };
  const [created] = await db
    .insert(serviceAgreements)
    .values({
      companyId,
      name,
      pricingModel: (str(fd, "pricingModel") || "per_passenger") as "per_passenger",
      unitRate: dec(fd, "unitRate") ?? "0",
      fixedMonthlyAmount: dec(fd, "fixedMonthlyAmount") ?? "0",
      startDate: str(fd, "startDate") || new Date().toISOString().slice(0, 10),
      endDate: str(fd, "endDate") || null,
      slaOnTimePercent: num(fd, "slaOnTimePercent") ?? 95,
      slaResponseMinutes: num(fd, "slaResponseMinutes") ?? 15,
      maxPickupDeviationMinutes: num(fd, "maxPickupDeviationMinutes") ?? 10,
      cancellationPolicyHours: num(fd, "cancellationPolicyHours") ?? 2,
      notes: str(fd, "notes") || null,
    })
    .returning({ id: serviceAgreements.id });
  await logAudit({ user, action: "agreement.create", entity: "service_agreement", entityId: created.id, companyId });
  revalidatePath(`/companies/${companyId}`);
  return { ok: true, message: "Service agreement saved." };
}

/* ------------------------------------------------------------- employees */

export async function createEmployeeAction(_p: ActionState, fd: FormData): Promise<ActionState> {
  const user = await requireUser();
  const scopeCompanyId = user.role === "corporate_admin" ? user.companyId : num(fd, "companyId");
  if (!scopeCompanyId) return { ok: false, message: "Select the company this employee belongs to." };
  if (user.role === "corporate_admin" && user.companyId !== scopeCompanyId) {
    return { ok: false, message: "You can only register employees for your own company." };
  }
  if (user.role !== "corporate_admin" && !can(user.role as Role, "employee.manage")) {
    return { ok: false, message: "Not permitted." };
  }
  const fullName = str(fd, "fullName");
  const employeeCode = str(fd, "employeeCode") || ref("EMP");
  if (!fullName) return { ok: false, message: "Employee name is required." };

  try {
    const [created] = await db
      .insert(employees)
      .values({
        companyId: scopeCompanyId,
        branchId: num(fd, "branchId"),
        shiftId: num(fd, "shiftId"),
        employeeCode,
        fullName,
        email: str(fd, "email") || null,
        phone: str(fd, "phone") || null,
        department: str(fd, "department") || null,
        jobTitle: str(fd, "jobTitle") || null,
        homeAddress: str(fd, "homeAddress") || null,
        homeLat: num(fd, "homeLat"),
        homeLng: num(fd, "homeLng"),
        zone: str(fd, "zone") || null,
        vip: str(fd, "vip") === "on",
      })
      .returning({ id: employees.id });
    await logAudit({ user, action: "employee.create", entity: "employee", entityId: created.id, companyId: scopeCompanyId });
    revalidatePath("/employees");
    return { ok: true, message: `${fullName} registered with code ${employeeCode}.` };
  } catch (error) {
    return { ok: false, message: `Could not save employee: ${(error as Error).message}` };
  }
}

export async function importEmployeesAction(_p: ActionState, fd: FormData): Promise<ActionState> {
  const user = await requireUser();
  const companyId = user.role === "corporate_admin" ? user.companyId : num(fd, "companyId");
  if (!companyId) return { ok: false, message: "Select a company for the import." };
  if (user.role !== "corporate_admin" && !can(user.role as Role, "employee.manage")) {
    return { ok: false, message: "Not permitted." };
  }
  const csv = String(fd.get("csv") ?? "");
  const rows = parseCsvSafe(csv);
  if (!rows.length) return { ok: false, message: "No data rows found. Expected a header row plus at least one employee." };

  let inserted = 0;
  const errors: string[] = [];
  for (const row of rows) {
    const fullName = row["full_name"] || row["name"];
    if (!fullName) {
      errors.push("A row is missing full_name");
      continue;
    }
    try {
      await db.insert(employees).values({
        companyId,
        branchId: num(fd, "branchId"),
        employeeCode: row["employee_code"] || ref("EMP"),
        fullName,
        email: row["email"] || null,
        phone: row["phone"] || null,
        department: row["department"] || null,
        jobTitle: row["job_title"] || null,
        homeAddress: row["home_address"] || null,
        zone: row["zone"] || null,
        homeLat: row["home_lat"] ? Number(row["home_lat"]) : null,
        homeLng: row["home_lng"] ? Number(row["home_lng"]) : null,
      });
      inserted += 1;
    } catch (error) {
      errors.push(`${fullName}: ${(error as Error).message}`);
    }
  }
  await logAudit({ user, action: "employee.import", entity: "employee", companyId, details: { inserted, failed: errors.length } });
  revalidatePath("/employees");
  return {
    ok: inserted > 0,
    message: `Imported ${inserted} employee record(s).${errors.length ? ` ${errors.length} row(s) skipped: ${errors.slice(0, 3).join("; ")}` : ""}`,
  };
}

export async function toggleEmployeeAction(_p: ActionState, fd: FormData): Promise<ActionState> {
  const user = await guard("employee.manage");
  const id = num(fd, "id");
  const active = str(fd, "active") === "true";
  if (!id) return { ok: false, message: "Missing employee." };
  await db.update(employees).set({ active }).where(eq(employees.id, id));
  await logAudit({ user, action: active ? "employee.activate" : "employee.deactivate", entity: "employee", entityId: id });
  revalidatePath("/employees");
  return { ok: true, message: `Employee ${active ? "activated" : "deactivated"}.` };
}

export async function createShiftAction(_p: ActionState, fd: FormData): Promise<ActionState> {
  const user = await guard("employee.manage");
  const companyId = user.role === "corporate_admin" ? user.companyId : num(fd, "companyId");
  const name = str(fd, "name");
  const startTime = str(fd, "startTime");
  const endTime = str(fd, "endTime");
  if (!companyId || !name || !startTime || !endTime) return { ok: false, message: "Company, shift name, start and end time are required." };
  const [created] = await db
    .insert(shifts)
    .values({ companyId, branchId: num(fd, "branchId"), name, startTime, endTime, graceMinutes: num(fd, "graceMinutes") ?? 15 })
    .returning({ id: shifts.id });
  await logAudit({ user, action: "shift.create", entity: "employee_shift", entityId: created.id, companyId });
  revalidatePath("/employees");
  return { ok: true, message: `Shift ${name} configured.` };
}

export async function assignEmployeeShiftAction(_p: ActionState, fd: FormData): Promise<ActionState> {
  const user = await guard("employee.manage");
  const id = num(fd, "id");
  const shiftId = num(fd, "shiftId");
  if (!id || !shiftId) return { ok: false, message: "Employee and shift are required." };
  await db.update(employees).set({ shiftId }).where(eq(employees.id, id));
  await logAudit({ user, action: "employee.assign_shift", entity: "employee", entityId: id, details: { shiftId } });
  revalidatePath("/employees");
  return { ok: true, message: "Shift assigned." };
}

/* ------------------------------------------------------------------ fleet */

export async function createVehicleAction(_p: ActionState, fd: FormData): Promise<ActionState> {
  const user = await guard("vehicle.manage");
  const registrationNo = str(fd, "registrationNo");
  const make = str(fd, "make");
  const capacity = num(fd, "capacity");
  if (!registrationNo || !make || !capacity) return { ok: false, message: "Registration number, make and capacity are required." };
  try {
    const [created] = await db
      .insert(vehicles)
      .values({
        registrationNo,
        make,
        model: str(fd, "model") || make,
        year: num(fd, "year"),
        capacity,
        vehicleType: str(fd, "vehicleType") || "minibus",
        fuelType: str(fd, "fuelType") || "diesel",
        ownership: str(fd, "ownership") || "owned",
        assignedCompanyId: num(fd, "assignedCompanyId"),
        assignedDriverId: num(fd, "assignedDriverId"),
        odometerKm: num(fd, "odometerKm") ?? 0,
        avgKmPerLitre: num(fd, "avgKmPerLitre"),
        insuranceExpiry: str(fd, "insuranceExpiry") || null,
        roadworthinessExpiry: str(fd, "roadworthinessExpiry") || null,
        registrationExpiry: str(fd, "registrationExpiry") || null,
        costPerKm: dec(fd, "costPerKm") ?? "0",
        photoUrl: str(fd, "photoUrl") || null,
        status: "available",
      })
      .returning({ id: vehicles.id });
    await logAudit({ user, action: "vehicle.create", entity: "vehicle", entityId: created.id });
    revalidatePath("/fleet");
    return { ok: true, message: `Vehicle ${registrationNo} added to the fleet.` };
  } catch (error) {
    return { ok: false, message: `Could not add vehicle: ${(error as Error).message}` };
  }
}

export async function updateVehicleAction(_p: ActionState, fd: FormData): Promise<ActionState> {
  const user = await guard("vehicle.manage");
  const id = num(fd, "id");
  if (!id) return { ok: false, message: "Missing vehicle." };
  await db
    .update(vehicles)
    .set({
      status: str(fd, "status") as "available",
      odometerKm: num(fd, "odometerKm") ?? undefined,
      insuranceExpiry: str(fd, "insuranceExpiry") || null,
      roadworthinessExpiry: str(fd, "roadworthinessExpiry") || null,
      registrationExpiry: str(fd, "registrationExpiry") || null,
      assignedCompanyId: num(fd, "assignedCompanyId"),
      notes: str(fd, "notes") || null,
    })
    .where(eq(vehicles.id, id));
  await logAudit({ user, action: "vehicle.update", entity: "vehicle", entityId: id, details: { status: str(fd, "status") } });
  revalidatePath("/fleet");
  return { ok: true, message: "Vehicle record updated." };
}

export async function scheduleMaintenanceAction(_p: ActionState, fd: FormData): Promise<ActionState> {
  const user = await guard("vehicle.manage");
  const vehicleId = num(fd, "vehicleId");
  const description = str(fd, "description");
  const serviceDate = str(fd, "serviceDate");
  if (!vehicleId || !description || !serviceDate) return { ok: false, message: "Vehicle, description and service date are required." };
  const type = str(fd, "type") || "preventive";
  const [created] = await db
    .insert(maintenanceRecords)
    .values({
      vehicleId,
      type,
      description,
      cost: dec(fd, "cost") ?? "0",
      odometerKm: num(fd, "odometerKm"),
      serviceDate,
      nextServiceDate: str(fd, "nextServiceDate") || null,
      garageName: str(fd, "garageName") || null,
      status: type === "preventive" ? "completed" : "in_progress",
    })
    .returning({ id: maintenanceRecords.id });
  if (str(fd, "takeOffline") === "on") {
    await db.update(vehicles).set({ status: "under_maintenance" }).where(eq(vehicles.id, vehicleId));
  }
  await logAudit({ user, action: "maintenance.create", entity: "vehicle", entityId: vehicleId, details: { recordId: created.id, type } });
  revalidatePath("/fleet");
  return { ok: true, message: "Maintenance record captured." };
}

/* ---------------------------------------------------------------- drivers */

export async function createDriverAction(_p: ActionState, fd: FormData): Promise<ActionState> {
  const user = await guard("driver.manage");
  const fullName = str(fd, "fullName");
  const phone = str(fd, "phone");
  const licenseNo = str(fd, "licenseNo");
  if (!fullName || !phone || !licenseNo) return { ok: false, message: "Name, phone and licence number are required." };
  const email = str(fd, "email") || null;
  let userId: number | null = null;
  const tempPassword = `Ride-${generateToken(3)}`;
  if (email) {
    const [existing] = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
    userId =
      existing?.id ??
      (
        await db
          .insert(users)
          .values({
            email,
            fullName,
            phone,
            passwordHash: hashPassword(tempPassword),
            role: "driver",
            status: "active",
            invitedById: user.id,
          })
          .returning({ id: users.id })
      )[0].id;
  }
  const [created] = await db
    .insert(drivers)
    .values({
      userId,
      companyId: num(fd, "companyId"),
      fullName,
      phone,
      email,
      licenseNo,
      licenseClass: str(fd, "licenseClass") || null,
      licenseExpiry: str(fd, "licenseExpiry") || null,
      baseSalary: dec(fd, "baseSalary") ?? "0",
      tripAllowance: dec(fd, "tripAllowance") ?? "0",
      emergencyContactName: str(fd, "emergencyContactName") || null,
      emergencyContactPhone: str(fd, "emergencyContactPhone") || null,
      hiredAt: str(fd, "hiredAt") || null,
      status: "available",
    })
    .returning({ id: drivers.id });
  await logAudit({ user, action: "driver.create", entity: "driver", entityId: created.id, details: { accountCreated: Boolean(email) } });
  revalidatePath("/drivers");
  return {
    ok: true,
    message: email
      ? `Driver registered. Login ${email} with temporary password ${tempPassword} (share securely and require a change on first login).`
      : "Driver registered without a portal account.",
  };
}

export async function updateDriverAction(_p: ActionState, fd: FormData): Promise<ActionState> {
  const user = await guard("driver.manage");
  const id = num(fd, "id");
  if (!id) return { ok: false, message: "Missing driver." };
  await db
    .update(drivers)
    .set({
      status: str(fd, "status") as "available",
      licenseExpiry: str(fd, "licenseExpiry") || null,
      baseSalary: dec(fd, "baseSalary") ?? undefined,
      tripAllowance: dec(fd, "tripAllowance") ?? undefined,
      notes: str(fd, "notes") || null,
    })
    .where(eq(drivers.id, id));
  await logAudit({ user, action: "driver.update", entity: "driver", entityId: id });
  revalidatePath("/drivers");
  return { ok: true, message: "Driver record updated." };
}

/* --------------------------------------------------------- routes & stops */

export async function createStopAction(_p: ActionState, fd: FormData): Promise<ActionState> {
  const user = await guard("route.manage");
  const companyId = user.role === "corporate_admin" ? user.companyId : num(fd, "companyId");
  const name = str(fd, "name");
  if (!companyId || !name) return { ok: false, message: "Company and stop name are required." };
  const [created] = await db
    .insert(stops)
    .values({
      companyId,
      name,
      zone: str(fd, "zone") || null,
      address: str(fd, "address") || null,
      lat: num(fd, "lat"),
      lng: num(fd, "lng"),
    })
    .returning({ id: stops.id });
  await logAudit({ user, action: "stop.create", entity: "stop", entityId: created.id, companyId });
  revalidatePath("/routes");
  return { ok: true, message: `Stop ${name} created.` };
}

export async function createRouteAction(_p: ActionState, fd: FormData): Promise<ActionState> {
  const user = await guard("route.manage");
  const companyId = user.role === "corporate_admin" ? user.companyId : num(fd, "companyId");
  const name = str(fd, "name");
  if (!companyId || !name) return { ok: false, message: "Company and route name are required." };
  const stopIds = fd.getAll("stopIds").map((v) => Number(v)).filter(Boolean);
  const [created] = await db
    .insert(routes)
    .values({
      companyId,
      branchId: num(fd, "branchId"),
      name,
      direction: (str(fd, "direction") || "home_to_office") as "home_to_office",
      zone: str(fd, "zone") || null,
      estimatedKm: num(fd, "estimatedKm") ?? 0,
      estimatedMinutes: num(fd, "estimatedMinutes") ?? 0,
    })
    .returning({ id: routes.id });
  if (stopIds.length) {
    await db.insert(routeStops).values(
      stopIds.map((stopId, index) => ({ routeId: created.id, stopId, sequence: index + 1, offsetMinutes: index * 8 })),
    );
  }
  await logAudit({ user, action: "route.create", entity: "route", entityId: created.id, companyId, details: { stops: stopIds.length } });
  revalidatePath("/routes");
  return { ok: true, message: `Route ${name} created with ${stopIds.length} stop(s).` };
}

export async function toggleRouteAction(_p: ActionState, fd: FormData): Promise<ActionState> {
  const user = await guard("route.manage");
  const id = num(fd, "id");
  if (!id) return { ok: false, message: "Missing route." };
  const active = str(fd, "active") === "true";
  await db.update(routes).set({ active }).where(eq(routes.id, id));
  await logAudit({ user, action: active ? "route.activate" : "route.deactivate", entity: "route", entityId: id });
  revalidatePath("/routes");
  return { ok: true, message: `Route ${active ? "activated" : "deactivated"}.` };
}

/* ------------------------------------------------------------------- users */

export async function inviteUserAction(_p: ActionState, fd: FormData): Promise<ActionState> {
  const user = await guard("user.manage");
  const email = str(fd, "email").toLowerCase();
  const fullName = str(fd, "fullName");
  const role = str(fd, "role") as Role;
  if (!email || !fullName || !role) return { ok: false, message: "Name, email and role are required." };
  const tempPassword = `Ride-${generateToken(3)}`;
  try {
    const [created] = await db
      .insert(users)
      .values({
        email,
        fullName,
        phone: str(fd, "phone") || null,
        passwordHash: hashPassword(tempPassword),
        role,
        status: "active",
        companyId: num(fd, "companyId"),
        invitedById: user.id,
        twoFactorEnabled: ["super_admin", "ops_manager", "finance_officer"].includes(role),
        twoFactorCode: ["super_admin", "ops_manager", "finance_officer"].includes(role) ? String(100000 + Math.floor(Math.random() * 899999)) : null,
      })
      .returning({ id: users.id });
    await logAudit({ user, action: "user.invite", entity: "user", entityId: created.id, details: { role } });
    revalidatePath("/settings");
    return { ok: true, message: `Invitation created. Temporary password: ${tempPassword}` };
  } catch (error) {
    return { ok: false, message: `Could not create user: ${(error as Error).message}` };
  }
}

export async function updateUserStatusAction(_p: ActionState, fd: FormData): Promise<ActionState> {
  const user = await guard("user.manage");
  const id = num(fd, "id");
  const status = str(fd, "status");
  if (!id || !status) return { ok: false, message: "Missing user or status." };
  if (id === user.id) return { ok: false, message: "You cannot change your own account status." };
  await db.update(users).set({ status: status as "active" }).where(eq(users.id, id));
  await logAudit({ user, action: "user.status", entity: "user", entityId: id, details: { status } });
  revalidatePath("/settings");
  return { ok: true, message: `Account set to ${status}.` };
}

/* ---------------------------------------------------------------- finance */

export async function generateInvoiceAction(_p: ActionState, fd: FormData): Promise<ActionState> {
  const user = await guard("finance.manage");
  const companyId = num(fd, "companyId");
  if (!companyId) return { ok: false, message: "Select a company." };
  const periodStart = str(fd, "periodStart");
  const periodEnd = str(fd, "periodEnd");
  if (!periodStart || !periodEnd) return { ok: false, message: "Billing period is required." };

  const [company] = await db.select().from(companies).where(eq(companies.id, companyId)).limit(1);
  if (!company) return { ok: false, message: "Company not found." };

  const [agreement] = await db
    .select()
    .from(serviceAgreements)
    .where(eq(serviceAgreements.companyId, companyId))
    .orderBy(desc(serviceAgreements.id))
    .limit(1);

  const stats = await db.execute(sql`
    select
      count(*)::int as trips,
      coalesce(sum(booked_seats), 0)::int as passengers,
      coalesce(sum(planned_km), 0) as km
    from trips
    where company_id = ${companyId} and status = 'completed' and trip_date between ${periodStart} and ${periodEnd}
  `);
  const row = (stats.rows[0] ?? {}) as { trips: number; passengers: number; km: string };
  const trips = Number(row.trips ?? 0);
  const passengers = Number(row.passengers ?? 0);
  const km = Number(row.km ?? 0);

  const model = agreement?.pricingModel ?? company.billingModel;
  const rate = Number(agreement?.unitRate ?? 0);
  const lines: Array<{ description: string; category: string; quantity: string; unitPrice: string; amount: number }> = [];

  if (model === "per_passenger") {
    lines.push({ description: "Staff shuttle transport — passengers carried", category: "transport", quantity: String(passengers), unitPrice: String(rate), amount: Math.round(passengers * rate * 100) / 100 });
  } else if (model === "per_trip") {
    lines.push({ description: "Staff shuttle transport — completed trips", category: "transport", quantity: String(trips), unitPrice: String(rate), amount: Math.round(trips * rate * 100) / 100 });
  } else if (model === "distance_based") {
    lines.push({ description: "Staff shuttle transport — distance operated", category: "transport", quantity: String(km), unitPrice: String(rate), amount: Math.round(km * rate * 100) / 100 });
  } else {
    lines.push({ description: "Monthly transportation retainer", category: "retainer", quantity: "1", unitPrice: String(Number(agreement?.fixedMonthlyAmount ?? company.monthlyRate)), amount: Number(agreement?.fixedMonthlyAmount ?? company.monthlyRate) });
  }

  const extraTrips = await db.execute(sql`
    select count(*)::int as v from trips
    where company_id = ${companyId} and status = 'completed' and trip_date between ${periodStart} and ${periodEnd}
      and direction = 'ad_hoc'
  `);
  const adHoc = Number((extraTrips.rows[0] as { v: number } | undefined)?.v ?? 0);
  if (adHoc > 0) {
    lines.push({ description: `Ad-hoc / emergency transport (${adHoc} trips)`, category: "extra", quantity: String(adHoc), unitPrice: "250.00", amount: adHoc * 250 });
  }

  const subtotal = Math.round(lines.reduce((s, l) => s + l.amount, 0) * 100) / 100;
  const tax = Math.round(subtotal * 0.15 * 100) / 100;
  const total = Math.round((subtotal + tax) * 100) / 100;

  const [countRow] = await db.select({ v: sql<number>`count(*)` }).from(invoices);
  const invoiceNo = `INV-${new Date().getFullYear()}-${String(Number(countRow?.v ?? 0) + 1).padStart(4, "0")}`;

  const [invoice] = await db
    .insert(invoices)
    .values({
      companyId,
      invoiceNo,
      periodStart,
      periodEnd,
      subtotal: String(subtotal),
      tax: String(tax),
      total: String(total),
      amountPaid: "0",
      status: "issued",
      issuedAt: new Date(),
      dueDate: str(fd, "dueDate") || null,
      notes: `Generated from completed trips between ${periodStart} and ${periodEnd}.`,
    })
    .returning({ id: invoices.id });

  await db.insert(invoiceLines).values(
    lines.map((l) => ({
      invoiceId: invoice.id,
      description: l.description,
      category: l.category,
      quantity: l.quantity,
      unitPrice: l.unitPrice,
      amount: String(l.amount),
    })),
  );

  await logAudit({ user, action: "invoice.generate", entity: "invoice", entityId: invoice.id, companyId, details: { total, trips, passengers } });
  revalidatePath("/finance");
  return { ok: true, message: `Invoice ${invoiceNo} generated for ${moneySafe(total)} (${trips} trips, ${passengers} passengers).` };
}

function moneySafe(v: number) {
  return `GHS ${v.toLocaleString("en-GH", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export async function recordPaymentAction(_p: ActionState, fd: FormData): Promise<ActionState> {
  const user = await guard("finance.manage");
  const companyId = num(fd, "companyId");
  const amount = num(fd, "amount");
  if (!companyId || !amount || amount <= 0) return { ok: false, message: "Company and a positive amount are required." };
  const invoiceId = num(fd, "invoiceId");
  const method = (str(fd, "method") || "bank_transfer") as "bank_transfer";

  await db.insert(payments).values({
    companyId,
    invoiceId,
    amount: String(amount),
    method,
    reference: str(fd, "reference") || null,
    status: "successful",
    paidAt: new Date(),
    recordedById: user.id,
    notes: str(fd, "notes") || null,
  });

  if (invoiceId) {
    const [invoice] = await db.select().from(invoices).where(eq(invoices.id, invoiceId)).limit(1);
    if (invoice) {
      const paid = Number(invoice.amountPaid) + amount;
      const total = Number(invoice.total);
      await db
        .update(invoices)
        .set({ amountPaid: String(paid), status: paid >= total ? "paid" : "partial" })
        .where(eq(invoices.id, invoiceId));
    }
  }

  await logAudit({ user, action: "payment.record", entity: "payment", companyId, details: { amount, method, invoiceId } });
  revalidatePath("/finance");
  return { ok: true, message: `Payment of ${moneySafe(amount)} recorded.` };
}

export async function approveEarningsAction(_p: ActionState, fd: FormData): Promise<ActionState> {
  const user = await guard("finance.manage");
  const period = str(fd, "periodStart");
  if (!period) return { ok: false, message: "Payroll period start is required." };
  const result = await db
    .update(driverEarnings)
    .set({ status: "approved" })
    .where(and(eq(driverEarnings.status, "accrued"), eq(driverEarnings.periodStart, period)))
    .returning({ id: driverEarnings.id });
  await logAudit({ user, action: "earnings.approve", entity: "driver_earnings", details: { period, count: result.length } });
  revalidatePath("/finance");
  return { ok: true, message: `${result.length} earnings record(s) approved for payroll.` };
}
