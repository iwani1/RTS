"use server";

import { and, eq, gt, isNull } from "drizzle-orm";
import { redirect } from "next/navigation";
import { db } from "@/db";
import { employees, passwordResets, sessions, users } from "@/db/schema";
import { createSession, destroySession, hashPassword, logAudit, verifyPassword } from "@/lib/auth";
import { homeFor } from "@/lib/auth";
import { generateToken } from "@/lib/auth";
import type { Role } from "@/lib/rbac";
import type { ActionState } from "@/components/action-form";

const PRIVILEGED: Role[] = ["super_admin", "ops_manager", "finance_officer", "dispatcher"];

export async function loginAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  const password = String(formData.get("password") ?? "");
  const code = String(formData.get("code") ?? "").trim();

  if (!email || !password) return { ok: false, message: "Email and password are required." };

  const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (!user || !verifyPassword(password, user.passwordHash)) {
    return { ok: false, message: "Invalid email or password." };
  }
  if (user.status !== "active") {
    return { ok: false, message: `Account is ${user.status}. Contact your administrator to activate it.` };
  }
  if (PRIVILEGED.includes(user.role as Role) && user.twoFactorEnabled) {
    if (!code) return { ok: false, message: "Two-factor code required for privileged accounts." };
    if (code !== user.twoFactorCode) return { ok: false, message: "Invalid two-factor code." };
  }

  await createSession(user.id);
  await logAudit({
    user: { id: user.id, email: user.email, fullName: user.fullName, role: user.role, companyId: user.companyId, status: user.status, twoFactorEnabled: user.twoFactorEnabled },
    action: "auth.login",
    entity: "user",
    entityId: user.id,
  });
  redirect(homeFor(user.role as Role));
}

export async function registerAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const fullName = String(formData.get("fullName") ?? "").trim();
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  const phone = String(formData.get("phone") ?? "").trim();
  const password = String(formData.get("password") ?? "");

  if (!fullName || !email || !password) return { ok: false, message: "Full name, work email and password are required." };
  if (password.length < 8) return { ok: false, message: "Password must be at least 8 characters." };

  const [existing] = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
  if (existing) return { ok: false, message: "An account with this email already exists." };

  // If HR already registered this person as an employee, activate immediately.
  const [employee] = await db.select().from(employees).where(eq(employees.email, email)).limit(1);
  const autoApprove = Boolean(employee);

  const [created] = await db
    .insert(users)
    .values({
      fullName,
      email,
      phone: phone || null,
      passwordHash: hashPassword(password),
      role: "employee",
      status: autoApprove ? "active" : "pending",
      companyId: employee?.companyId ?? null,
    })
    .returning({ id: users.id, status: users.status });

  if (employee) {
    await db.update(employees).set({ userId: created.id }).where(eq(employees.id, employee.id));
  }

  await logAudit({
    action: "auth.register",
    entity: "user",
    entityId: created.id,
    companyId: employee?.companyId ?? null,
    details: { email, autoApprove },
  });

  return {
    ok: true,
    message: autoApprove
      ? "Account activated — your work email matched an employee record. You can sign in now."
      : "Registration received. An administrator must approve the account before you can sign in.",
  };
}

export async function requestPasswordResetAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  if (!email) return { ok: false, message: "Enter the email linked to your account." };
  const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (!user) {
    return { ok: true, message: "If that account exists, a reset link has been generated." };
  }
  const token = generateToken(24);
  await db.insert(passwordResets).values({
    userId: user.id,
    tokenHash: token,
    expiresAt: new Date(Date.now() + 60 * 60 * 1000),
  });
  await logAudit({ action: "auth.password_reset_requested", entity: "user", entityId: user.id });
  // No email provider configured in this environment: the link is returned so the
  // flow is testable end to end. Swap for an email/SMS job in production.
  return {
    ok: true,
    message: `Reset link (demo delivery): /reset-password?token=${token}`,
    data: { token },
  };
}

export async function resetPasswordAction(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const token = String(formData.get("token") ?? "").trim();
  const password = String(formData.get("password") ?? "");
  if (!token) return { ok: false, message: "Reset token missing." };
  if (password.length < 8) return { ok: false, message: "Password must be at least 8 characters." };

  const [row] = await db
    .select()
    .from(passwordResets)
    .where(and(eq(passwordResets.tokenHash, token), isNull(passwordResets.usedAt), gt(passwordResets.expiresAt, new Date())))
    .limit(1);
  if (!row) return { ok: false, message: "This reset link is invalid or has expired." };

  await db.update(users).set({ passwordHash: hashPassword(password) }).where(eq(users.id, row.userId));
  await db.update(passwordResets).set({ usedAt: new Date() }).where(eq(passwordResets.id, row.id));
  await db.delete(sessions).where(eq(sessions.userId, row.userId));
  await logAudit({ action: "auth.password_reset", entity: "user", entityId: row.userId });

  return { ok: true, message: "Password updated. You can now sign in with your new password." };
}

export async function logoutAction(): Promise<void> {
  await destroySession();
  redirect("/login");
}
