import Link from "next/link";
import { getSessionUser, homeFor } from "@/lib/auth";
import type { Role } from "@/lib/rbac";

export const dynamic = "force-dynamic";

const MODULES = [
  ["🔐", "Authentication & RBAC", "Eight roles, 2FA for privileged users, audit trail on every mutation."],
  ["🏢", "Corporate clients", "Companies, branches, contracts, SLAs and company scoped data isolation."],
  ["🎫", "Bookings", "Home-to-office, office-to-home, recurring rides, waiting lists, duplicates blocked."],
  ["🧭", "Route planning", "Capacity aware nearest-neighbour routing with pickup time windows."],
  ["🚐", "Fleet", "Documents, expiries, maintenance, availability and assignment guards."],
  ["🧑‍✈️", "Drivers", "Mobile friendly duty app with OTP boarding, offline queue and incidents."],
  ["🛰️", "Dispatch", "Live board, vehicle/driver reassignment, breakdown recovery workflow."],
  ["💰", "Finance", "GHS invoicing, payments, driver earnings and payroll export."],
  ["🚨", "Safety", "Incidents, SOS, no-shows, document expiry reminders, inspections."],
  ["📈", "Analytics", "On-time performance, utilisation, cost per passenger, CSV/PDF exports."],
];

export default async function LandingPage() {
  const user = await getSessionUser();

  return (
    <div className="min-h-screen bg-gradient-to-b from-navy-900 via-navy-900 to-slate-900 text-navy-100">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
        <div className="flex items-center gap-2">
          <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-teal-500 font-bold text-navy-950">SR</span>
          <div>
            <p className="font-semibold text-white">StaffRide TMS</p>
            <p className="text-xs text-navy-300">Enterprise staff transportation</p>
          </div>
        </div>
        <nav className="flex items-center gap-3 text-sm">
          <a href="/docs" className="hidden text-navy-200 hover:text-white sm:block">
            Documentation
          </a>
          <Link href="/login" className="rounded-lg bg-teal-500 px-4 py-2 font-medium text-navy-950 hover:bg-teal-400">
            {user ? "Open my workspace" : "Sign in"}
          </Link>
        </nav>
      </header>

      <section className="mx-auto max-w-6xl px-6 py-14">
        <p className="mb-3 inline-flex rounded-full bg-white/10 px-3 py-1 text-xs font-medium text-teal-300">
          Phase 1 MVP · Live Phase 2 operations · Phase 3 finance
        </p>
        <h1 className="max-w-3xl text-4xl font-semibold leading-tight text-white sm:text-5xl">
          Run daily staff transportation for every corporate client from one command centre.
        </h1>
        <p className="mt-4 max-w-2xl text-navy-200">
          Bookings, shift-aware routing, dispatch, fleet and driver compliance, boarding OTP verification, live trip
          monitoring, invoicing in Ghana Cedis and operational analytics — on real, persisted data.
        </p>
        <div className="mt-8 flex flex-wrap gap-3">
          <Link href={user ? homeFor(user.role as Role) : "/login"} className="rounded-lg bg-teal-500 px-5 py-3 font-medium text-navy-950 hover:bg-teal-400">
            {user ? "Go to my workspace" : "Enter the platform"}
          </Link>
          <a href="/docs" className="rounded-lg border border-white/25 px-5 py-3 font-medium text-white hover:bg-white/10">
            Architecture & API docs
          </a>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 pb-16">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {MODULES.map(([icon, title, body]) => (
            <div key={title} className="rounded-xl border border-white/10 bg-white/5 p-4">
              <p className="text-2xl" aria-hidden>
                {icon}
              </p>
              <h3 className="mt-2 font-semibold text-white">{title}</h3>
              <p className="mt-1 text-sm text-navy-200">{body}</p>
            </div>
          ))}
        </div>
      </section>

      <footer className="border-t border-white/10 px-6 py-6 text-center text-xs text-navy-400">
        StaffRide TMS · demo dataset seeds automatically · mapping, SMS and payment providers run in clearly labelled demo mode
      </footer>
    </div>
  );
}
