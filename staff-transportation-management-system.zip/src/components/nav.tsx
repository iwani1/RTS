"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, useSyncExternalStore } from "react";
import type { Section } from "@/lib/rbac";
import { cn } from "@/lib/utils";

export type NavItem = { href: string; label: string; section: Section; icon: string; badge?: number };

export function Sidebar({ items, brand, roleLabel, userName }: { items: NavItem[]; brand: string; roleLabel: string; userName: string }) {
  const pathname = usePathname();
  // the drawer is keyed to the current pathname so navigating closes it without
  // needing to call setState inside an effect
  const [openPath, setOpenPath] = useState<string | null>(null);
  const open = openPath === pathname;

  // theme state is derived from the document so server and client agree without
  // calling setState inside an effect
  const subscribe = (onChange: () => void) => {
    const observer = new MutationObserver(onChange);
    observer.observe(document.documentElement, { attributes: true, attributeFilter: ["class"] });
    return () => observer.disconnect();
  };
  const dark = useSyncExternalStore(
    subscribe,
    () => document.documentElement.classList.contains("dark"),
    () => false,
  );

  const toggleTheme = () => {
    const next = !document.documentElement.classList.contains("dark");
    document.documentElement.classList.toggle("dark", next);
    try {
      localStorage.setItem("tms-theme", next ? "dark" : "light");
    } catch {
      /* storage unavailable */
    }
  };

  return (
    <>
      <button
        type="button"
        onClick={() => setOpenPath(open ? null : pathname)}
        className="fixed bottom-4 left-4 z-50 rounded-full bg-navy-800 px-4 py-3 text-sm font-medium text-white shadow-lg lg:hidden"
        aria-expanded={open}
        aria-label="Toggle navigation"
      >
        {open ? "✕ Close" : "☰ Menu"}
      </button>

      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-40 flex w-64 flex-col bg-navy-900 text-navy-100 transition-transform lg:translate-x-0 dark:bg-slate-900",
          open ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="flex items-center gap-2 border-b border-white/10 px-4 py-4">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-teal-500 text-base font-bold text-navy-950">SR</span>
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold text-white">{brand}</p>
            <p className="text-[11px] text-navy-300">{roleLabel}</p>
          </div>
        </div>

        <nav className="flex-1 space-y-0.5 overflow-y-auto px-2 py-3">
          {items.map((item) => {
            const active = pathname === item.href || (item.href !== "/dashboard" && pathname.startsWith(item.href));
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center justify-between gap-2 rounded-lg px-3 py-2 text-sm transition",
                  active ? "bg-teal-500 font-semibold text-navy-950" : "text-navy-200 hover:bg-white/10 hover:text-white",
                )}
              >
                <span className="flex items-center gap-2.5">
                  <span aria-hidden className="w-4 text-center">{item.icon}</span>
                  {item.label}
                </span>
                {item.badge ? (
                  <span className={cn("rounded-full px-1.5 text-[10px] font-semibold", active ? "bg-navy-900 text-white" : "bg-teal-500 text-navy-950")}>
                    {item.badge}
                  </span>
                ) : null}
              </Link>
            );
          })}
        </nav>

        <div className="border-t border-white/10 px-3 py-3">
          <p className="truncate px-1 text-xs text-navy-300">Signed in as</p>
          <p className="truncate px-1 text-sm font-medium text-white">{userName}</p>
          <div className="mt-2 flex gap-2">
            <button type="button" onClick={toggleTheme} className="flex-1 rounded-md bg-white/10 px-2 py-1.5 text-xs text-white hover:bg-white/20">
              {dark ? "☀️ Light" : "🌙 Dark"}
            </button>
            <form action="/api/auth/logout" method="post" className="flex-1">
              <button type="submit" className="w-full rounded-md bg-rose-500/90 px-2 py-1.5 text-xs font-medium text-white hover:bg-rose-500">
                Sign out
              </button>
            </form>
          </div>
        </div>
      </aside>
      {open ? <div className="fixed inset-0 z-30 bg-black/40 lg:hidden" onClick={() => setOpenPath(null)} /> : null}
    </>
  );
}
