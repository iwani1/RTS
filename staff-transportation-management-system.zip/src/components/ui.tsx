import type { ReactNode } from "react";
import Link from "next/link";
import { cn, humanize } from "@/lib/utils";

/* --------------------------------------------------------------- layout */

export function PageHeader({
  title,
  subtitle,
  actions,
}: {
  title: string;
  subtitle?: string;
  actions?: ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-col gap-3 border-b border-slate-200 pb-4 md:flex-row md:items-end md:justify-between dark:border-slate-800">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight text-navy-900 dark:text-white">{title}</h1>
        {subtitle ? <p className="mt-1 max-w-3xl text-sm text-slate-500 dark:text-slate-400">{subtitle}</p> : null}
      </div>
      {actions ? <div className="flex flex-wrap items-center gap-2">{actions}</div> : null}
    </div>
  );
}

export function Card({
  title,
  subtitle,
  actions,
  children,
  className,
  padded = true,
}: {
  title?: string;
  subtitle?: string;
  actions?: ReactNode;
  children: ReactNode;
  className?: string;
  padded?: boolean;
}) {
  return (
    <section
      className={cn(
        "rounded-xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900",
        className,
      )}
    >
      {title || actions ? (
        <header className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 px-4 py-3 dark:border-slate-800">
          <div>
            <h2 className="text-sm font-semibold uppercase tracking-wide text-slate-600 dark:text-slate-300">{title}</h2>
            {subtitle ? <p className="text-xs text-slate-400">{subtitle}</p> : null}
          </div>
          {actions ? <div className="flex flex-wrap items-center gap-2">{actions}</div> : null}
        </header>
      ) : null}
      <div className={padded ? "p-4" : ""}>{children}</div>
    </section>
  );
}

export function StatCard({
  label,
  value,
  hint,
  tone = "default",
  icon,
}: {
  label: string;
  value: string | number;
  hint?: string;
  tone?: "default" | "positive" | "warning" | "danger" | "info";
  icon?: string;
}) {
  const tones: Record<string, string> = {
    default: "text-navy-900 dark:text-white",
    positive: "text-emerald-600 dark:text-emerald-400",
    warning: "text-amber-600 dark:text-amber-400",
    danger: "text-rose-600 dark:text-rose-400",
    info: "text-teal-600 dark:text-teal-400",
  };
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900">
      <div className="flex items-start justify-between">
        <p className="text-xs font-medium uppercase tracking-wide text-slate-500 dark:text-slate-400">{label}</p>
        {icon ? <span aria-hidden className="text-lg">{icon}</span> : null}
      </div>
      <p className={cn("mt-2 text-2xl font-semibold tabular-nums", tones[tone])}>{value}</p>
      {hint ? <p className="mt-1 text-xs text-slate-400">{hint}</p> : null}
    </div>
  );
}

/* ---------------------------------------------------------------- badges */

const TONES: Record<string, string> = {
  green: "bg-emerald-50 text-emerald-700 ring-emerald-200 dark:bg-emerald-950 dark:text-emerald-300 dark:ring-emerald-900",
  red: "bg-rose-50 text-rose-700 ring-rose-200 dark:bg-rose-950 dark:text-rose-300 dark:ring-rose-900",
  amber: "bg-amber-50 text-amber-700 ring-amber-200 dark:bg-amber-950 dark:text-amber-300 dark:ring-amber-900",
  blue: "bg-sky-50 text-sky-700 ring-sky-200 dark:bg-sky-950 dark:text-sky-300 dark:ring-sky-900",
  navy: "bg-navy-50 text-navy-700 ring-navy-200 dark:bg-navy-950 dark:text-navy-200 dark:ring-navy-900",
  teal: "bg-teal-50 text-teal-700 ring-teal-200 dark:bg-teal-950 dark:text-teal-300 dark:ring-teal-900",
  slate: "bg-slate-100 text-slate-600 ring-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:ring-slate-700",
  violet: "bg-violet-50 text-violet-700 ring-violet-200 dark:bg-violet-950 dark:text-violet-300 dark:ring-violet-900",
};

export type Tone = keyof typeof TONES;

export function Badge({ children, tone = "slate" }: { children: ReactNode; tone?: Tone }) {
  return (
    <span className={cn("inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ring-1 ring-inset", TONES[tone])}>
      {children}
    </span>
  );
}

const STATUS_TONES: Record<string, Tone> = {
  // trips
  scheduled: "blue",
  dispatching: "violet",
  in_progress: "teal",
  completed: "green",
  delayed: "amber",
  breakdown: "red",
  cancelled: "red",
  // bookings
  pending: "amber",
  approved: "blue",
  waitlisted: "violet",
  assigned: "navy",
  no_show: "amber",
  rejected: "red",
  // vehicles
  available: "green",
  on_trip: "teal",
  under_maintenance: "amber",
  out_of_service: "red",
  off_duty: "slate",
  unavailable: "red",
  // incidents / finance
  open: "red",
  acknowledged: "amber",
  resolved: "green",
  draft: "slate",
  issued: "blue",
  paid: "green",
  partial: "amber",
  overdue: "red",
  void: "slate",
  active: "green",
  suspended: "red",
  inactive: "slate",
  successful: "green",
  failed: "red",
  accrued: "slate",
  new: "amber",
  addressed: "green",
  planned: "blue",
};

export function StatusBadge({ status }: { status: string | null | undefined }) {
  const key = status ?? "";
  return <Badge tone={STATUS_TONES[key] ?? "slate"}>{humanize(key)}</Badge>;
}

/* ---------------------------------------------------------------- tables */

export function Table({ head, children }: { head: string[]; children: ReactNode }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-full text-left text-sm">
        <thead>
          <tr className="border-b border-slate-200 text-xs uppercase tracking-wide text-slate-500 dark:border-slate-800 dark:text-slate-400">
            {head.map((h) => (
              <th key={h} className="whitespace-nowrap px-3 py-2 font-medium">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100 dark:divide-slate-800">{children}</tbody>
      </table>
    </div>
  );
}

export function Td({ children, className }: { children: ReactNode; className?: string }) {
  return <td className={cn("px-3 py-2 align-middle text-slate-700 dark:text-slate-300", className)}>{children}</td>;
}

export function EmptyState({ title, hint }: { title: string; hint?: string }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-slate-300 px-6 py-10 text-center dark:border-slate-700">
      <p className="text-sm font-medium text-slate-600 dark:text-slate-300">{title}</p>
      {hint ? <p className="mt-1 text-xs text-slate-400">{hint}</p> : null}
    </div>
  );
}

/* ----------------------------------------------------------------- forms */

export const inputClass =
  "w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 shadow-sm outline-none transition focus:border-teal-500 focus:ring-2 focus:ring-teal-500/30 disabled:bg-slate-100 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100";

export function Field({
  label,
  name,
  type = "text",
  required,
  defaultValue,
  placeholder,
  options,
  rows,
  step,
  hint,
  className,
}: {
  label: string;
  name: string;
  type?: string;
  required?: boolean;
  defaultValue?: string | number | null;
  placeholder?: string;
  options?: Array<{ value: string; label: string }>;
  rows?: number;
  step?: string;
  hint?: string;
  className?: string;
}) {
  return (
    // the control is nested inside the label so screen readers associate them
    // without needing a generated (impure) element id
    <label className={cn("block", className)}>
      <span className="mb-1 block text-xs font-medium text-slate-600 dark:text-slate-300">
        {label} {required ? <span className="text-rose-500">*</span> : null}
      </span>
      {options ? (
        <select name={name} required={required} defaultValue={defaultValue ?? ""} className={inputClass}>
          {options.map((o) => (
            <option key={o.value} value={o.value}>
              {o.label}
            </option>
          ))}
        </select>
      ) : rows ? (
        <textarea name={name} rows={rows} required={required} placeholder={placeholder} defaultValue={defaultValue ?? ""} className={inputClass} />
      ) : (
        <input
          name={name}
          type={type}
          step={step}
          required={required}
          placeholder={placeholder}
          defaultValue={defaultValue ?? ""}
          className={inputClass}
        />
      )}
      {hint ? <span className="mt-1 block text-xs text-slate-400">{hint}</span> : null}
    </label>
  );
}

export function buttonClass(variant: "primary" | "secondary" | "ghost" | "danger" = "primary") {
  const base =
    "inline-flex items-center justify-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium transition disabled:cursor-not-allowed disabled:opacity-60";
  const map = {
    primary: "bg-navy-800 text-white shadow-sm hover:bg-navy-700 dark:bg-teal-600 dark:hover:bg-teal-500",
    secondary:
      "border border-slate-300 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800",
    ghost: "text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800",
    danger: "bg-rose-600 text-white hover:bg-rose-500",
  };
  return cn(base, map[variant]);
}

export function LinkButton({
  href,
  children,
  variant = "secondary",
}: {
  href: string;
  children: ReactNode;
  variant?: "primary" | "secondary" | "ghost" | "danger";
}) {
  return (
    <Link href={href} className={buttonClass(variant)}>
      {children}
    </Link>
  );
}

export function ProgressBar({ value, tone = "teal" }: { value: number; tone?: "teal" | "amber" | "rose" }) {
  const colors = { teal: "bg-teal-500", amber: "bg-amber-500", rose: "bg-rose-500" };
  return (
    <div className="h-2 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-slate-800">
      <div className={cn("h-full rounded-full", colors[tone])} style={{ width: `${Math.min(100, Math.max(0, value))}%` }} />
    </div>
  );
}

export function Tabs({ tabs, current }: { tabs: Array<{ href: string; label: string; count?: number }>; current: string }) {
  return (
    <nav className="mb-4 flex flex-wrap gap-1 rounded-lg bg-slate-100 p-1 text-sm dark:bg-slate-900">
      {tabs.map((t) => (
        <Link
          key={t.href}
          href={t.href}
          className={cn(
            "rounded-md px-3 py-1.5 font-medium transition",
            t.href === current
              ? "bg-white text-navy-900 shadow-sm dark:bg-slate-800 dark:text-white"
              : "text-slate-500 hover:text-navy-800 dark:text-slate-400 dark:hover:text-white",
          )}
        >
          {t.label}
          {typeof t.count === "number" ? (
            <span className="ml-1.5 rounded-full bg-slate-200 px-1.5 text-xs dark:bg-slate-700">{t.count}</span>
          ) : null}
        </Link>
      ))}
    </nav>
  );
}

export function DefinitionList({ items }: { items: Array<{ label: string; value: ReactNode }> }) {
  return (
    <dl className="grid grid-cols-1 gap-x-6 gap-y-3 sm:grid-cols-2">
      {items.map((i) => (
        <div key={i.label} className="min-w-0">
          <dt className="text-xs uppercase tracking-wide text-slate-400">{i.label}</dt>
          <dd className="mt-0.5 truncate text-sm font-medium text-slate-800 dark:text-slate-200">{i.value}</dd>
        </div>
      ))}
    </dl>
  );
}

export function DemoNotice({ children }: { children?: ReactNode }) {
  return (
    <div className="rounded-lg border border-dashed border-amber-400 bg-amber-50 px-3 py-2 text-xs text-amber-800 dark:border-amber-700 dark:bg-amber-950/40 dark:text-amber-300">
      <strong className="font-semibold">Demo implementation:</strong> {children ?? "No live provider credentials configured."}
    </div>
  );
}
