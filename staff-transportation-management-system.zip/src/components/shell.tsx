import type { ReactNode } from "react";
import { and, count, eq, isNull } from "drizzle-orm";
import { db } from "@/db";
import { bookings, incidents, notifications } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { canAccess, ROLE_LABELS, type Role, type Section } from "@/lib/rbac";
import { Sidebar, type NavItem } from "./nav";

const NAV: Array<{ href: string; label: string; section: Section; icon: string }> = [
  { href: "/dashboard", label: "Dashboard", section: "dashboard", icon: "📊" },
  { href: "/dispatch", label: "Live Dispatch", section: "dispatch", icon: "🛰️" },
  { href: "/trips", label: "Trips", section: "trips", icon: "🚌" },
  { href: "/bookings", label: "Bookings", section: "bookings", icon: "🎫" },
  { href: "/routes", label: "Routes & Stops", section: "routes", icon: "🧭" },
  { href: "/employees", label: "Employees", section: "employees", icon: "👥" },
  { href: "/companies", label: "Corporate Clients", section: "companies", icon: "🏢" },
  { href: "/fleet", label: "Fleet", section: "fleet", icon: "🚐" },
  { href: "/drivers", label: "Drivers", section: "drivers", icon: "🧑‍✈️" },
  { href: "/incidents", label: "Safety & Incidents", section: "incidents", icon: "🚨" },
  { href: "/finance", label: "Billing & Payroll", section: "finance", icon: "💰" },
  { href: "/reports", label: "Reports", section: "reports", icon: "📈" },
  { href: "/audit", label: "Audit Trail", section: "audit", icon: "🗂️" },
  { href: "/passenger", label: "My Transport", section: "passenger", icon: "🧍" },
  { href: "/driver", label: "Driver App", section: "driverapp", icon: "🚏" },
  { href: "/settings", label: "Settings & Users", section: "settings", icon: "⚙️" },
];

export async function AppShell({ children }: { children: ReactNode }) {
  const user = await requireUser();
  const role = user.role as Role;

  const badges = await loadBadges(role, user.companyId);

  const items: NavItem[] = NAV.filter((n) => canAccess(role, n.section)).map((n) => ({
    href: n.href,
    label: n.label,
    section: n.section,
    icon: n.icon,
    badge: badges[n.section],
  }));

  const unread = await db
    .select({ v: count() })
    .from(notifications)
    .where(and(eq(notifications.userId, user.id), isNull(notifications.readAt)));

  return (
    <div className="min-h-screen lg:pl-64">
      <Sidebar
        items={items}
        brand="StaffRide TMS"
        roleLabel={ROLE_LABELS[role]}
        userName={user.fullName}
      />
      <header className="sticky top-0 z-20 border-b border-slate-200 bg-white/90 backdrop-blur dark:border-slate-800 dark:bg-slate-950/90">
        <div className="flex items-center justify-between gap-3 px-4 py-3 lg:px-6">
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
            <span className="rounded-full bg-teal-50 px-2 py-0.5 font-medium text-teal-700 dark:bg-teal-950 dark:text-teal-300">
              {ROLE_LABELS[role]}
            </span>
            <span className="hidden sm:inline">
              {Number(unread[0]?.v ?? 0) > 0 ? `${unread[0]?.v} unread notifications` : "No new notifications"}
            </span>
          </div>
          <nav className="flex items-center gap-2 text-xs">
            <a href="/docs" className="rounded-md px-2 py-1 text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800">
              Docs
            </a>
            <a
              href="/settings"
              className="rounded-md px-2 py-1 font-medium text-navy-700 hover:bg-slate-100 dark:text-navy-200 dark:hover:bg-slate-800"
            >
              {user.fullName.split(" ")[0]}&apos;s account
            </a>
          </nav>
        </div>
      </header>
      <main className="mx-auto w-full max-w-7xl px-4 py-6 lg:px-6">{children}</main>
    </div>
  );
}

async function loadBadges(role: Role, companyId: number | null): Promise<Partial<Record<Section, number>>> {
  try {
    const result: Partial<Record<Section, number>> = {};
    if (canAccess(role, "bookings")) {
      const [pending] = await db
        .select({ v: count() })
        .from(bookings)
        .where(
          companyId && role === "corporate_admin"
            ? and(eq(bookings.companyId, companyId), eq(bookings.status, "pending"))
            : eq(bookings.status, "pending"),
        );
      result.bookings = Number(pending?.v ?? 0);
    }
    if (canAccess(role, "incidents")) {
      const [open] = await db.select({ v: count() }).from(incidents).where(eq(incidents.status, "open"));
      result.incidents = Number(open?.v ?? 0);
    }
    return result;
  } catch {
    return {};
  }
}
