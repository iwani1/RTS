"use client";

import { useActionState } from "react";
import type { ReactNode } from "react";
import { useFormStatus } from "react-dom";
import { buttonClass } from "./ui";

export type ActionState = { ok?: boolean; message?: string; data?: Record<string, string> } | null;

export type ServerAction = (state: ActionState, formData: FormData) => Promise<ActionState>;

function SubmitButton({ label, variant = "primary", confirm }: { label: string; variant?: "primary" | "secondary" | "danger" | "ghost"; confirm?: string }) {
  const { pending } = useFormStatus();
  return (
    <button
      type="submit"
      disabled={pending}
      className={buttonClass(variant)}
      onClick={(e) => {
        if (confirm && !window.confirm(confirm)) e.preventDefault();
      }}
    >
      {pending ? "Working…" : label}
    </button>
  );
}

/**
 * Wraps a server action with progressive feedback so every mutating control in
 * the product has a real, implemented outcome (no dead buttons).
 */
export function ActionForm({
  action,
  children,
  submitLabel,
  submitVariant = "primary",
  className,
  confirm,
  footer,
  resetOnSuccess,
}: {
  action: ServerAction;
  children?: ReactNode;
  submitLabel: string;
  submitVariant?: "primary" | "secondary" | "danger" | "ghost";
  className?: string;
  confirm?: string;
  footer?: ReactNode;
  resetOnSuccess?: boolean;
}) {
  const [state, formAction] = useActionState(action, null);
  return (
    <form
      action={formAction}
      className={className}
      key={resetOnSuccess && state?.ok ? String(state.ok) + String(state.message) : undefined}
    >
      {children}
      {state?.message ? (
        <p
          role="status"
          className={
            state.ok
              ? "mt-3 rounded-lg bg-emerald-50 px-3 py-2 text-xs text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300"
              : "mt-3 rounded-lg bg-rose-50 px-3 py-2 text-xs text-rose-700 dark:bg-rose-950 dark:text-rose-300"
          }
        >
          {state.message}
        </p>
      ) : null}
      <div className="mt-3 flex items-center gap-2">
        <SubmitButton label={submitLabel} variant={submitVariant} confirm={confirm} />
        {footer}
      </div>
    </form>
  );
}

export function InlineActionForm({
  action,
  hiddenFields,
  submitLabel,
  variant = "secondary",
  confirm,
}: {
  action: ServerAction;
  hiddenFields: Record<string, string | number>;
  submitLabel: string;
  variant?: "primary" | "secondary" | "danger" | "ghost";
  confirm?: string;
}) {
  const [state, formAction] = useActionState(action, null);
  return (
    <form action={formAction} className="inline-flex items-center gap-2">
      {Object.entries(hiddenFields).map(([k, v]) => (
        <input key={k} type="hidden" name={k} value={String(v)} />
      ))}
      <SubmitButton label={submitLabel} variant={variant} confirm={confirm} />
      {state?.message ? (
        <span className={state.ok ? "text-xs text-emerald-600" : "text-xs text-rose-600"}>{state.message}</span>
      ) : null}
    </form>
  );
}
