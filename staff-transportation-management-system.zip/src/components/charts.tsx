/** Pure SVG chart components - no charting dependency required. */
import { cn } from "@/lib/utils";

export function BarChart({
  data,
  height = 180,
  valueKey = "value",
  labelKey = "label",
  format,
  tone = "#0f766e",
}: {
  data: Array<Record<string, string | number>>;
  height?: number;
  valueKey?: string;
  labelKey?: string;
  format?: (v: number) => string;
  tone?: string;
}) {
  const values = data.map((d) => Number(d[valueKey] ?? 0));
  const max = Math.max(1, ...values);
  return (
    <div className="w-full">
      <div className="flex items-end gap-1" style={{ height }}>
        {data.map((d, i) => {
          const v = values[i];
          const h = Math.max(2, (v / max) * (height - 24));
          return (
            <div key={i} className="group relative flex flex-1 flex-col items-center justify-end">
              <span className="mb-1 text-[10px] font-medium text-slate-500 opacity-0 transition group-hover:opacity-100 dark:text-slate-300">
                {format ? format(v) : v}
              </span>
              <div
                className="w-full rounded-t"
                style={{ height: h, backgroundColor: tone, opacity: 0.85 }}
                title={`${d[labelKey]}: ${format ? format(v) : v}`}
              />
            </div>
          );
        })}
      </div>
      <div className="mt-1 flex gap-1">
        {data.map((d, i) => (
          <span key={i} className="flex-1 truncate text-center text-[9px] text-slate-400">
            {String(d[labelKey] ?? "")}
          </span>
        ))}
      </div>
    </div>
  );
}

export function LineChart({
  series,
  height = 190,
  labels,
}: {
  series: Array<{ name: string; color: string; points: number[] }>;
  height?: number;
  labels: string[];
}) {
  const all = series.flatMap((s) => s.points);
  const max = Math.max(1, ...all);
  const w = 700;
  const h = height;
  const pad = 24;
  const stepX = labels.length > 1 ? (w - pad * 2) / (labels.length - 1) : 0;
  const y = (v: number) => h - pad - (v / max) * (h - pad * 2);
  return (
    <div className="w-full">
      <svg viewBox={`0 0 ${w} ${h}`} className="h-auto w-full" role="img" aria-label="trend chart">
        {[0, 0.25, 0.5, 0.75, 1].map((t) => (
          <line key={t} x1={pad} x2={w - pad} y1={y(max * t)} y2={y(max * t)} stroke="currentColor" className="text-slate-200 dark:text-slate-800" strokeWidth="1" />
        ))}
        {series.map((s) => {
          const d = s.points.map((p, i) => `${i === 0 ? "M" : "L"} ${pad + i * stepX} ${y(p)}`).join(" ");
          return (
            <g key={s.name}>
              <path d={d} fill="none" stroke={s.color} strokeWidth="2.5" strokeLinejoin="round" />
              {s.points.map((p, i) => (
                <circle key={i} cx={pad + i * stepX} cy={y(p)} r="3" fill={s.color} />
              ))}
            </g>
          );
        })}
      </svg>
      <div className="flex flex-wrap items-center justify-between gap-2 text-[10px] text-slate-400">
        <div className="flex gap-3">
          {series.map((s) => (
            <span key={s.name} className="inline-flex items-center gap-1">
              <span className="inline-block h-2 w-2 rounded-full" style={{ backgroundColor: s.color }} />
              {s.name}
            </span>
          ))}
        </div>
        <span>
          {labels[0]} → {labels[labels.length - 1]}
        </span>
      </div>
    </div>
  );
}

export function DonutStat({ value, label, tone = "#0f766e" }: { value: number; label: string; tone?: string }) {
  const clamped = Math.min(100, Math.max(0, value));
  const r = 42;
  const c = 2 * Math.PI * r;
  return (
    <div className="flex items-center gap-3">
      <svg width="104" height="104" viewBox="0 0 104 104" role="img" aria-label={label}>
        <circle cx="52" cy="52" r={r} fill="none" stroke="currentColor" className="text-slate-200 dark:text-slate-800" strokeWidth="10" />
        <circle
          cx="52"
          cy="52"
          r={r}
          fill="none"
          stroke={tone}
          strokeWidth="10"
          strokeLinecap="round"
          strokeDasharray={`${(clamped / 100) * c} ${c}`}
          transform="rotate(-90 52 52)"
        />
        <text x="52" y="56" textAnchor="middle" className={cn("fill-slate-700 text-sm font-semibold dark:fill-slate-200")}>
          {clamped.toFixed(0)}%
        </text>
      </svg>
      <p className="text-sm text-slate-500 dark:text-slate-400">{label}</p>
    </div>
  );
}
