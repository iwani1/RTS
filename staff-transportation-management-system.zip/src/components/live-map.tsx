"use client";

import { useEffect, useState } from "react";

export type MapPoint = {
  id: string;
  lat: number;
  lng: number;
  label: string;
  sublabel?: string;
  kind: "vehicle" | "stop" | "office" | "incident";
  tone?: "teal" | "navy" | "amber" | "rose";
};

const BOUNDS = { minLat: 5.45, maxLat: 5.8, minLng: -0.45, maxLng: 0.05 };

function project(p: { lat: number; lng: number }) {
  const x = ((p.lng - BOUNDS.minLng) / (BOUNDS.maxLng - BOUNDS.minLng)) * 100;
  const y = ((BOUNDS.maxLat - p.lat) / (BOUNDS.maxLat - BOUNDS.minLat)) * 100;
  return { x: Math.max(2, Math.min(98, x)), y: Math.max(2, Math.min(98, y)) };
}

const TONE_FILL: Record<string, string> = {
  teal: "#0d9488",
  navy: "#12355b",
  amber: "#d97706",
  rose: "#e11d48",
};

/**
 * Lightweight vector map of the Greater Accra service area.
 *
 * NOTE: this is a *demo* renderer. Set NEXT_PUBLIC_MAP_PROVIDER (mapbox|google)
 * and the corresponding key to switch to a real basemap; see docs/API.md.
 */
export function MapCanvas({ points, height = 360 }: { points: MapPoint[]; height?: number }) {
  return (
    <div
      className="relative w-full overflow-hidden rounded-lg border border-slate-200 bg-[#eaf2f6] dark:border-slate-700 dark:bg-slate-950"
      style={{ height }}
    >
      <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="absolute inset-0 h-full w-full">
        {/* stylised coastline + arterial roads */}
        <path d="M0,84 C12,78 22,86 34,80 C46,74 52,82 64,76 C76,70 88,78 100,72 L100,100 L0,100 Z" fill="#cfe3ec" className="dark:opacity-10" />
        <g stroke="#b9ced9" strokeWidth="0.5" className="dark:opacity-20">
          <line x1="0" y1="52" x2="100" y2="46" />
          <line x1="26" y1="0" x2="34" y2="100" />
          <line x1="62" y1="0" x2="58" y2="100" />
          <line x1="0" y1="70" x2="100" y2="66" />
          <line x1="84" y1="0" x2="78" y2="100" />
        </g>
        {points.map((p, i) => {
          const a = project(p);
          const prev = i > 0 ? project(points[i - 1]) : null;
          return (
            <g key={p.id}>
              {prev ? <line x1={prev.x} y1={prev.y} x2={a.x} y2={a.y} stroke="#0d9488" strokeWidth="0.4" strokeDasharray="1.5 1" /> : null}
              <circle cx={a.x} cy={a.y} r={p.kind === "vehicle" ? 2.4 : 1.6} fill={TONE_FILL[p.tone ?? "teal"]} stroke="#ffffff" strokeWidth="0.5" />
            </g>
          );
        })}
      </svg>
      <div className="pointer-events-none absolute inset-0">
        {points.map((p) => {
          const a = project(p);
          return (
            <div
              key={`lbl-${p.id}`}
              className="absolute -translate-x-1/2 whitespace-nowrap rounded bg-white/90 px-1 py-0.5 text-[10px] font-medium text-slate-700 shadow-sm dark:bg-slate-800/90 dark:text-slate-200"
              style={{ left: `${a.x}%`, top: `calc(${a.y}% + 8px)` }}
            >
              {p.label}
            </div>
          );
        })}
      </div>
      <span className="absolute bottom-2 right-2 rounded bg-white/85 px-2 py-0.5 text-[10px] text-slate-500 dark:bg-slate-900/85">
        Demo vector map · Greater Accra
      </span>
    </div>
  );
}

type LivePayload = { points: MapPoint[]; updatedAt?: string };

/** Polls the dispatch feed and re-renders the map. */
export function LiveMap({ initial, pollUrl }: { initial: MapPoint[]; pollUrl?: string }) {
  const [points, setPoints] = useState<MapPoint[]>(initial);
  const [updatedAt, setUpdatedAt] = useState<string | null>(null);
  const [live, setLive] = useState(true);

  useEffect(() => {
    if (!pollUrl || !live) return;
    let cancelled = false;
    const load = async () => {
      try {
        const res = await fetch(pollUrl, { cache: "no-store" });
        if (!res.ok) return;
        const data = (await res.json()) as LivePayload;
        if (!cancelled && Array.isArray(data.points)) {
          setPoints(data.points);
          setUpdatedAt(new Date().toLocaleTimeString("en-GB"));
        }
      } catch {
        /* offline: keep last known positions */
      }
    };
    const id = setInterval(load, 15000);
    load();
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, [pollUrl, live]);

  return (
    <div>
      <MapCanvas points={points} />
      <div className="mt-2 flex items-center justify-between text-xs text-slate-500">
        <span>
          {points.filter((p) => p.kind === "vehicle").length} vehicles · {points.length} markers
          {updatedAt ? ` · refreshed ${updatedAt}` : " · static snapshot"}
        </span>
        {pollUrl ? (
          <button
            type="button"
            onClick={() => setLive((v) => !v)}
            className="rounded border border-slate-300 px-2 py-0.5 dark:border-slate-700"
          >
            {live ? "Pause refresh" : "Resume refresh"}
          </button>
        ) : null}
      </div>
    </div>
  );
}
