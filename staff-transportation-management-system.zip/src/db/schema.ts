/**
 * Enterprise Staff Transportation Management System (TMS)
 * PostgreSQL schema (Drizzle ORM)
 *
 * Design notes
 *  - Every operational row is scoped to a `companyId` where the data belongs to a
 *    corporate client, which is the primary tenant-isolation boundary.
 *  - Money is stored as numeric(12,2) and rendered in GHS by default.
 *  - All tables carry created/updated timestamps and FK constraints with indexes
 *    on the hot lookup paths (tenant, date, status, trip).
 */
import {
  boolean,
  date,
  doublePrecision,
  index,
  integer,
  jsonb,
  numeric,
  pgEnum,
  pgTable,
  serial,
  text,
  time,
  timestamp,
  unique,
  varchar,
} from "drizzle-orm/pg-core";

/* ------------------------------------------------------------------ enums */

export const userRoleEnum = pgEnum("user_role", [
  "super_admin",
  "ops_manager",
  "dispatcher",
  "corporate_admin",
  "fleet_manager",
  "driver",
  "employee",
  "finance_officer",
]);

export const userStatusEnum = pgEnum("user_status", [
  "pending",
  "active",
  "suspended",
]);

export const companyStatusEnum = pgEnum("company_status", [
  "active",
  "suspended",
  "inactive",
]);

export const billingModelEnum = pgEnum("billing_model", [
  "per_trip",
  "per_passenger",
  "monthly_fixed",
  "distance_based",
]);

export const directionEnum = pgEnum("trip_direction", [
  "home_to_office",
  "office_to_home",
  "inter_office",
  "ad_hoc",
]);

export const tripStatusEnum = pgEnum("trip_status", [
  "scheduled",
  "dispatching",
  "in_progress",
  "completed",
  "delayed",
  "breakdown",
  "cancelled",
]);

export const bookingStatusEnum = pgEnum("booking_status", [
  "pending",
  "approved",
  "waitlisted",
  "assigned",
  "in_progress",
  "completed",
  "no_show",
  "cancelled",
  "rejected",
]);

export const vehicleStatusEnum = pgEnum("vehicle_status", [
  "available",
  "assigned",
  "on_trip",
  "under_maintenance",
  "out_of_service",
]);

export const driverStatusEnum = pgEnum("driver_status", [
  "available",
  "on_trip",
  "off_duty",
  "unavailable",
]);

export const incidentTypeEnum = pgEnum("incident_type", [
  "breakdown",
  "accident",
  "sos",
  "missed_pickup",
  "delay",
  "no_show",
  "complaint",
  "safety",
]);

export const incidentSeverityEnum = pgEnum("incident_severity", [
  "low",
  "medium",
  "high",
  "critical",
]);

export const incidentStatusEnum = pgEnum("incident_status", [
  "open",
  "acknowledged",
  "resolved",
]);

export const invoiceStatusEnum = pgEnum("invoice_status", [
  "draft",
  "issued",
  "paid",
  "partial",
  "overdue",
  "void",
]);

export const paymentMethodEnum = pgEnum("payment_method", [
  "bank_transfer",
  "mobile_money",
  "paystack",
  "flutterwave",
  "cash",
  "cheque",
]);

export const paymentStatusEnum = pgEnum("payment_status", [
  "pending",
  "successful",
  "failed",
]);

export const recurringEnum = pgEnum("recurring_rule", [
  "none",
  "daily",
  "weekly",
  "monthly",
]);

export const earningsStatusEnum = pgEnum("earnings_status", [
  "accrued",
  "approved",
  "paid",
]);

const money = (name: string) => numeric(name, { precision: 12, scale: 2 });

/* -------------------------------------------------------------- companies */

export const companies = pgTable(
  "companies",
  {
    id: serial("id").primaryKey(),
    name: varchar("name", { length: 160 }).notNull(),
    contactPerson: varchar("contact_person", { length: 120 }),
    email: varchar("email", { length: 160 }),
    phone: varchar("phone", { length: 40 }),
    industry: varchar("industry", { length: 80 }),
    city: varchar("city", { length: 80 }),
    billingModel: billingModelEnum("billing_model").notNull().default("per_passenger"),
    currency: varchar("currency", { length: 8 }).notNull().default("GHS"),
    monthlyRate: money("monthly_rate").default("0"),
    status: companyStatusEnum("status").notNull().default("active"),
    notes: text("notes"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("companies_status_idx").on(t.status)],
);

export const branches = pgTable(
  "company_branches",
  {
    id: serial("id").primaryKey(),
    companyId: integer("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    name: varchar("name", { length: 140 }).notNull(),
    address: text("address"),
    city: varchar("city", { length: 80 }),
    lat: doublePrecision("lat"),
    lng: doublePrecision("lng"),
    isHeadquarters: boolean("is_headquarters").default(false).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("branches_company_idx").on(t.companyId)],
);

/* ------------------------------------------------------------------- users */

export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    email: varchar("email", { length: 180 }).notNull().unique(),
    phone: varchar("phone", { length: 40 }),
    fullName: varchar("full_name", { length: 140 }).notNull(),
    passwordHash: text("password_hash").notNull(),
    role: userRoleEnum("role").notNull().default("employee"),
    status: userStatusEnum("status").notNull().default("active"),
    companyId: integer("company_id").references(() => companies.id, {
      onDelete: "set null",
    }),
    twoFactorEnabled: boolean("two_factor_enabled").notNull().default(false),
    twoFactorCode: varchar("two_factor_code", { length: 12 }),
    invitationToken: varchar("invitation_token", { length: 80 }),
    invitedById: integer("invited_by_id"),
    lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("users_role_idx").on(t.role), index("users_company_idx").on(t.companyId)],
);

export const sessions = pgTable(
  "sessions",
  {
    token: varchar("token", { length: 96 }).primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    ip: varchar("ip", { length: 64 }),
    userAgent: text("user_agent"),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("sessions_user_idx").on(t.userId)],
);

export const passwordResets = pgTable(
  "password_resets",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    tokenHash: varchar("token_hash", { length: 96 }).notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    usedAt: timestamp("used_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("password_resets_user_idx").on(t.userId)],
);

/* --------------------------------------------------------------- employees */

export const shifts = pgTable(
  "employee_shifts",
  {
    id: serial("id").primaryKey(),
    companyId: integer("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    branchId: integer("branch_id").references(() => branches.id, {
      onDelete: "set null",
    }),
    name: varchar("name", { length: 80 }).notNull(),
    startTime: time("start_time").notNull(),
    endTime: time("end_time").notNull(),
    graceMinutes: integer("grace_minutes").notNull().default(15),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("shifts_company_idx").on(t.companyId)],
);

export const employees = pgTable(
  "employees",
  {
    id: serial("id").primaryKey(),
    companyId: integer("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    branchId: integer("branch_id").references(() => branches.id, {
      onDelete: "set null",
    }),
    userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
    shiftId: integer("shift_id").references(() => shifts.id, { onDelete: "set null" }),
    employeeCode: varchar("employee_code", { length: 40 }).notNull(),
    fullName: varchar("full_name", { length: 140 }).notNull(),
    email: varchar("email", { length: 180 }),
    phone: varchar("phone", { length: 40 }),
    department: varchar("department", { length: 100 }),
    jobTitle: varchar("job_title", { length: 100 }),
    homeAddress: text("home_address"),
    homeLat: doublePrecision("home_lat"),
    homeLng: doublePrecision("home_lng"),
    zone: varchar("zone", { length: 80 }),
    vip: boolean("vip").notNull().default(false),
    active: boolean("active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [
    index("employees_company_idx").on(t.companyId),
    unique("employees_company_code_unique").on(t.companyId, t.employeeCode),
  ],
);

/* -------------------------------------------------------- routes &  stops */

export const stops = pgTable(
  "stops",
  {
    id: serial("id").primaryKey(),
    companyId: integer("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    name: varchar("name", { length: 140 }).notNull(),
    zone: varchar("zone", { length: 80 }),
    address: text("address"),
    lat: doublePrecision("lat"),
    lng: doublePrecision("lng"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("stops_company_idx").on(t.companyId)],
);

export const routes = pgTable(
  "routes",
  {
    id: serial("id").primaryKey(),
    companyId: integer("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    branchId: integer("branch_id").references(() => branches.id, {
      onDelete: "set null",
    }),
    name: varchar("name", { length: 140 }).notNull(),
    direction: directionEnum("direction").notNull().default("home_to_office"),
    zone: varchar("zone", { length: 80 }),
    estimatedKm: doublePrecision("estimated_km").default(0),
    estimatedMinutes: integer("estimated_minutes").default(0),
    active: boolean("active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("routes_company_idx").on(t.companyId)],
);

export const routeStops = pgTable(
  "route_stops",
  {
    id: serial("id").primaryKey(),
    routeId: integer("route_id")
      .notNull()
      .references(() => routes.id, { onDelete: "cascade" }),
    stopId: integer("stop_id")
      .notNull()
      .references(() => stops.id, { onDelete: "cascade" }),
    sequence: integer("sequence").notNull(),
    offsetMinutes: integer("offset_minutes").notNull().default(0),
  },
  (t) => [unique("route_stop_seq_unique").on(t.routeId, t.stopId, t.sequence)],
);

/* ------------------------------------------------------------ fleet/ staff */

export const vehicles = pgTable(
  "vehicles",
  {
    id: serial("id").primaryKey(),
    registrationNo: varchar("registration_no", { length: 30 }).notNull().unique(),
    make: varchar("make", { length: 60 }).notNull(),
    model: varchar("model", { length: 60 }).notNull(),
    year: integer("year"),
    photoUrl: text("photo_url"),
    capacity: integer("capacity").notNull(),
    vehicleType: varchar("vehicle_type", { length: 40 }).notNull().default("minibus"),
    fuelType: varchar("fuel_type", { length: 30 }).notNull().default("diesel"),
    ownership: varchar("ownership", { length: 30 }).notNull().default("owned"),
    assignedCompanyId: integer("assigned_company_id").references(() => companies.id, {
      onDelete: "set null",
    }),
    assignedDriverId: integer("assigned_driver_id"),
    odometerKm: integer("odometer_km").default(0),
    avgKmPerLitre: doublePrecision("avg_km_per_litre").default(0),
    insuranceExpiry: date("insurance_expiry"),
    roadworthinessExpiry: date("roadworthiness_expiry"),
    registrationExpiry: date("registration_expiry"),
    status: vehicleStatusEnum("status").notNull().default("available"),
    costPerKm: money("cost_per_km").default("0"),
    notes: text("notes"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("vehicles_status_idx").on(t.status)],
);

export const drivers = pgTable(
  "drivers",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
    companyId: integer("company_id").references(() => companies.id, {
      onDelete: "set null",
    }),
    fullName: varchar("full_name", { length: 140 }).notNull(),
    phone: varchar("phone", { length: 40 }).notNull(),
    email: varchar("email", { length: 180 }),
    licenseNo: varchar("license_no", { length: 60 }).notNull(),
    licenseClass: varchar("license_class", { length: 30 }),
    licenseExpiry: date("license_expiry"),
    status: driverStatusEnum("status").notNull().default("available"),
    baseSalary: money("base_salary").default("0"),
    tripAllowance: money("trip_allowance").default("0"),
    ratingAvg: doublePrecision("rating_avg").default(5),
    ratingCount: integer("rating_count").default(0),
    emergencyContactName: varchar("emergency_contact_name", { length: 120 }),
    emergencyContactPhone: varchar("emergency_contact_phone", { length: 40 }),
    hiredAt: date("hired_at"),
    notes: text("notes"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("drivers_status_idx").on(t.status)],
);

export const driverShifts = pgTable(
  "driver_shifts",
  {
    id: serial("id").primaryKey(),
    driverId: integer("driver_id")
      .notNull()
      .references(() => drivers.id, { onDelete: "cascade" }),
    shiftDate: date("shift_date").notNull(),
    label: varchar("label", { length: 40 }).notNull().default("morning"),
    startTime: time("start_time").notNull(),
    endTime: time("end_time").notNull(),
    status: varchar("status", { length: 30 }).notNull().default("planned"),
  },
  (t) => [index("driver_shifts_date_idx").on(t.shiftDate, t.driverId)],
);

export const maintenanceRecords = pgTable(
  "maintenance_records",
  {
    id: serial("id").primaryKey(),
    vehicleId: integer("vehicle_id")
      .notNull()
      .references(() => vehicles.id, { onDelete: "cascade" }),
    type: varchar("type", { length: 40 }).notNull().default("preventive"),
    description: text("description").notNull(),
    cost: money("cost").default("0"),
    odometerKm: integer("odometer_km"),
    serviceDate: date("service_date").notNull(),
    nextServiceDate: date("next_service_date"),
    garageName: varchar("garage_name", { length: 120 }),
    status: varchar("status", { length: 30 }).notNull().default("completed"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("maintenance_vehicle_idx").on(t.vehicleId)],
);

/* ---------------------------------------------------- trips & assignments */

export const trips = pgTable(
  "trips",
  {
    id: serial("id").primaryKey(),
    reference: varchar("reference", { length: 30 }).notNull().unique(),
    companyId: integer("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    branchId: integer("branch_id").references(() => branches.id, {
      onDelete: "set null",
    }),
    routeId: integer("route_id").references(() => routes.id, { onDelete: "set null" }),
    vehicleId: integer("vehicle_id").references(() => vehicles.id, {
      onDelete: "set null",
    }),
    driverId: integer("driver_id").references(() => drivers.id, {
      onDelete: "set null",
    }),
    direction: directionEnum("direction").notNull().default("home_to_office"),
    tripDate: date("trip_date").notNull(),
    scheduledDeparture: timestamp("scheduled_departure", { withTimezone: true }).notNull(),
    scheduledArrival: timestamp("scheduled_arrival", { withTimezone: true }),
    actualDeparture: timestamp("actual_departure", { withTimezone: true }),
    actualArrival: timestamp("actual_arrival", { withTimezone: true }),
    status: tripStatusEnum("status").notNull().default("scheduled"),
    capacity: integer("capacity").notNull().default(0),
    bookedSeats: integer("booked_seats").notNull().default(0),
    plannedKm: doublePrecision("planned_km").default(0),
    notes: text("notes"),
    createdById: integer("created_by_id").references(() => users.id, {
      onDelete: "set null",
    }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [
    index("trips_date_status_idx").on(t.tripDate, t.status),
    index("trips_company_idx").on(t.companyId),
    index("trips_driver_idx").on(t.driverId),
  ],
);

export const bookings = pgTable(
  "bookings",
  {
    id: serial("id").primaryKey(),
    reference: varchar("reference", { length: 30 }).notNull().unique(),
    companyId: integer("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    employeeId: integer("employee_id")
      .notNull()
      .references(() => employees.id, { onDelete: "cascade" }),
    tripId: integer("trip_id").references(() => trips.id, { onDelete: "set null" }),
    routeId: integer("route_id").references(() => routes.id, { onDelete: "set null" }),
    direction: directionEnum("direction").notNull().default("home_to_office"),
    bookingDate: date("booking_date").notNull(),
    pickupAddress: text("pickup_address"),
    dropoffAddress: text("dropoff_address"),
    pickupStopId: integer("pickup_stop_id").references(() => stops.id, {
      onDelete: "set null",
    }),
    requestedTime: time("requested_time"),
    pickupTime: time("pickup_time"),
    seats: integer("seats").notNull().default(1),
    status: bookingStatusEnum("status").notNull().default("pending"),
    recurring: recurringEnum("recurring").notNull().default("none"),
    otpCode: varchar("otp_code", { length: 8 }),
    vip: boolean("vip").notNull().default(false),
    notes: text("notes"),
    approvedById: integer("approved_by_id").references(() => users.id, {
      onDelete: "set null",
    }),
    cancelledAt: timestamp("cancelled_at", { withTimezone: true }),
    cancelReason: text("cancel_reason"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [
    index("bookings_company_date_idx").on(t.companyId, t.bookingDate),
    index("bookings_employee_idx").on(t.employeeId),
    index("bookings_trip_idx").on(t.tripId),
    index("bookings_status_idx").on(t.status),
  ],
);

export const boardings = pgTable(
  "passenger_boardings",
  {
    id: serial("id").primaryKey(),
    bookingId: integer("booking_id")
      .notNull()
      .references(() => bookings.id, { onDelete: "cascade" }),
    tripId: integer("trip_id").references(() => trips.id, { onDelete: "cascade" }),
    boardedAt: timestamp("boarded_at", { withTimezone: true }),
    alightedAt: timestamp("alighted_at", { withTimezone: true }),
    noShow: boolean("no_show").notNull().default(false),
    otpVerified: boolean("otp_verified").notNull().default(false),
    recordedById: integer("recorded_by_id").references(() => users.id, {
      onDelete: "set null",
    }),
    note: text("note"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [
    unique("boardings_booking_unique").on(t.bookingId, t.tripId),
    index("boardings_trip_idx").on(t.tripId),
  ],
);

export const gpsEvents = pgTable(
  "gps_events",
  {
    id: serial("id").primaryKey(),
    tripId: integer("trip_id").references(() => trips.id, { onDelete: "cascade" }),
    vehicleId: integer("vehicle_id").references(() => vehicles.id, {
      onDelete: "cascade",
    }),
    lat: doublePrecision("lat").notNull(),
    lng: doublePrecision("lng").notNull(),
    speedKph: doublePrecision("speed_kph").default(0),
    heading: integer("heading").default(0),
    source: varchar("source", { length: 30 }).notNull().default("driver_app"),
    recordedAt: timestamp("recorded_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [
    index("gps_trip_idx").on(t.tripId, t.recordedAt),
    index("gps_recorded_idx").on(t.recordedAt),
  ],
);

export const feedback = pgTable(
  "feedback",
  {
    id: serial("id").primaryKey(),
    companyId: integer("company_id").references(() => companies.id, {
      onDelete: "cascade",
    }),
    employeeId: integer("employee_id").references(() => employees.id, {
      onDelete: "set null",
    }),
    tripId: integer("trip_id").references(() => trips.id, { onDelete: "set null" }),
    bookingId: integer("booking_id").references(() => bookings.id, {
      onDelete: "set null",
    }),
    category: varchar("category", { length: 30 }).notNull().default("feedback"),
    rating: integer("rating"),
    comments: text("comments"),
    status: varchar("status", { length: 30 }).notNull().default("new"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("feedback_company_idx").on(t.companyId)],
);

/* ---------------------------------------------------------------- finance */

export const serviceAgreements = pgTable(
  "service_agreements",
  {
    id: serial("id").primaryKey(),
    companyId: integer("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    name: varchar("name", { length: 140 }).notNull(),
    pricingModel: billingModelEnum("pricing_model").notNull().default("per_passenger"),
    unitRate: money("unit_rate").default("0"),
    fixedMonthlyAmount: money("fixed_monthly_amount").default("0"),
    currency: varchar("currency", { length: 8 }).notNull().default("GHS"),
    startDate: date("start_date").notNull(),
    endDate: date("end_date"),
    slaOnTimePercent: doublePrecision("sla_on_time_percent").default(95),
    slaResponseMinutes: integer("sla_response_minutes").default(15),
    maxPickupDeviationMinutes: integer("max_pickup_deviation_minutes").default(10),
    cancellationPolicyHours: integer("cancellation_policy_hours").default(2),
    status: varchar("status", { length: 30 }).notNull().default("active"),
    notes: text("notes"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("agreements_company_idx").on(t.companyId)],
);

export const invoices = pgTable(
  "invoices",
  {
    id: serial("id").primaryKey(),
    companyId: integer("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    invoiceNo: varchar("invoice_no", { length: 40 }).notNull().unique(),
    periodStart: date("period_start").notNull(),
    periodEnd: date("period_end").notNull(),
    subtotal: money("subtotal").notNull().default("0"),
    tax: money("tax").notNull().default("0"),
    discount: money("discount").notNull().default("0"),
    total: money("total").notNull().default("0"),
    amountPaid: money("amount_paid").notNull().default("0"),
    status: invoiceStatusEnum("status").notNull().default("draft"),
    issuedAt: timestamp("issued_at", { withTimezone: true }),
    dueDate: date("due_date"),
    notes: text("notes"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("invoices_company_idx").on(t.companyId, t.status)],
);

export const invoiceLines = pgTable(
  "invoice_lines",
  {
    id: serial("id").primaryKey(),
    invoiceId: integer("invoice_id")
      .notNull()
      .references(() => invoices.id, { onDelete: "cascade" }),
    description: text("description").notNull(),
    category: varchar("category", { length: 40 }).notNull().default("transport"),
    quantity: numeric("quantity", { precision: 10, scale: 2 }).notNull().default("1"),
    unitPrice: money("unit_price").notNull().default("0"),
    amount: money("amount").notNull().default("0"),
  },
  (t) => [index("invoice_lines_invoice_idx").on(t.invoiceId)],
);

export const payments = pgTable(
  "payments",
  {
    id: serial("id").primaryKey(),
    companyId: integer("company_id")
      .notNull()
      .references(() => companies.id, { onDelete: "cascade" }),
    invoiceId: integer("invoice_id").references(() => invoices.id, {
      onDelete: "set null",
    }),
    amount: money("amount").notNull().default("0"),
    method: paymentMethodEnum("method").notNull().default("bank_transfer"),
    reference: varchar("reference", { length: 80 }),
    status: paymentStatusEnum("status").notNull().default("pending"),
    paidAt: timestamp("paid_at", { withTimezone: true }),
    notes: text("notes"),
    recordedById: integer("recorded_by_id").references(() => users.id, {
      onDelete: "set null",
    }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("payments_company_idx").on(t.companyId)],
);

export const driverEarnings = pgTable(
  "driver_earnings",
  {
    id: serial("id").primaryKey(),
    driverId: integer("driver_id")
      .notNull()
      .references(() => drivers.id, { onDelete: "cascade" }),
    tripId: integer("trip_id").references(() => trips.id, { onDelete: "set null" }),
    periodStart: date("period_start").notNull(),
    periodEnd: date("period_end").notNull(),
    basePay: money("base_pay").notNull().default("0"),
    overtimePay: money("overtime_pay").notNull().default("0"),
    allowance: money("allowance").notNull().default("0"),
    deduction: money("deduction").notNull().default("0"),
    total: money("total").notNull().default("0"),
    status: earningsStatusEnum("status").notNull().default("accrued"),
    paidAt: timestamp("paid_at", { withTimezone: true }),
  },
  (t) => [index("earnings_driver_idx").on(t.driverId, t.periodStart)],
);

/* ------------------------------------------------ safety / ops / audit */

export const incidents = pgTable(
  "incidents",
  {
    id: serial("id").primaryKey(),
    companyId: integer("company_id").references(() => companies.id, {
      onDelete: "cascade",
    }),
    tripId: integer("trip_id").references(() => trips.id, { onDelete: "set null" }),
    vehicleId: integer("vehicle_id").references(() => vehicles.id, {
      onDelete: "set null",
    }),
    driverId: integer("driver_id").references(() => drivers.id, {
      onDelete: "set null",
    }),
    reportedById: integer("reported_by_id").references(() => users.id, {
      onDelete: "set null",
    }),
    type: incidentTypeEnum("type").notNull(),
    severity: incidentSeverityEnum("severity").notNull().default("medium"),
    status: incidentStatusEnum("status").notNull().default("open"),
    description: text("description").notNull(),
    actionTaken: text("action_taken"),
    location: text("location"),
    reportedAt: timestamp("reported_at", { withTimezone: true }).defaultNow().notNull(),
    resolvedAt: timestamp("resolved_at", { withTimezone: true }),
  },
  (t) => [
    index("incidents_status_idx").on(t.status),
    index("incidents_company_idx").on(t.companyId),
  ],
);

export const notifications = pgTable(
  "notifications",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").references(() => users.id, { onDelete: "cascade" }),
    companyId: integer("company_id").references(() => companies.id, {
      onDelete: "cascade",
    }),
    channel: varchar("channel", { length: 20 }).notNull().default("in_app"),
    category: varchar("category", { length: 40 }).notNull().default("general"),
    title: varchar("title", { length: 160 }).notNull(),
    body: text("body"),
    bookingId: integer("booking_id").references(() => bookings.id, {
      onDelete: "cascade",
    }),
    tripId: integer("trip_id").references(() => trips.id, { onDelete: "cascade" }),
    readAt: timestamp("read_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [index("notifications_user_idx").on(t.userId, t.readAt)],
);

export const auditLogs = pgTable(
  "audit_logs",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
    actorEmail: varchar("actor_email", { length: 180 }),
    action: varchar("action", { length: 80 }).notNull(),
    entity: varchar("entity", { length: 60 }).notNull(),
    entityId: varchar("entity_id", { length: 40 }),
    companyId: integer("company_id").references(() => companies.id, {
      onDelete: "set null",
    }),
    details: jsonb("details"),
    ip: varchar("ip", { length: 64 }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [
    index("audit_created_idx").on(t.createdAt),
    index("audit_company_idx").on(t.companyId),
  ],
);

export type Company = typeof companies.$inferSelect;
export type User = typeof users.$inferSelect;
export type Employee = typeof employees.$inferSelect;
export type Vehicle = typeof vehicles.$inferSelect;
export type Driver = typeof drivers.$inferSelect;
export type Route = typeof routes.$inferSelect;
export type Trip = typeof trips.$inferSelect;
export type Booking = typeof bookings.$inferSelect;
export type Incident = typeof incidents.$inferSelect;
export type Invoice = typeof invoices.$inferSelect;
