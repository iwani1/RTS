import { randomBytes, randomInt, scryptSync, timingSafeEqual } from "node:crypto";
import { cookies, headers } from "next/headers";
import { redirect } from "next/navigation";
import { and, eq, gt } from "drizzle-orm";
import { db } from "@/db";
import { auditLogs, sessions, users, type User } from "@/db/schema";
import { can, canAccess, type Permission, type Role, type Section } from "./rbac";

export const SESSION_COOKIE = "tms_session";
const SESSION_DAYS = 7;

/* ----------------------------------------------------------- passwords */

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const derived = scryptSync(password, salt, 64).toString("hex");
  return `scrypt$${salt}$${derived}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const parts = stored.split("$");
  if (parts.length !== 3) return false;
  const [, salt, hash] = parts;
  const derived = scryptSync(password, salt, 64);
  const expected = Buffer.from(hash, "hex");
  if (expected.length !== derived.length) return false;
  return timingSafeEqual(derived, expected);
}

export function generateOtp(): string {
  return String(randomInt(100000, 999999));
}

export function generateToken(bytes = 32): string {
  return randomBytes(bytes).toString("hex");
}

/* ------------------------------------------------------------ sessions */

export async function createSession(userId: number) {
  const token = generateToken(48);
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000);
  const hdrs = await headers();
  await db.insert(sessions).values({
    token,
    userId,
    expiresAt,
    ip: hdrs.get("x-forwarded-for") ?? "local",
    userAgent: hdrs.get("user-agent") ?? "unknown",
  });
  const jar = await cookies();
  jar.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    secure: process.env.NODE_ENV === "production",
    expires: expiresAt,
  });
  await db.update(users).set({ lastLoginAt: new Date() }).where(eq(users.id, userId));
}

export async function destroySession() {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (token) {
    await db.delete(sessions).where(eq(sessions.token, token));
  }
  jar.delete(SESSION_COOKIE);
}

export type SessionUser = Pick<
  User,
  "id" | "email" | "fullName" | "role" | "companyId" | "status" | "twoFactorEnabled"
>;

export async function getSessionUser(): Promise<SessionUser | null> {
  try {
    const jar = await cookies();
    const token = jar.get(SESSION_COOKIE)?.value;
    if (!token) return null;
    const rows = await db
      .select({
        id: users.id,
        email: users.email,
        fullName: users.fullName,
        role: users.role,
        companyId: users.companyId,
        status: users.status,
        twoFactorEnabled: users.twoFactorEnabled,
      })
      .from(sessions)
      .innerJoin(users, eq(users.id, sessions.userId))
      .where(and(eq(sessions.token, token), gt(sessions.expiresAt, new Date())))
      .limit(1);
    const user = rows[0];
    if (!user || user.status !== "active") return null;
    return user;
  } catch {
    return null;
  }
}

export async function requireUser(): Promise<SessionUser> {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  return user;
}

export async function requireSection(section: Section): Promise<SessionUser> {
  const user = await requireUser();
  if (!canAccess(user.role as Role, section)) redirect(homeFor(user.role as Role));
  return user;
}

export async function requirePermission(permission: Permission): Promise<SessionUser> {
  const user = await requireUser();
  if (!can(user.role as Role, permission)) {
    throw new Error("You do not have permission to perform this action.");
  }
  return user;
}

export function homeFor(role: Role): string {
  if (role === "driver") return "/driver";
  if (role === "employee") return "/passenger";
  return "/dashboard";
}

/* ---------------------------------------------------------- audit trail */

export async function logAudit(input: {
  user?: SessionUser | null;
  action: string;
  entity: string;
  entityId?: string | number | null;
  companyId?: number | null;
  details?: unknown;
}) {
  try {
    await db.insert(auditLogs).values({
      userId: input.user?.id ?? null,
      actorEmail: input.user?.email ?? "system",
      action: input.action,
      entity: input.entity,
      entityId: input.entityId != null ? String(input.entityId) : null,
      companyId: input.companyId ?? input.user?.companyId ?? null,
      details: (input.details ?? null) as Record<string, unknown> | null,
    });
  } catch {
    // never let audit logging break a business operation
  }
}

/** Multi-tenant guard: resolves the company scope for the signed in user. */
export function companyScope(user: SessionUser): number | null {
  if (user.role === "super_admin" || user.role === "ops_manager" || user.role === "dispatcher" || user.role === "fleet_manager" || user.role === "finance_officer") {
    return null; // platform staff see all companies
  }
  return user.companyId ?? null;
}
