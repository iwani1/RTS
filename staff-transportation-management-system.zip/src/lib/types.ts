export type ClassValue = string;
